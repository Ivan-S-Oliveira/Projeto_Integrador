#!/usr/bin/env python3
r"""Calibracao por janela, ano e grupo (O/E, inclinacao, ECE) a partir das previsoes gravadas pelo notebook 11.

Nao treina nada e nao le o teste: usa so o arquivo de previsoes que o proprio notebook 11 gravou.

Uso (na raiz do repositorio, com o venv do projeto):  [antes: $env:PYTHONPATH = "tools\G9_final.zip"]
    .\.venv\Scripts\python.exe -m calibracao_pos_g9 --ensaio          (ensaio: usa as previsoes do ensaio; confere que o script funciona ANTES do G9)
    .\.venv\Scripts\python.exe -m calibracao_pos_g9                   (relatorio com as previsoes reais; nada e gravado)
    .\.venv\Scripts\python.exe -m calibracao_pos_g9 --aplicar         (grava os CSV em outputs/final)

Saidas (com --aplicar): outputs/final/calibracao_por_janela.csv, calibracao_por_ano.csv e calibracao_por_grupo.csv.
Leitura: O/E = obitos observados / soma das probabilidades previstas. Acima de 1: o modelo subestima o risco.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression

JANELAS = {"teste_a": ["test_ref"], "pandemico_isolado": ["test_pandemic"], "teste_b": ["test_ref", "test_pandemic"]}
GRUPOS = ["regiao_residencia", "faixa_etaria", "sexo_categoria", "sg_uf"]
MIN_N, MIN_EVENTOS = 100, 20


def resumo(y: np.ndarray, p: np.ndarray, n_bins: int = 10) -> dict:
    p = np.clip(p.astype("float64"), 1e-9, 1 - 1e-9)
    prev = float(y.mean())
    brier_nulo = prev * (1 - prev)
    brier = float(np.mean((p - y) ** 2))
    out = {
        "n": int(len(y)), "obitos": int(y.sum()), "prevalencia": prev, "media_prevista": float(p.mean()),
        "o_e": float(y.sum()) / float(p.sum()) if p.sum() > 0 else np.nan,
        "brier": brier, "brier_relativo": 1 - brier / brier_nulo if brier_nulo > 0 else np.nan,
        "inclinacao": np.nan, "intercepto": np.nan, "ece_quantis": np.nan,
    }
    if len(np.unique(y)) < 2:
        return out
    logito = np.log(p / (1 - p)).reshape(-1, 1)
    reg = LogisticRegression(C=1e9, max_iter=500).fit(logito, y)
    out["inclinacao"], out["intercepto"] = float(reg.coef_[0, 0]), float(reg.intercept_[0])
    faixas = pd.qcut(p, q=n_bins, duplicates="drop")
    t = pd.DataFrame({"y": y, "p": p, "f": faixas}).groupby("f", observed=True).agg(n=("y", "size"), obs=("y", "mean"), prev=("p", "mean"))
    out["ece_quantis"] = float((t["n"] * (t["obs"] - t["prev"]).abs()).sum() / t["n"].sum())
    return out


def achar(raiz: Path, ensaio: bool) -> Path | None:
    pasta = raiz / "outputs" / "predictions"
    if not pasta.is_dir():
        return None
    achados = [p for p in pasta.glob("*validacao_final_*_predicoes_teste.*") if ("ensaio" in p.name.lower()) == ensaio]
    return max(achados, key=lambda p: p.stat().st_mtime) if achados else None


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--raiz", type=Path, default=Path.cwd())
    ap.add_argument("--ensaio", action="store_true", help="usa as previsoes do ensaio (nao e resultado do teste)")
    ap.add_argument("--previsoes", type=Path)
    ap.add_argument("--aplicar", action="store_true")
    args = ap.parse_args()
    raiz = args.raiz.resolve()

    arq = args.previsoes or achar(raiz, args.ensaio)
    if not arq or not arq.is_file():
        print("ABORTADO: nao achei o arquivo de previsoes" + (" do ensaio." if args.ensaio else " do notebook 11. O G9 foi executado?"))
        return 1
    df = pd.read_parquet(arq) if arq.suffix == ".parquet" else pd.read_csv(arq)
    falta = {"bloco", "y_true", "y_prob"} - set(df.columns)
    if falta:
        print(f"ABORTADO: faltam colunas no arquivo de previsoes: {sorted(falta)}")
        return 1

    linhas_j, linhas_a, linhas_g = [], [], []
    for nome, blocos in JANELAS.items():
        sub = df[df["bloco"].isin(blocos)]
        if sub.empty:
            print(f"AVISO: janela {nome} sem linhas.")
            continue
        y, p = sub["y_true"].to_numpy(dtype=int), sub["y_prob"].to_numpy(dtype=float)
        linhas_j.append({"janela": nome, **resumo(y, p)})
        if nome == "teste_b" and "ano_internacao" in sub.columns:
            for ano, g in sub.groupby("ano_internacao"):
                if len(g) >= MIN_N:
                    linhas_a.append({"ano": int(ano), **resumo(g["y_true"].to_numpy(dtype=int), g["y_prob"].to_numpy(dtype=float))})
        if nome in ("teste_a", "pandemico_isolado"):
            for col in GRUPOS:
                if col not in sub.columns:
                    continue
                for valor, g in sub.groupby(sub[col].astype("string").fillna("AUSENTE")):
                    ev = int(g["y_true"].sum())
                    suprimido = len(g) < MIN_N or ev < MIN_EVENTOS or (len(g) - ev) < MIN_EVENTOS
                    base = {"janela": nome, "grupo": col, "valor": str(valor), "n": int(len(g)), "obitos": ev, "suprimido": suprimido}
                    linhas_g.append(base if suprimido else {**base, **{k: v for k, v in resumo(g["y_true"].to_numpy(dtype=int), g["y_prob"].to_numpy(dtype=float)).items() if k not in base}})
    tj, ta, tg = pd.DataFrame(linhas_j), pd.DataFrame(linhas_a), pd.DataFrame(linhas_g)

    rot = " (ENSAIO: nao e resultado do teste)" if args.ensaio else ""
    print(f"Previsoes: {arq.name}{rot}")
    cols = ["janela", "n", "obitos", "prevalencia", "media_prevista", "o_e", "inclinacao", "intercepto", "ece_quantis", "brier_relativo"]
    print(tj[cols].round(4).to_string(index=False))
    if not ta.empty:
        print("\nPor ano (Teste B):")
        print(ta[["ano", "n", "prevalencia", "media_prevista", "o_e"]].round(3).to_string(index=False))
    if not tg.empty:
        print(f"\nPor grupo: {len(tg)} linhas, {int(tg['suprimido'].sum())} suprimidas (n < {MIN_N} ou menos de {MIN_EVENTOS} obitos/curas).")
    if "pandemico_isolado" in set(tj["janela"]):
        oe = float(tj.loc[tj["janela"] == "pandemico_isolado", "o_e"].iloc[0])
        print(f"\nHipotese registrada (O/E acima de 1 em 2020-2022): O/E = {oe:.2f} -> " + ("dentro do previsto" if oe > 1 else "fora do previsto"))

    if not args.aplicar:
        print("\nRelatorio pronto. Nada foi gravado. Para gravar: rode de novo com --aplicar.")
        return 0
    if args.ensaio:
        print("Com --ensaio nada e gravado em outputs/final (para nao misturar com o resultado real).")
        return 0
    destino = raiz / "outputs" / "final"
    destino.mkdir(parents=True, exist_ok=True)
    tj.to_csv(destino / "calibracao_por_janela.csv", index=False, encoding="utf-8-sig")
    ta.to_csv(destino / "calibracao_por_ano.csv", index=False, encoding="utf-8-sig")
    tg.to_csv(destino / "calibracao_por_grupo.csv", index=False, encoding="utf-8-sig")
    print("GRAVADO: outputs/final/calibracao_por_janela.csv, calibracao_por_ano.csv e calibracao_por_grupo.csv")
    return 0


if __name__ == "__main__":
    sys.exit(main())
