#!/usr/bin/env python3
r"""Roda a suite completa de testes e guarda o resultado em outputs/final/pytest_completo.txt. Nao altera o projeto.

Uso (na raiz do repositorio, com o venv do projeto):  [antes: $env:PYTHONPATH = "tools\G9_final.zip"]
    .\.venv\Scripts\python.exe -m rodar_testes            (suite completa, -m "")
    .\.venv\Scripts\python.exe -m rodar_testes --rapido   (sem os testes marcados como slow)
"""
from __future__ import annotations

import argparse
import subprocess
import sys
import time
from pathlib import Path


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--raiz", type=Path, default=Path.cwd())
    ap.add_argument("--rapido", action="store_true")
    ap.add_argument("--limite-s", type=int, default=2400)
    args = ap.parse_args()
    raiz = args.raiz.resolve()
    if not (raiz / "tests").is_dir():
        print(f"ABORTADO: {raiz} nao parece a raiz do projeto (sem pasta tests).")
        return 1
    marca = "not slow" if args.rapido else ""
    t0 = time.perf_counter()
    try:
        r = subprocess.run([sys.executable, "-m", "pytest", "-m", marca, "-q", "-p", "no:cacheprovider"], cwd=raiz, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=args.limite_s)
        saida, cod = r.stdout + r.stderr, r.returncode
    except subprocess.TimeoutExpired:
        saida, cod = f"TEMPO ESGOTADO ({args.limite_s} s).", 124
    dur = time.perf_counter() - t0
    destino = raiz / "outputs" / "final"
    destino.mkdir(parents=True, exist_ok=True)
    (destino / "pytest_completo.txt").write_text(saida, encoding="utf-8")
    linhas = saida.strip().splitlines()
    falhas = [l for l in linhas if l.startswith(("FAILED", "ERROR"))]
    print(f"pytest {'(rapido)' if args.rapido else '(completo)'}: codigo {cod} em {dur:.0f} s")
    print("\n".join(falhas[:25]) or "sem falhas listadas")
    print(linhas[-1] if linhas else "(sem saida)")
    return 0 if cod == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
