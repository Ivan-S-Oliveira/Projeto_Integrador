#!/usr/bin/env python3
r"""Orquestrador: roda os scripts do projeto em sequencia, num unico comando, em dois tempos.

Tempo 1 (relatorio): roda o RELATORIO de cada etapa (nada muda no repositorio) e junta tudo num arquivo so.
Tempo 2 (aplicar): grava as etapas aprovadas, na ordem segura, e roda os testes. So funciona se o commit for o mesmo do relatorio.

Uso (na raiz do repositorio, com o venv do projeto; todos os scripts ficam na mesma pasta, fora do repositorio):  [antes: $env:PYTHONPATH = "tools\G9_final.zip"]
    .\.venv\Scripts\python.exe -m lote listar
    .\.venv\Scripts\python.exe -m lote relatorio --lote agora
    .\.venv\Scripts\python.exe -m lote aplicar --etapas renomear

Lotes prontos:   agora = testes, renomear, checklist
                 tudo = todos os relatorios de uma vez (use com --ensaio hoje)
                 pos-cadeia = caminhos, comentarios, markdown
                 pos-g9 = calibracao, tabelas, curva, blocos
                 pacote = resultados
Ou escolha as etapas: --etapas renomear,comentarios

O relatorio vai para outputs/final/lote_relatorio.md (envie esse arquivo para a IA conferir antes de aplicar).
"""
from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

AQUI = Path(__file__).resolve().parent
_ZIP = AQUI if AQUI.suffix.lower() == ".zip" else None


def _existe(nome: str) -> bool:
    # roda a partir do zip (sem descompactar): confere dentro do zip
    if _ZIP:
        import zipfile
        try:
            return f"{nome}.py" in zipfile.ZipFile(_ZIP).namelist()
        except OSError:
            return False
    return (AQUI / f"{nome}.py").is_file()


def _cmd(nome: str, *args: str) -> list[str]:
    # com o zip no PYTHONPATH (ver _env_zip), "-m nome" acha o modulo dentro dele
    if _ZIP:
        return [sys.executable, "-m", nome, *args]
    return [sys.executable, str(AQUI / f"{nome}.py"), *args]


def _env_zip(env: dict) -> dict:
    if not _ZIP:
        return env
    env = dict(env)
    atual = env.get("PYTHONPATH", "")
    env["PYTHONPATH"] = str(_ZIP) + (os.pathsep + atual if atual else "")
    return env

# nome: (script, args do relatorio, args do aplicar ou None se nao aplica sozinho, descricao)
ETAPAS = {
    "renomear":    ("renomear_saidas.py",      [],                    ["--aplicar", "--mover-gerados"], "troca os prefixos dos arquivos de saida (#192)"),
    "caminhos":    ("limpar_caminhos.py",      [],                    ["--aplicar"],                    "tira caminhos pessoais das saidas salvas (#189)"),
    "comentarios": ("limpar_comentarios.py",   [],                    ["--aplicar"],                    "remove comentarios do codigo, notebooks e YAML (#189)"),
    "markdown":    ("enxugar_markdown.py",     [],                    None,                             "lista as celulas Markdown candidatas (#190; a troca usa um JSON da IA)"),
    "calibracao":  ("calibracao_pos_g9.py",    [],                    ["--aplicar"],                    "O/E e calibracao por janela, ano e grupo (#165)"),
    "tabelas":     ("tabelas_relatorio.py",    [],                    ["--aplicar"],                    "tabelas de equidade e figura por regiao (#55)"),
    "curva":       ("curva_decisao.py",        [],                    ["--aplicar"],                    "curva de decisao, opcional (#176)"),
    "blocos":      ("gerar_blocos_g9.py",      [],                    None,                             "textos da documentacao do G9 (#194; so le)"),
    "resultados":  ("montar_resultados.py",    [],                    ["--aplicar"],                    "monta a pasta resultados/ (#157)"),
    "checklist":   ("checklist_g9.py",         [],                    None,                             "checagem do G9 (#193; so le)"),
    "testes":      ("rodar_testes.py",         [],                    None,                             "suite completa de testes (#188; so le; leva alguns minutos)"),
}
# etapas cujo script aceita --ensaio (usam as previsoes e manifestos do ensaio)
ACEITAM_ENSAIO = {"calibracao", "tabelas", "curva", "blocos"}
ORDEM_APLICAR = ["renomear", "caminhos", "comentarios", "calibracao", "tabelas", "curva", "resultados"]
LOTES = {
    "agora":      ["testes", "renomear", "checklist"],
    "tudo":       ["testes", "renomear", "caminhos", "comentarios", "markdown", "calibracao", "tabelas", "curva", "resultados", "blocos", "checklist"],
    "pos-cadeia": ["caminhos", "comentarios", "markdown"],
    "pos-g9":     ["calibracao", "tabelas", "curva", "blocos"],
    "pacote":     ["resultados"],
}
MUDAM_CODIGO = {"renomear", "comentarios"}
CARIMBO = Path("outputs") / "final" / "lote_relatorio.carimbo.json"
RELATORIO = Path("outputs") / "final" / "lote_relatorio.md"


def git(raiz: Path, *args: str) -> str:
    try:
        r = subprocess.run(["git", *args], cwd=raiz, capture_output=True, text=True, timeout=120)
        return r.stdout.strip() if r.returncode == 0 else ""
    except (OSError, subprocess.TimeoutExpired):
        return ""


def rodar(raiz: Path, script: str, args: list[str]) -> tuple[int, str]:
    env = {**os.environ, "PYTHONUTF8": "1", "PYTHONIOENCODING": "utf-8"}
    r = subprocess.run(_cmd(script[:-3], "--raiz", str(raiz), *args), cwd=raiz, capture_output=True, text=True, encoding="utf-8", errors="replace", env=_env_zip(env))
    return r.returncode, (r.stdout + (("\n[stderr]\n" + r.stderr) if r.stderr.strip() else "")).strip()


def cortar(texto: str, topo: int = 260, fim: int = 40) -> str:
    linhas = texto.splitlines()
    if len(linhas) <= topo + fim:
        return texto
    return "\n".join(linhas[:topo] + [f"... [{len(linhas) - topo - fim} linhas omitidas] ..."] + linhas[-fim:])


def escolher(args) -> list[str]:
    if args.etapas:
        nomes = [e.strip() for e in args.etapas.split(",") if e.strip()]
    elif args.lote:
        nomes = list(LOTES[args.lote])
    else:
        print("Escolha --lote ou --etapas. Use `listar` para ver as opcoes.")
        sys.exit(1)
    for n in nomes:
        if n not in ETAPAS:
            print(f"Etapa desconhecida: {n}. Opcoes: {', '.join(ETAPAS)}")
            sys.exit(1)
    return nomes


def cmd_listar() -> int:
    print("Etapas:")
    for n, (_, _, ap, desc) in ETAPAS.items():
        print(f"  {n:12s} {'aplica' if ap else 'so relatorio':13s} {desc}")
    print("\nLotes:")
    for n, e in LOTES.items():
        print(f"  {n:11s} {', '.join(e)}")
    print("\nOrdem segura ao aplicar:", " > ".join(ORDEM_APLICAR))
    faltam = [s for s, *_ in ETAPAS.values() if not _existe(s[:-3])]
    if faltam:
        print("\nATENCAO: faltam scripts ao lado do lote.py:", ", ".join(sorted(set(faltam))))
    return 0


def cmd_relatorio(raiz: Path, nomes: list[str], ensaio: bool = False) -> int:
    agora = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    head = git(raiz, "rev-parse", "HEAD")
    suja = git(raiz, "status", "--porcelain", "--untracked-files=no")
    partes = [f"# Relatorio do lote ({agora})", "", f"- commit: `{head[:10]}` · ramo `{git(raiz, 'rev-parse', '--abbrev-ref', 'HEAD')}`",
              f"- arvore Git: {'limpa' if not suja else 'COM MUDANCAS: ' + ', '.join(l[3:] for l in suja.splitlines()[:8])}", f"- etapas: {', '.join(nomes)}",
              f"- modo: {'ENSAIO (pos-G9 com as previsoes do ensaio; nao serve para aplicar)' if ensaio else 'normal'}", ""]
    resumo, ok_todas = [], True
    destino = raiz / RELATORIO
    destino.parent.mkdir(parents=True, exist_ok=True)
    for n in nomes:
        script, a_rel, a_ap, desc = ETAPAS[n]
        if not _existe(script[:-3]):
            texto, cod = f"FALTA o script {script} ao lado do lote.py.", 1
        else:
            cod, texto = rodar(raiz, script, a_rel + (["--ensaio"] if ensaio and n in ACEITAM_ENSAIO else []))
        status = "ok" if cod == 0 else f"codigo {cod}"
        if n == "checklist" and cod == 1:
            status = "checklist com FALHAS (informativo: veja a lista)"
        elif n == "testes" and cod == 1:
            status = "testes com FALHAS (veja a lista)"
        else:
            ok_todas &= cod == 0
        resumo.append((n, status))
        partes += [f"## {n} · {desc}", "", f"Resultado: **{status}**", "", "```text", cortar(texto), "```", ""]
        print(f"[{n}] {status}")
        destino.write_text("\n".join(partes), encoding="utf-8")
    partes.insert(7, "Resumo: " + " · ".join(f"{n}: {s}" for n, s in resumo) + "\n")
    destino.write_text("\n".join(partes), encoding="utf-8")
    (raiz / CARIMBO).write_text(json.dumps({"head": head, "etapas": nomes, "quando": agora, "arvore_limpa": not suja, "ensaio": ensaio}), encoding="utf-8")
    print(f"\nRelatorio unico: {RELATORIO.as_posix()}  (envie este arquivo para conferir)")
    print("Nada foi alterado no repositorio." + ("" if ok_todas else " ATENCAO: ha etapa com erro; leia o relatorio."))
    return 0 if ok_todas else 2


def cmd_aplicar(raiz: Path, nomes: list[str], args) -> int:
    sem_aplicar = [n for n in nomes if ETAPAS[n][2] is None]
    if sem_aplicar:
        print(f"Estas etapas nao aplicam sozinhas: {', '.join(sem_aplicar)}. Tire-as da lista.")
        return 1
    head = git(raiz, "rev-parse", "HEAD")
    suja = git(raiz, "status", "--porcelain", "--untracked-files=no")
    if suja and not args.forcar:
        print("PARADO: ha mudancas nao commitadas (o git nao poderia desfazer so o lote). Faca commit e gere o relatorio de novo.")
        return 1
    if not args.forcar:
        carimbo = raiz / CARIMBO
        if not carimbo.is_file():
            print("PARADO: nao ha relatorio anterior. Rode primeiro: relatorio --etapas ...")
            return 1
        c = json.loads(carimbo.read_text(encoding="utf-8"))
        if c.get("ensaio"):
            print("PARADO: o ultimo relatorio foi de ENSAIO (so para treinar). Gere um relatorio normal (sem --ensaio) e envie para conferir.")
            return 1
        if c.get("head") != head:
            print("PARADO: o commit mudou depois do relatorio. Gere o relatorio de novo e envie para conferir.")
            return 1
        nao_vistas = [n for n in nomes if n not in c.get("etapas", [])]
        if nao_vistas:
            print(f"PARADO: estas etapas nao estavam no relatorio: {', '.join(nao_vistas)}.")
            return 1
    ordem = [n for n in ORDEM_APLICAR if n in nomes]
    log = [f"# Lote aplicado em {datetime.now(timezone.utc):%Y-%m-%d %H:%M UTC}", f"commit de partida: `{head[:10]}`", ""]
    for n in ordem:
        script, _, a_ap, _ = ETAPAS[n]
        print(f"[{n}] aplicando...")
        cod, texto = rodar(raiz, script, a_ap)
        log += [f"## {n}", "```text", cortar(texto, 80, 20), "```", ""]
        if cod != 0:
            print(texto[-1500:])
            print(f"\nPARADO em '{n}' (codigo {cod}). As etapas seguintes NAO rodaram. Para desfazer o que ja gravou: git checkout -- .")
            (raiz / "outputs" / "final").mkdir(parents=True, exist_ok=True)
            (raiz / "outputs" / "final" / "lote_aplicado.md").write_text("\n".join(log), encoding="utf-8")
            return 2
        print(f"[{n}] ok")
    if not args.sem_testes and (MUDAM_CODIGO & set(ordem) or args.pytest):
        print("Rodando pytest...")
        r = subprocess.run([sys.executable, "-m", "pytest", "-q", "-x"], cwd=raiz, capture_output=True, text=True)
        ultima = (r.stdout.strip().splitlines() or [""])[-1]
        log += ["## pytest", "```text", ultima, "```", ""]
        print("pytest:", "OK" if r.returncode == 0 else "FALHOU", "|", ultima)
        if r.returncode != 0:
            print("Os testes falharam depois do lote. Desfaca com: git checkout -- .   (arquivos movidos por 'renomear' ficam em outputs/_antigo)")
            return 3
    stat = git(raiz, "diff", "--stat")
    log += ["## git diff --stat", "```text", stat[-1500:], "```"]
    (raiz / "outputs" / "final").mkdir(parents=True, exist_ok=True)
    (raiz / "outputs" / "final" / "lote_aplicado.md").write_text("\n".join(log), encoding="utf-8")
    print("\n" + "\n".join(stat.splitlines()[-6:]))
    print("\nLote aplicado. Confira e faca o commit. Para desfazer antes do commit: git checkout -- .")
    return 0


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("acao", choices=["listar", "relatorio", "aplicar"])
    ap.add_argument("--raiz", type=Path, default=Path.cwd())
    ap.add_argument("--lote", choices=sorted(LOTES))
    ap.add_argument("--etapas", help="lista separada por virgula")
    ap.add_argument("--ensaio", action="store_true", help="no relatorio: roda calibracao, tabelas, curva e blocos com as previsoes do ensaio")
    ap.add_argument("--forcar", action="store_true", help="ignora o carimbo e a arvore limpa (nao recomendado)")
    ap.add_argument("--sem-testes", action="store_true")
    ap.add_argument("--pytest", action="store_true", help="roda o pytest mesmo se so houver etapas que nao mudam codigo")
    args = ap.parse_args()
    if args.acao == "listar":
        return cmd_listar()
    raiz = args.raiz.resolve()
    if not (raiz / "src").is_dir():
        print(f"ABORTADO: {raiz} nao parece a raiz do projeto.")
        return 1
    nomes = escolher(args)
    return cmd_relatorio(raiz, nomes, args.ensaio) if args.acao == "relatorio" else cmd_aplicar(raiz, nomes, args)


if __name__ == "__main__":
    sys.exit(main())
