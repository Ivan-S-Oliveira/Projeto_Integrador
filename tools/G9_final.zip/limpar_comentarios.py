#!/usr/bin/env python3
r"""Remove comentarios do projeto. Primeiro gera o relatorio numa copia; so grava com --aplicar.

Uso (na raiz do repositorio, com o venv do projeto):  [antes: $env:PYTHONPATH = "tools\G9_final.zip"]
    .\.venv\Scripts\python.exe -m limpar_comentarios                  (relatorio, nada muda)
    .\.venv\Scripts\python.exe -m limpar_comentarios --pytest         (relatorio + pytest na copia)
    .\.venv\Scripts\python.exe -m limpar_comentarios --aplicar        (grava no repositorio)
    .\.venv\Scripts\python.exe -m limpar_comentarios --docstrings manter

O que faz:
    .py (src, tests, tools): tira os comentarios # e deixa so a primeira frase de cada docstring.
    .ipynb (notebooks): o mesmo, so nas celulas de codigo. Saidas e celulas Markdown nao mudam.
    .yaml (configs): tira os comentarios, sem mexer nos textos de blocos (>- e |).
Mantem: shebang, cookie de codificacao, # noqa, # type:, # pragma, # fmt:, # pylint, # ruff, # mypy.
Cada arquivo e conferido (mesma arvore de codigo, mesmo YAML, JSON valido). Se falhar, fica como estava.
"""
from __future__ import annotations

import argparse
import ast
import difflib
import io
import json
import re
import shutil
import subprocess
import sys
import tempfile
import tokenize
from pathlib import Path

MANTER = re.compile(r"^#\s*(noqa|type:|pragma|fmt:|pylint|ruff|mypy|-\*-)", re.I)
COOKIE = re.compile(r"coding[:=]\s*[-\w.]+")
MAGICA = re.compile(r"^(\s*)([%!].*)$")
PADROES = ("src/", "tests/", "tools/", "notebooks/", "configs/")
LIMITE_DOC = 140


def arquivos_do_projeto(raiz: Path) -> list[Path]:
    try:
        saida = subprocess.run(["git", "ls-files"], cwd=raiz, capture_output=True, text=True, check=True).stdout
        lista = [raiz / p for p in saida.splitlines() if p]
    except (OSError, subprocess.CalledProcessError):
        lista = [p for p in raiz.rglob("*") if p.is_file() and ".venv" not in p.parts]
    escolhidos = []
    for p in lista:
        rel = p.relative_to(raiz).as_posix()
        if not rel.startswith(PADROES):
            continue
        if p.suffix in (".py", ".ipynb", ".yaml", ".yml") and p.is_file():
            escolhidos.append(p)
    return sorted(escolhidos)


def primeira_frase(doc: str) -> str:
    limpo = " ".join(doc.strip().split("\n\n")[0].split())
    corte = re.search(r"[.!?](\s|$)", limpo)
    if corte:
        limpo = limpo[: corte.end()].strip()
    if len(limpo) > LIMITE_DOC:
        limpo = limpo[:LIMITE_DOC].rsplit(" ", 1)[0].rstrip(",;:") + "."
    return limpo


def encurtar_docstrings(texto: str) -> tuple[str, int]:
    arvore = ast.parse(texto)
    linhas = texto.splitlines(keepends=True)
    alvos = []
    for no in ast.walk(arvore):
        if isinstance(no, (ast.Module, ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            corpo = no.body
            if corpo and isinstance(corpo[0], ast.Expr) and isinstance(corpo[0].value, ast.Constant) and isinstance(corpo[0].value.value, str):
                alvos.append(corpo[0])
    mudou = 0
    for expr in sorted(alvos, key=lambda e: e.lineno, reverse=True):
        ini, fim = expr.lineno - 1, expr.end_lineno
        bloco = "".join(linhas[ini:fim])
        original = expr.value.value
        novo = primeira_frase(original)
        if not novo or novo == " ".join(original.split()) or "\\" in novo or '"' in novo:
            continue
        indent = linhas[ini][: len(linhas[ini]) - len(linhas[ini].lstrip())]
        if not re.match(r'^\s*[rRuU]?("""|\'\'\')', bloco) or not re.search(r'("""|\'\'\')\s*$', bloco.rstrip("\r\n")):
            continue
        eol = "\r\n" if linhas[ini].endswith("\r\n") else "\n"
        linhas[ini:fim] = [f'{indent}"""{novo}"""{eol}']
        mudou += 1
    return "".join(linhas), mudou


def tirar_comentarios_py(texto: str) -> tuple[str, int]:
    linhas = texto.splitlines(keepends=True)
    removidos = 0
    comentarios = []
    for tok in tokenize.generate_tokens(io.StringIO(texto).readline):
        if tok.type == tokenize.COMMENT:
            comentarios.append(tok)
    for tok in sorted(comentarios, key=lambda t: t.start, reverse=True):
        lin, col = tok.start
        if lin <= 2 and (tok.string.startswith("#!") or COOKIE.search(tok.string)):
            continue
        if MANTER.match(tok.string):
            continue
        original = linhas[lin - 1]
        antes = original[:col]
        eol = original[len(original.rstrip("\r\n")):]
        removidos += 1
        if antes.strip() == "":
            linhas[lin - 1] = None
        else:
            linhas[lin - 1] = antes.rstrip() + eol
    saida = "".join(l for l in linhas if l is not None)
    saida = re.sub(r"\n{4,}", "\n\n\n", saida)
    return saida, removidos


def arvore_sem_docstrings(texto: str) -> str:
    arvore = ast.parse(texto)
    for no in ast.walk(arvore):
        if isinstance(no, (ast.Module, ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            corpo = no.body
            if corpo and isinstance(corpo[0], ast.Expr) and isinstance(corpo[0].value, ast.Constant) and isinstance(corpo[0].value.value, str):
                corpo[0].value.value = ""
    return ast.dump(arvore)


def processar_py(texto: str, docstrings: str) -> tuple[str, dict]:
    novo, n_com = tirar_comentarios_py(texto)
    n_doc = 0
    if docstrings == "primeira-linha":
        novo, n_doc = encurtar_docstrings(novo)
    if arvore_sem_docstrings(texto) != arvore_sem_docstrings(novo):
        raise ValueError("a arvore do codigo mudou")
    return novo, {"comentarios": n_com, "docstrings": n_doc}


def processar_celula(fonte: str, docstrings: str) -> tuple[str, dict]:
    mascaras: dict[str, str] = {}
    linhas = []
    for i, ln in enumerate(fonte.split("\n")):
        m = MAGICA.match(ln)
        if m:
            chave = f"__magica_{i}__"
            mascaras[chave] = ln
            linhas.append(f"{m.group(1)}{chave} = 0")
        else:
            linhas.append(ln)
    mascarado = "\n".join(linhas)
    novo, info = processar_py(mascarado, docstrings)
    for chave, original in mascaras.items():
        m = re.search(rf"^(\s*){re.escape(chave)} = 0$", novo, re.M)
        if m:
            novo = novo.replace(m.group(0), original, 1)
    return novo.rstrip("\n"), info


def ler_json_formato(bruto: str):
    dados = json.loads(bruto)
    for sort in (True, False):
        for indent in (1, 2):
            if json.dumps(dados, indent=indent, ensure_ascii=False, sort_keys=sort) + "\n" == bruto:
                return dados, indent, sort
    return dados, 1, True


def processar_ipynb(bruto: str, docstrings: str) -> tuple[str, dict]:
    dados, indent, sort = ler_json_formato(bruto)
    total = {"comentarios": 0, "docstrings": 0, "celulas_vazias": 0, "celulas_puladas": 0}
    novas = []
    for celula in dados.get("cells", []):
        if celula.get("cell_type") != "code":
            novas.append(celula)
            continue
        fonte = celula["source"] if isinstance(celula["source"], str) else "".join(celula["source"])
        try:
            novo, info = processar_py(fonte, docstrings)
            novo = novo.rstrip("\n")
        except (SyntaxError, ValueError, tokenize.TokenError, IndentationError):
            try:
                novo, info = processar_celula(fonte, docstrings)
            except (SyntaxError, ValueError, tokenize.TokenError, IndentationError):
                total["celulas_puladas"] += 1
                novas.append(celula)
                continue
        total["comentarios"] += info["comentarios"]
        total["docstrings"] += info["docstrings"]
        if novo.strip() == "" and fonte.strip() != "":
            total["celulas_vazias"] += 1
            continue
        celula["source"] = novo.splitlines(keepends=True)
        novas.append(celula)
    dados["cells"] = novas
    return json.dumps(dados, indent=indent, ensure_ascii=False, sort_keys=sort) + "\n", total


def tirar_comentario_final(linha: str) -> str:
    aspas = None
    i = 0
    while i < len(linha):
        c = linha[i]
        if aspas:
            if c == aspas:
                if aspas == "'" and i + 1 < len(linha) and linha[i + 1] == "'":
                    i += 1
                else:
                    aspas = None
            elif c == "\\" and aspas == '"':
                i += 1
        elif c in ("'", '"'):
            aspas = c
        elif c == "#" and i > 0 and linha[i - 1] in " \t":
            return linha[:i].rstrip()
        i += 1
    return linha


def processar_yaml(texto: str) -> tuple[str, dict]:
    import yaml

    saida = []
    bloco = None
    removidos = 0
    for ln in texto.splitlines(keepends=True):
        corpo = ln.rstrip("\r\n")
        eol = ln[len(corpo):]
        indent = len(corpo) - len(corpo.lstrip(" "))
        if bloco is not None:
            if corpo.strip() == "" or indent > bloco:
                saida.append(ln)
                continue
            bloco = None
        if corpo.lstrip().startswith("#"):
            removidos += 1
            continue
        novo = tirar_comentario_final(corpo)
        if novo != corpo:
            removidos += 1
        if re.search(r":\s*[>|][+-]?\d?\s*$", novo) or re.match(r"^\s*-\s*[>|][+-]?\d?\s*$", novo):
            bloco = indent
        saida.append(novo + eol)
    novo_texto = re.sub(r"(\r?\n){3,}", "\n\n", "".join(saida)).lstrip("\r\n")
    if yaml.safe_load(texto) != yaml.safe_load(novo_texto):
        raise ValueError("o conteudo do YAML mudou")
    return novo_texto, {"comentarios": removidos}


def transformar(caminho: Path, docstrings: str) -> tuple[str, dict]:
    bruto = caminho.read_bytes().decode("utf-8")
    fim_crlf = "\r\n" in bruto
    texto = bruto.replace("\r\n", "\n") if fim_crlf else bruto
    if caminho.suffix == ".py":
        novo, info = processar_py(texto, docstrings)
    elif caminho.suffix == ".ipynb":
        novo, info = processar_ipynb(texto, docstrings)
        json.loads(novo)
    else:
        novo, info = processar_yaml(texto)
    if fim_crlf:
        novo = novo.replace("\n", "\r\n")
    return novo, info


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--raiz", type=Path, default=Path.cwd())
    ap.add_argument("--aplicar", action="store_true", help="grava no repositorio (sem isso so ha relatorio)")
    ap.add_argument("--docstrings", choices=("primeira-linha", "manter"), default="primeira-linha")
    ap.add_argument("--pytest", action="store_true", help="roda o pytest rapido na copia")
    ap.add_argument("--diff", help="mostra o diff de um arquivo (caminho relativo)")
    args = ap.parse_args()

    raiz = args.raiz.resolve()
    if not (raiz / "src").is_dir():
        print(f"ABORTADO: {raiz} nao parece a raiz do projeto (sem pasta src).")
        return 1

    arquivos = arquivos_do_projeto(raiz)
    copia = Path(tempfile.mkdtemp(prefix="limpeza_"))
    ok, falhas, linhas_rel = [], [], []
    tot = {"comentarios": 0, "docstrings": 0, "celulas_vazias": 0}
    for p in arquivos:
        rel = p.relative_to(raiz).as_posix()
        try:
            novo, info = transformar(p, args.docstrings)
        except Exception as exc:  # noqa: BLE001
            falhas.append((rel, f"{type(exc).__name__}: {exc}"))
            continue
        antigo = p.read_bytes().decode("utf-8")
        destino = copia / rel
        destino.parent.mkdir(parents=True, exist_ok=True)
        destino.write_bytes(novo.encode("utf-8"))
        if novo != antigo:
            ok.append(rel)
            for k in tot:
                tot[k] += info.get(k, 0)
            linhas_rel.append(f"{rel:60s} comentarios={info.get('comentarios', 0):4d} docstrings={info.get('docstrings', 0):3d}"
                              + (f" celulas_vazias={info['celulas_vazias']}" if info.get("celulas_vazias") else "")
                              + (f" puladas={info['celulas_puladas']}" if info.get("celulas_puladas") else ""))
        if args.diff and rel == args.diff:
            for l in difflib.unified_diff(antigo.splitlines(), novo.splitlines(), rel, rel + " (novo)", lineterm="", n=1):
                print(l)

    for p in copia.rglob("*.py"):
        try:
            compile(p.read_text(encoding="utf-8"), str(p), "exec")
        except SyntaxError as exc:
            falhas.append((p.relative_to(copia).as_posix(), f"SyntaxError: {exc}"))
            if p.relative_to(copia).as_posix() in ok:
                ok.remove(p.relative_to(copia).as_posix())

    print("=" * 78)
    print(f"RELATORIO (copia em {copia})")
    print("=" * 78)
    print("\n".join(linhas_rel) or "Nada para mudar.")
    print("-" * 78)
    print(f"arquivos que mudam: {len(ok)} | comentarios: {tot['comentarios']} | docstrings: {tot['docstrings']} | celulas vazias: {tot['celulas_vazias']}")
    for rel, motivo in falhas:
        print(f"PULADO {rel}: {motivo}")

    if args.pytest:
        espelho = Path(tempfile.mkdtemp(prefix="limpeza_pytest_"))
        try:
            saida = subprocess.run(["git", "ls-files"], cwd=raiz, capture_output=True, text=True, check=True).stdout.splitlines()
            for rel in saida:
                origem = raiz / rel
                if origem.is_file():
                    (espelho / rel).parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(origem, espelho / rel)
        except (OSError, subprocess.CalledProcessError):
            print("PYTEST: nao consegui montar a copia (git indisponivel).")
        for rel in ok:
            shutil.copy2(copia / rel, espelho / rel)
        r = subprocess.run([sys.executable, "-m", "pytest", "-q", "-x"], cwd=espelho, capture_output=True, text=True)
        print("PYTEST na copia:", "OK" if r.returncode == 0 else "FALHOU")
        print("\n".join(r.stdout.splitlines()[-8:]))
        if r.returncode != 0:
            print("Nada sera gravado.")
            return 2

    if not args.aplicar:
        print("Relatorio pronto. Nada foi gravado. Para gravar: rode de novo com --aplicar.")
        return 0

    for rel in ok:
        shutil.copy2(copia / rel, raiz / rel)
    print(f"GRAVADO: {len(ok)} arquivo(s). Rode o pytest e confira com: git diff --stat")
    return 0


if __name__ == "__main__":
    sys.exit(main())
