#!/usr/bin/env python3
r"""Insere comentarios curtos nos pontos criticos, a partir de uma lista JSON. Relatorio numa copia primeiro.

Uso (na raiz do repositorio, com o venv do projeto):  [antes: $env:PYTHONPATH = "tools\G9_final.zip"]
    .\.venv\Scripts\python.exe -m inserir_comentarios ..\comentarios.json              (relatorio)
    .\.venv\Scripts\python.exe -m inserir_comentarios ..\comentarios.json --aplicar    (grava)

Formato do JSON (uma lista):
    [{"arquivo": "src/dados.py", "ancora": "def criar_group_id(", "comentario": "Grupo = numero de notificacao."}]

Regras: a ancora precisa casar com UMA linha do arquivo (a linha, sem os espacos do comeco, comeca com a ancora).
Em notebooks vale so nas celulas de codigo, e a ancora precisa existir em UMA celula. O comentario entra
na linha de cima, com a mesma indentacao. Cada arquivo e conferido (mesma arvore de codigo; YAML igual).
"""
from __future__ import annotations

import argparse
import ast
import json
import shutil
import sys
import tempfile
from pathlib import Path


def inserir_em_texto(texto: str, ancora: str, comentario: str, sufixo: str) -> str:
    linhas = texto.split("\n")
    achadas = [i for i, ln in enumerate(linhas) if ln.strip().startswith(ancora.strip())]
    if len(achadas) != 1:
        raise ValueError(f"ancora {ancora!r} casa com {len(achadas)} linhas (precisa ser 1)")
    i = achadas[0]
    indent = linhas[i][: len(linhas[i]) - len(linhas[i].lstrip())]
    if i > 0 and linhas[i - 1].strip() == f"# {comentario}".strip():
        return texto
    linhas.insert(i, f"{indent}# {comentario}")
    return "\n".join(linhas)


def aplicar_arquivo(caminho: Path, itens: list[dict]) -> tuple[str, int]:
    bruto = caminho.read_bytes().decode("utf-8")
    crlf = "\r\n" in bruto
    texto = bruto.replace("\r\n", "\n")
    if caminho.suffix == ".ipynb":
        dados = json.loads(texto)
        celulas = [c for c in dados["cells"] if c.get("cell_type") == "code"]
        for it in itens:
            donas = []
            for c in celulas:
                fonte = c["source"] if isinstance(c["source"], str) else "".join(c["source"])
                if any(ln.strip().startswith(it["ancora"].strip()) for ln in fonte.split("\n")):
                    donas.append((c, fonte))
            if len(donas) != 1:
                raise ValueError(f"ancora {it['ancora']!r} aparece em {len(donas)} celulas (precisa ser 1)")
            c, fonte = donas[0]
            c["source"] = inserir_em_texto(fonte, it["ancora"], it["comentario"], ".py").splitlines(keepends=True)
        for sort in (True, False):
            if json.dumps(json.loads(texto), indent=1, ensure_ascii=False, sort_keys=sort) + "\n" == texto:
                novo = json.dumps(dados, indent=1, ensure_ascii=False, sort_keys=sort) + "\n"
                break
        else:
            novo = json.dumps(dados, indent=1, ensure_ascii=False) + "\n"
    else:
        novo = texto
        for it in itens:
            novo = inserir_em_texto(novo, it["ancora"], it["comentario"], caminho.suffix)
        if caminho.suffix == ".py":
            if ast.dump(ast.parse(texto)) != ast.dump(ast.parse(novo)):
                raise ValueError("a arvore do codigo mudou")
        elif caminho.suffix in (".yaml", ".yml"):
            import yaml

            if yaml.safe_load(texto) != yaml.safe_load(novo):
                raise ValueError("o conteudo do YAML mudou")
    return (novo.replace("\n", "\r\n") if crlf else novo), len(itens)


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("lista", type=Path)
    ap.add_argument("--raiz", type=Path, default=Path.cwd())
    ap.add_argument("--aplicar", action="store_true")
    args = ap.parse_args()

    raiz = args.raiz.resolve()
    itens = json.loads(args.lista.read_text(encoding="utf-8"))
    por_arquivo: dict[str, list[dict]] = {}
    for it in itens:
        for chave in ("arquivo", "ancora", "comentario"):
            if not it.get(chave):
                print(f"ABORTADO: item sem '{chave}': {it}")
                return 1
        if len(it["comentario"]) > 120:
            print(f"AVISO: comentario longo ({len(it['comentario'])} caracteres): {it['comentario'][:60]}...")
        por_arquivo.setdefault(it["arquivo"], []).append(it)

    copia = Path(tempfile.mkdtemp(prefix="comentarios_"))
    ok, falhas = [], []
    for rel, lista in por_arquivo.items():
        caminho = raiz / rel
        if not caminho.is_file():
            falhas.append((rel, "arquivo nao existe"))
            continue
        try:
            novo, n = aplicar_arquivo(caminho, lista)
        except Exception as exc:  # noqa: BLE001
            falhas.append((rel, f"{type(exc).__name__}: {exc}"))
            continue
        destino = copia / rel
        destino.parent.mkdir(parents=True, exist_ok=True)
        destino.write_bytes(novo.encode("utf-8"))
        ok.append((rel, n))

    print("=" * 78)
    print(f"RELATORIO (copia em {copia})")
    print("=" * 78)
    for rel, n in ok:
        print(f"{rel:60s} {n} comentario(s)")
    for rel, motivo in falhas:
        print(f"FALHOU {rel}: {motivo}")
    print("-" * 78)
    print(f"arquivos que mudam: {len(ok)} | comentarios: {sum(n for _, n in ok)} | falhas: {len(falhas)}")
    if not args.aplicar:
        print("Relatorio pronto. Nada foi gravado. Para gravar: rode de novo com --aplicar.")
        return 0
    if falhas:
        print("Ha falhas: corrija a lista antes de aplicar.")
        return 2
    for rel, _ in ok:
        shutil.copy2(copia / rel, raiz / rel)
    print(f"GRAVADO: {len(ok)} arquivo(s).")
    return 0


if __name__ == "__main__":
    sys.exit(main())
