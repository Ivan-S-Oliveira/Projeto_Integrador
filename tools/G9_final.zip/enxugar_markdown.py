#!/usr/bin/env python3
r"""Ajuda a enxugar as celulas Markdown dos notebooks: lista as candidatas e aplica os textos novos.

Uso (na raiz do repositorio, com o venv do projeto):  [antes: $env:PYTHONPATH = "tools\G9_final.zip"]
    .\.venv\Scripts\python.exe -m enxugar_markdown                              (relatorio + lista JSON de candidatas)
    .\.venv\Scripts\python.exe -m enxugar_markdown --aplicar-json ..\novos.json (relatorio do que mudaria)
    .\.venv\Scripts\python.exe -m enxugar_markdown --aplicar-json ..\novos.json --aplicar

1) O relatorio mostra, por notebook, quantas celulas Markdown existem, o tamanho total e as candidatas:
   celulas longas (mais de --limite caracteres) ou com marcas antigas (C_16, B_04, #142, "item #5", val_tune...).
   Grava outputs/final/markdown_candidatos.json (arquivo, id da celula, motivos e texto atual).
2) Uma pessoa ou uma IA devolve um JSON: [{"arquivo": "notebooks/10_calibracao_limiar.ipynb", "id": "8394e5d7", "texto_novo": "..."}].
3) --aplicar-json confere cada item (a celula existe e e Markdown) e, com --aplicar, troca so o texto. Codigo e saidas nao mudam.
"""
from __future__ import annotations

import argparse
import json
import re
import shutil
import sys
import tempfile
from pathlib import Path

MARCAS = re.compile(r"\bC_\d{1,2}\b|\bB_\d{2}\b|\bA_\d{2}\b|#\d{2,3}\b|item #|Notebook 0\d|val_tune|provis[óo]ri|Fase E|§\s?\d+(\.\d+)?|\bC[2-6]\b")


def ler(caminho: Path):
    bruto = caminho.read_bytes().decode("utf-8")
    dados = json.loads(bruto)
    for sort in (True, False):
        if json.dumps(dados, indent=1, ensure_ascii=False, sort_keys=sort) + "\n" == bruto:
            return dados, sort
    return dados, False


def gravar(dados, sort: bool) -> str:
    return json.dumps(dados, indent=1, ensure_ascii=False, sort_keys=sort) + "\n"


def texto_da(celula) -> str:
    fonte = celula["source"]
    return fonte if isinstance(fonte, str) else "".join(fonte)


def notebooks(raiz: Path) -> list[Path]:
    return sorted((raiz / "notebooks").glob("*.ipynb"))


def relatorio(raiz: Path, limite: int) -> int:
    candidatas = []
    print(f"{'notebook':44s} {'md':>4s} {'chars':>8s} {'candidatas':>11s}")
    for nb in notebooks(raiz):
        try:
            dados, _ = ler(nb)
        except (ValueError, UnicodeDecodeError) as exc:
            print(f"PULADO {nb.name}: nao e JSON de notebook ({type(exc).__name__})")
            continue
        md = [c for c in dados["cells"] if c["cell_type"] == "markdown"]
        n_cand = 0
        for c in md:
            t = texto_da(c)
            motivos = []
            if len(t) > limite:
                motivos.append(f"longa ({len(t)} caracteres)")
            achados = sorted(set(m.group(0) for m in MARCAS.finditer(t)))
            if achados:
                motivos.append("marcas antigas: " + ", ".join(achados[:6]))
            if motivos:
                n_cand += 1
                candidatas.append({"arquivo": nb.relative_to(raiz).as_posix(), "id": c.get("id"), "chars": len(t), "motivos": motivos, "texto_atual": t})
        print(f"{nb.name:44s} {len(md):4d} {sum(len(texto_da(c)) for c in md):8d} {n_cand:11d}")
    destino = raiz / "outputs" / "final"
    destino.mkdir(parents=True, exist_ok=True)
    (destino / "markdown_candidatos.json").write_text(json.dumps(candidatas, indent=1, ensure_ascii=False), encoding="utf-8")
    print("-" * 78)
    print(f"candidatas: {len(candidatas)} -> outputs/final/markdown_candidatos.json (entregue esse arquivo para a IA)")
    return 0


def aplicar(raiz: Path, lista: Path, gravar_de_verdade: bool) -> int:
    itens = json.loads(lista.read_text(encoding="utf-8"))
    por_arquivo: dict[str, list[dict]] = {}
    for it in itens:
        for chave in ("arquivo", "id", "texto_novo"):
            if not it.get(chave):
                print(f"ABORTADO: item sem '{chave}': {str(it)[:100]}")
                return 1
        por_arquivo.setdefault(it["arquivo"], []).append(it)

    copia = Path(tempfile.mkdtemp(prefix="markdown_"))
    ok, falhas, avisos = [], [], []
    antes = depois = 0
    for rel, lista_it in por_arquivo.items():
        caminho = raiz / rel
        if not caminho.is_file():
            falhas.append((rel, "arquivo nao existe"))
            continue
        try:
            dados, sort = ler(caminho)
        except (ValueError, UnicodeDecodeError) as exc:
            falhas.append((rel, f"nao e JSON de notebook ({type(exc).__name__})"))
            continue
        por_id = {c.get("id"): c for c in dados["cells"]}
        erro = None
        for it in lista_it:
            c = por_id.get(it["id"])
            if c is None or c["cell_type"] != "markdown":
                erro = f"celula {it['id']!r} nao existe ou nao e Markdown"
                break
            t_antigo, t_novo = texto_da(c), it["texto_novo"].rstrip("\n")
            antes += len(t_antigo)
            depois += len(t_novo)
            if len(t_novo) > len(t_antigo):
                avisos.append(f"{rel} {it['id']}: texto novo MAIOR ({len(t_antigo)} -> {len(t_novo)})")
            if MARCAS.search(t_novo):
                avisos.append(f"{rel} {it['id']}: ainda tem marca antiga: {sorted(set(m.group(0) for m in MARCAS.finditer(t_novo)))[:4]}")
            c["source"] = t_novo.splitlines(keepends=True)
        if erro:
            falhas.append((rel, erro))
            continue
        saida = gravar(dados, sort)
        json.loads(saida)
        destino = copia / rel
        destino.parent.mkdir(parents=True, exist_ok=True)
        destino.write_bytes(saida.encode("utf-8"))
        ok.append((rel, len(lista_it)))

    print("=" * 78)
    print(f"RELATORIO (copia em {copia})")
    print("=" * 78)
    for rel, n in ok:
        print(f"{rel:60s} {n} celula(s)")
    for rel, motivo in falhas:
        print(f"FALHOU {rel}: {motivo}")
    for a in avisos:
        print("AVISO", a)
    print("-" * 78)
    print(f"celulas trocadas: {sum(n for _, n in ok)} | caracteres: {antes} -> {depois} | falhas: {len(falhas)}")
    if not gravar_de_verdade:
        print("Relatorio pronto. Nada foi gravado. Para gravar: rode de novo com --aplicar.")
        return 0
    if falhas:
        print("Ha falhas: corrija o JSON antes de aplicar.")
        return 2
    for rel, _ in ok:
        shutil.copy2(copia / rel, raiz / rel)
    print(f"GRAVADO: {len(ok)} notebook(s). Codigo e saidas nao mudaram.")
    return 0


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--raiz", type=Path, default=Path.cwd())
    ap.add_argument("--limite", type=int, default=500)
    ap.add_argument("--aplicar-json", type=Path)
    ap.add_argument("--aplicar", action="store_true")
    args = ap.parse_args()
    raiz = args.raiz.resolve()
    if not (raiz / "notebooks").is_dir():
        print(f"ABORTADO: {raiz} nao parece a raiz do projeto (sem pasta notebooks).")
        return 1
    if args.aplicar_json:
        return aplicar(raiz, args.aplicar_json, args.aplicar)
    return relatorio(raiz, args.limite)


if __name__ == "__main__":
    sys.exit(main())
