#!/usr/bin/env python3
r"""Checklist do G9: confere tudo o que precisa estar certo ANTES de abrir o teste. So le; nunca altera o projeto.

Uso (na raiz do repositorio, com o venv do projeto):  [antes: $env:PYTHONPATH = "tools\G9_final.zip"]
    .\.venv\Scripts\python.exe -m checklist_g9
    .\.venv\Scripts\python.exe -m checklist_g9 --com-testes
    .\.venv\Scripts\python.exe -m checklist_g9 --depois          (confere o estado depois da abertura)

Sai com codigo 0 se nao houver FALHA. AVISO nao bloqueia, mas precisa de uma decisao sua.
Grava o resultado em outputs/final/checklist_g9.md (pasta ignorada pelo Git).
"""
from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

OK, AVISO, FALHA = "OK", "AVISO", "FALHA"
ALIASES = {"hist_gradient_boosting": "boosting"}


def git(raiz: Path, *args: str) -> str | None:
    try:
        r = subprocess.run(["git", *args], cwd=raiz, capture_output=True, text=True, timeout=60)
    except (OSError, subprocess.TimeoutExpired):
        return None
    return r.stdout.strip() if r.returncode == 0 else None


def mais_recente(pasta: Path, *padroes: str, filtro=None) -> Path | None:
    achados = []
    for padrao in padroes:
        achados += list(pasta.glob(padrao))
    if filtro:
        achados = [p for p in achados if filtro(p)]
    return max(achados, key=lambda p: p.stat().st_mtime) if achados else None


def ler_json(caminho: Path | None) -> dict:
    if caminho is None:
        return {}
    try:
        return json.loads(caminho.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--raiz", type=Path, default=Path.cwd())
    ap.add_argument("--com-testes", action="store_true", help="roda o pytest rapido (alguns minutos)")
    ap.add_argument("--depois", action="store_true", help="modo pos-abertura: confere o registro do G9")
    ap.add_argument("--n-features", type=int, default=30)
    ap.add_argument("--ram-gb", type=float, default=14.0)
    args = ap.parse_args()

    raiz = args.raiz.resolve()
    linhas: list[tuple[str, str, str]] = []

    def reg(status: str, titulo: str, detalhe: str = "") -> None:
        linhas.append((status, titulo, detalhe))

    if not (raiz / "configs" / "supervised.yaml").is_file():
        print(f"ABORTADO: {raiz} nao parece a raiz do projeto.")
        return 1
    import yaml

    cfg = yaml.safe_load((raiz / "configs" / "supervised.yaml").read_text(encoding="utf-8"))
    tabelas = raiz / "outputs" / "tables"

    sujo = git(raiz, "status", "--porcelain", "--untracked-files=no")
    ramo = git(raiz, "rev-parse", "--abbrev-ref", "HEAD")
    commit = git(raiz, "rev-parse", "--short", "HEAD")
    if sujo is None:
        reg(AVISO, "Git", "nao consegui consultar o Git")
    else:
        reg(OK if sujo == "" else FALHA, f"Arvore Git limpa (ramo {ramo}, commit {commit})",
            "" if sujo == "" else "arquivos rastreados modificados: " + ", ".join(l[3:] for l in sujo.splitlines()[:6]))
        a_frente = git(raiz, "rev-list", "--left-right", "--count", "HEAD...@{u}")
        if a_frente is None:
            reg(AVISO, "Commit publicado", "ramo sem upstream: confira o push")
        else:
            adiante, atras = (int(x) for x in a_frente.split())
            reg(OK if adiante == 0 and atras == 0 else AVISO, "Commit publicado e atualizado", f"a frente={adiante} atras={atras}")

    gates = cfg.get("gates") or {}
    if args.depois:
        g9 = gates.get("G9_holdout") or {}
        reg(OK if g9.get("status") == "executado" else FALHA, "G9 marcado como executado", f"status={g9.get('status')}")
        reg(OK if g9.get("n_acessos") == 1 else FALHA, "Teste aberto exatamente uma vez", f"n_acessos={g9.get('n_acessos')}")
        reg(OK if g9.get("executado_em") else FALHA, "Data da abertura registrada", str(g9.get("executado_em")))
        art = ler_json(raiz / "data" / "analytical" / "manifesto_supervisionado.json")
        reg(OK if art.get("test_opened") is True else FALHA, "test_opened no manifesto do artefato", str(art.get("test_opened_utc")))
        reais = [p for p in tabelas.glob("*validacao_final_*_manifesto.json") if "ensaio" not in p.name.lower() and "ENSAIO" not in p.name]
        reg(OK if len(reais) == 1 else FALHA, "Um unico manifesto real do notebook 11", ", ".join(p.name for p in reais) or "nenhum")
        preds = list((raiz / "outputs" / "predictions").glob("*validacao_final_*_predicoes_teste.*")) if (raiz / "outputs" / "predictions").is_dir() else []
        reg(OK if preds else FALHA, "Previsoes do teste gravadas", ", ".join(p.name for p in preds[:3]))
        _imprimir(linhas, raiz)
        return 1 if any(s == FALHA for s, _, _ in linhas) else 0

    for g in ("G6_finalistas_tuning", "G7_calibracao", "G8_limiar"):
        st = (gates.get(g) or {}).get("status")
        reg(OK if st == "aprovado" else FALHA, f"{g} aprovado", f"status={st}")
    g9 = gates.get("G9_holdout") or {}
    reg(OK if g9.get("status") in ("pendente", "aprovado") and not g9.get("executado_em") and (g9.get("n_acessos") or 0) == 0 else FALHA,
        "G9 ainda nao executado", f"status={g9.get('status')} n_acessos={g9.get('n_acessos')} executado_em={g9.get('executado_em')}")

    final = (cfg.get("features") or {}).get("final") or []
    reg(OK if len(final) == args.n_features else FALHA, f"features.final com {args.n_features} variaveis", f"tem {len(final)}")
    proibidas = set((cfg.get("features") or {}).get("proibidas") or [])
    reg(OK if not (set(final) & proibidas) else FALHA, "Nenhuma variavel proibida no modelo", ", ".join(sorted(set(final) & proibidas)))
    sel = cfg.get("selecao_modelos") or {}
    cal = cfg.get("calibracao") or {}
    lim = cfg.get("limiar") or {}
    reg(OK if sel.get("finalista_escolhido") else FALHA, "Finalista escolhido", str(sel.get("finalista_escolhido")))
    reg(OK if cal.get("ativa") and cal.get("metodo") else FALHA, "Calibracao definida", f"ativa={cal.get('ativa')} metodo={cal.get('metodo')}")
    reg(OK if lim.get("otimo") is not None else FALHA, "Limiar definido", f"otimo={lim.get('otimo')} metrica={lim.get('metrica')} min_recall={lim.get('min_recall')}")
    grupos = (cfg.get("avaliacao") or {}).get("grupos") or []
    reg(OK if {"cs_raca", "cs_zona"} <= set(grupos) else AVISO, "Grupos de equidade (raca/cor e zona)", ", ".join(grupos))

    art = ler_json(raiz / "data" / "analytical" / "manifesto_supervisionado.json")
    reg(OK if art and art.get("test_opened") is False else FALHA, "Artefato com test_opened = false", f"test_opened={art.get('test_opened')}")
    contagens = art.get("partition_counts") or {}
    reg(OK if contagens else AVISO, "Contagens por bloco registradas", ", ".join(f"{k}={v:,}" for k, v in contagens.items()))

    m10 = mais_recente(tabelas, "10_calibracao_limiar_*_manifesto.json", "C5_calibracao_limiar_*_manifesto.json") if tabelas.is_dir() else None
    d10 = ler_json(m10)
    if not d10:
        reg(FALHA, "Manifesto do notebook 10 encontrado", "rode o notebook 10")
    else:
        reg(OK, "Manifesto do notebook 10 encontrado", m10.name)
        reg(OK if d10.get("dataset_sha256") == art.get("dataset_sha256") else FALHA, "Notebook 10 usou o artefato atual", f"{str(d10.get('dataset_sha256'))[:12]} x {str(art.get('dataset_sha256'))[:12]}")
        reg(OK if set(d10.get("feature_columns") or []) == set(final) else FALHA, "Notebook 10 usou as mesmas variaveis do YAML")
        escolhas = d10.get("escolhas") or {}
        achado = None
        for nome, e in escolhas.items():
            if ALIASES.get(nome, nome) == ALIASES.get(sel.get("finalista_escolhido"), sel.get("finalista_escolhido")):
                achado = e
        reg(OK if achado and achado.get("metodo") == cal.get("metodo") else FALHA, "Metodo de calibracao do notebook 10 = YAML", str((achado or {}).get("metodo")))
        reg(OK if achado and lim.get("otimo") is not None and abs(float(achado.get("limiar")) - float(lim["otimo"])) < 1e-6 else FALHA,
            "Limiar do notebook 10 = limiar.otimo do YAML", f"{(achado or {}).get('limiar')} x {lim.get('otimo')}")
        carga = {"models": cfg.get("models"), "features": sorted(final), "finalista": ALIASES.get(sel.get("finalista_escolhido"), sel.get("finalista_escolhido"))}
        hash_agora = hashlib.sha256(json.dumps(carga, sort_keys=True, default=str).encode("utf-8")).hexdigest()[:16]
        reg(OK if d10.get("config_modelo_hash") == hash_agora else FALHA, "Hash dos modelos do notebook 10 = YAML atual", f"{d10.get('config_modelo_hash')} x {hash_agora}")
        reg(OK if d10.get("honest_calib_split") else AVISO, "Calibracao em metade separada da validacao")
        reg(OK if d10.get("g8_status") == "aprovado" else AVISO, "Manifesto do 10 registra G8 aprovado", f"g8_status={d10.get('g8_status')} (rode o 10 de novo apos aprovar, se quiser o registro limpo)")

    reais = [p for p in tabelas.glob("*validacao_final_*_manifesto.json") if "ensaio" not in p.name.lower()] if tabelas.is_dir() else []
    reg(OK if not reais else FALHA, "Nenhum manifesto real do notebook 11 (teste ainda fechado)", ", ".join(p.name for p in reais))

    ens = mais_recente(tabelas, "*ensaio_validacao_final_*_manifesto.json", "C6ENSAIO_*_manifesto.json") if tabelas.is_dir() else None
    de = ler_json(ens)
    if not de:
        reg(FALHA, "Ensaio do notebook 11 feito", "rode com SRAG_ENSAIO=1")
    else:
        reg(OK if de.get("ensaio") is True and de.get("test_opened") is False else FALHA, "Ensaio sem abrir o teste", ens.name)
        ultimo = git(raiz, "log", "-1", "--format=%ct", "--", "src", "notebooks/11_validacao_final.ipynb", "configs/supervised.yaml")
        quando = de.get("teste_aberto_em_utc")
        if ultimo and quando:
            t_ens = datetime.fromisoformat(quando).timestamp()
            reg(OK if t_ens >= float(ultimo) else FALHA, "Ensaio feito DEPOIS da ultima mudanca de codigo", f"ensaio {quando[:19]} | ultimo commit de codigo {datetime.fromtimestamp(float(ultimo), timezone.utc):%Y-%m-%d %H:%M}")
        pred_ens = mais_recente(raiz / "outputs" / "predictions", "*ensaio_validacao_final_*_predicoes_teste.*", "C6ENSAIO_*_predicoes_teste.*") if (raiz / "outputs" / "predictions").is_dir() else None
        if pred_ens is None:
            reg(FALHA, "Ensaio gravou o arquivo de previsoes", "sem ele o calibracao_pos_g9.py nao funciona depois do G9")
        else:
            try:
                import pandas as pd

                cols = set(pd.read_parquet(pred_ens).columns) if pred_ens.suffix == ".parquet" else set(pd.read_csv(pred_ens, nrows=5).columns)
                falta = {"bloco", "y_true", "y_prob", "ano_internacao", "regiao_residencia", "faixa_etaria"} - cols
                reg(OK if not falta else FALHA, "Previsoes do ensaio com as colunas que o pos-G9 usa", "faltam: " + ", ".join(sorted(falta)) if falta else pred_ens.name)
            except Exception as exc:  # noqa: BLE001
                reg(AVISO, "Previsoes do ensaio legiveis", repr(exc)[:80])
        nomes = [j.get("janela") for j in de.get("janelas") or []]
        reg(OK if {"teste_a", "teste_b", "pandemico_isolado"} <= set(nomes) else FALHA, "Ensaio gerou as tres janelas", ", ".join(map(str, nomes)))

    dec = raiz / "docs" / "decisoes.md"
    texto = dec.read_text(encoding="utf-8").lower() if dec.is_file() else ""
    reg(OK if "hipóteses registradas" in texto or "hipoteses registradas" in texto else FALHA, "Hipoteses do teste registradas em docs/decisoes.md")
    ultima_dec = git(raiz, "log", "-1", "--format=%h %cs", "--", "docs/decisoes.md")
    reg(OK if ultima_dec else AVISO, "decisoes.md esta no Git", str(ultima_dec))

    try:
        import psutil

        livre = psutil.virtual_memory().available / 1024 ** 3
        reg(OK if livre >= args.ram_gb else FALHA, f"Memoria livre >= {args.ram_gb:.0f} GB", f"{livre:.1f} GB livres (feche navegador, Teams e outros notebooks)")
    except ImportError:
        reg(AVISO, "Memoria livre", "psutil indisponivel")
    livre_disco = shutil.disk_usage(raiz).free / 1024 ** 3
    reg(OK if livre_disco >= 5 else FALHA, "Disco livre >= 5 GB", f"{livre_disco:.1f} GB")
    try:
        import sklearn.frozen  # noqa: F401

        reg(OK, "scikit-learn com FrozenEstimator (>= 1.6)")
    except ImportError:
        reg(FALHA, "scikit-learn com FrozenEstimator (>= 1.6)", "atualize o pacote")
    reg(OK if (raiz / "requirements-lock.txt").is_file() else AVISO, "requirements-lock.txt existe")

    if args.com_testes:
        r = subprocess.run([sys.executable, "-m", "pytest", "-q", "-x"], cwd=raiz, capture_output=True, text=True)
        reg(OK if r.returncode == 0 else FALHA, "pytest rapido", r.stdout.strip().splitlines()[-1] if r.stdout.strip() else "")

    _imprimir(linhas, raiz)
    return 1 if any(s == FALHA for s, _, _ in linhas) else 0


def _imprimir(linhas: list[tuple[str, str, str]], raiz: Path) -> None:
    marcas = {OK: "[ OK  ]", AVISO: "[AVISO]", FALHA: "[FALHA]"}
    saida = [f"{marcas[s]} {t}" + (f"  ->  {d}" if d else "") for s, t, d in linhas]
    print("\n".join(saida))
    n_f = sum(1 for s, _, _ in linhas if s == FALHA)
    n_a = sum(1 for s, _, _ in linhas if s == AVISO)
    resumo = f"{len(linhas) - n_f - n_a} ok, {n_a} aviso(s), {n_f} falha(s)"
    print("-" * 78)
    print(resumo + (" -> PODE APROVAR O G9" if n_f == 0 else " -> NAO APROVE O G9 AINDA"))
    destino = raiz / "outputs" / "final"
    destino.mkdir(parents=True, exist_ok=True)
    (destino / "checklist_g9.md").write_text("# Checklist G9\n\n" + "\n".join(f"- {l}" for l in saida) + f"\n\n{resumo}\n", encoding="utf-8")


if __name__ == "__main__":
    sys.exit(main())
