#!/usr/bin/env python3
r"""Curva de decisao (beneficio liquido) a partir das previsoes gravadas do teste. So le as previsoes; nao treina nada.

Uso (na raiz do repositorio, com o venv do projeto, DEPOIS do G9):  [antes: $env:PYTHONPATH = "tools\G9_final.zip"]
    .\.venv\Scripts\python.exe -m curva_decisao                  (relatorio: mostra a tabela e a faixa util, nada e gravado)
    .\.venv\Scripts\python.exe -m curva_decisao --aplicar        (grava outputs/final/curva_decisao.csv e a figura)

Janelas: Teste A = bloco test_ref; 2020-2022 = bloco test_pandemic. Beneficio liquido de um limiar t:
    BL(t) = VP/n - FP/n * t/(1-t)      (alertar todos: prev - (1-prev)*t/(1-t); ninguem: 0)
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import numpy as np
import pandas as pd

JANELAS = {"teste_a": ["test_ref"], "pandemico_2020_2022": ["test_pandemic"]}


def curva(y: np.ndarray, p: np.ndarray, limiares: np.ndarray) -> pd.DataFrame:
    n, prev = len(y), float(y.mean())
    linhas = []
    for t in limiares:
        alerta = p >= t
        vp = int((alerta & (y == 1)).sum())
        fp = int((alerta & (y == 0)).sum())
        peso = t / (1 - t)
        linhas.append({"limiar": round(float(t), 4), "bl_modelo": vp / n - fp / n * peso, "bl_todos": prev - (1 - prev) * peso,
                       "bl_nenhum": 0.0, "alertas_por_100": 100 * float(alerta.mean())})
    return pd.DataFrame(linhas)


def faixa_util(tab: pd.DataFrame) -> tuple[float, float] | None:
    ok = tab[(tab["bl_modelo"] > tab["bl_todos"]) & (tab["bl_modelo"] > 0)]
    return (float(ok["limiar"].min()), float(ok["limiar"].max())) if len(ok) else None


def achar_previsoes(raiz: Path, ensaio: bool = False) -> Path | None:
    pasta = raiz / "outputs" / "predictions"
    achados = [p for p in pasta.glob("*validacao_final_*_predicoes_teste.*") if ("ensaio" in p.name.lower()) == ensaio] if pasta.is_dir() else []
    return max(achados, key=lambda p: p.stat().st_mtime) if achados else None


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--raiz", type=Path, default=Path.cwd())
    ap.add_argument("--previsoes", type=Path, help="arquivo de previsoes (padrao: o mais recente do notebook 11)")
    ap.add_argument("--limiar", type=float, default=0.1178, help="limiar operacional para marcar na figura")
    ap.add_argument("--ensaio", action="store_true", help="usa as previsoes do ensaio (so para treinar; nao grava nada)")
    ap.add_argument("--aplicar", action="store_true")
    args = ap.parse_args()
    raiz = args.raiz.resolve()

    arq = args.previsoes or achar_previsoes(raiz, args.ensaio)
    if not arq or not arq.is_file():
        print("ABORTADO: nao achei o arquivo de previsoes do notebook 11. O G9 foi executado?")
        return 1
    df = pd.read_parquet(arq) if arq.suffix == ".parquet" else pd.read_csv(arq)
    limiares = np.round(np.arange(0.02, 0.4001, 0.01), 4)
    todas = []
    for nome, blocos in JANELAS.items():
        sub = df[df["bloco"].isin(blocos)]
        if sub.empty:
            print(f"AVISO: janela {nome} sem linhas (blocos {blocos}).")
            continue
        tab = curva(sub["y_true"].to_numpy(dtype=int), sub["y_prob"].to_numpy(dtype=float), limiares)
        tab.insert(0, "janela", nome)
        todas.append(tab)
        f = faixa_util(tab)
        linha = tab.iloc[(tab["limiar"] - args.limiar).abs().argmin()]
        print(f"{nome}: n={len(sub):,} | modelo melhor que 'alertar todos' e 'ninguem' entre t = "
              + (f"{f[0]:.2f} e {f[1]:.2f}" if f else "nenhuma faixa")
              + f" | no limiar {args.limiar:.4f}: BL modelo {linha['bl_modelo']:.4f} contra {linha['bl_todos']:.4f} (todos); {linha['alertas_por_100']:.1f} alertas por 100".replace(",", "."))
    if not todas:
        return 1
    saida = pd.concat(todas, ignore_index=True)
    if not args.aplicar or args.ensaio:
        print("Relatorio pronto. Nada foi gravado." + (" (ensaio: nunca grava)" if args.ensaio else " Para gravar: rode de novo com --aplicar."))
        return 0

    destino = raiz / "outputs" / "final"
    destino.mkdir(parents=True, exist_ok=True)
    saida.to_csv(destino / "curva_decisao.csv", index=False, encoding="utf-8-sig")
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fig, eixos = plt.subplots(1, len(todas), figsize=(6 * len(todas), 4), sharey=False)
    eixos = np.atleast_1d(eixos)
    for ax, tab in zip(eixos, todas):
        ax.plot(tab["limiar"], tab["bl_modelo"], label="modelo")
        ax.plot(tab["limiar"], tab["bl_todos"], label="alertar todos")
        ax.axhline(0, color="gray", lw=1, label="alertar ninguem")
        ax.axvline(args.limiar, color="red", ls="--", lw=1, label=f"limiar {args.limiar:.4f}")
        ax.set_title(tab["janela"].iloc[0])
        ax.set_xlabel("limiar de risco (t)")
        ax.set_ylabel("beneficio liquido")
        ax.legend()
    fig.tight_layout()
    fig_dir = raiz / "reports" / "figures"
    fig_dir.mkdir(parents=True, exist_ok=True)
    fig.savefig(fig_dir / "curva_decisao.png", dpi=150)
    print("GRAVADO: outputs/final/curva_decisao.csv e reports/figures/curva_decisao.png")
    return 0


if __name__ == "__main__":
    sys.exit(main())
