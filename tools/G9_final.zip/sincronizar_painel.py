#!/usr/bin/env python3
r"""Baixa PROJECT_STATUS_TEXT.md e PROJECT_STATUS.md das duas branches, compara card por card e monta a versao mais atualizada.

Uso (na raiz do repositorio; o zip em tools\G9_final.zip no PYTHONPATH (ver LEIA-ME)):
    .\.venv\Scripts\python.exe -m sincronizar_painel                       (RELATORIO: nada no repositorio e alterado)
    .\.venv\Scripts\python.exe -m sincronizar_painel --aplicar             (grava o compilado + aplica atualizar_painel.py)
    .\.venv\Scripts\python.exe -m sincronizar_painel --aplicar --publicar  (e publica nas duas branches, sem trocar de branch)

Pasta de saida (fora do repositorio): ..\painel_sync\
    PROJECT_STATUS_TEXT.main.md, PROJECT_STATUS_TEXT.enxugamento.md, PROJECT_STATUS_TEXT.local.md (e o mesmo para PROJECT_STATUS)
    PROJECT_STATUS_TEXT.compilado.md  -> mistura card a card
    relatorio_sync.md                 -> o que veio de onde

Como decide: para cada card, olha o historico do Git de cada branch e descobre QUANDO o texto atual do card chegou la.
Vence o texto que chegou por ultimo. Cards que so existem em uma branch entram. PROJECT_STATUS.md nao e misturado (so o painel o escreve): com --publicar, a branch mais antiga recebe uma COPIA do mais recente.
Nao usa o OneDrive: le tudo direto do Git (git fetch + git show).
"""
from __future__ import annotations

import argparse
import os
import re
import shutil
import subprocess
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path

TEXTO = "PROJECT_STATUS_TEXT.md"
ESTADO = "PROJECT_STATUS.md"
LIMITE_HIST = 80
AQUI = Path(__file__).resolve().parent
_ZIP = AQUI if AQUI.suffix.lower() == ".zip" else None


def _existe(nome: str) -> bool:
    # roda a partir do zip (sem descompactar): confere dentro do zip
    if _ZIP:
        import zipfile
        try:
            return f"{nome}.py" in zipfile.ZipFile(_ZIP).namelist()
        except OSError:
            return False
    return (AQUI / f"{nome}.py").is_file()


def _cmd(nome: str, *args: str) -> list[str]:
    # com o zip no PYTHONPATH (ver _env_zip), "-m nome" acha o modulo dentro dele
    if _ZIP:
        return [sys.executable, "-m", nome, *args]
    return [sys.executable, str(AQUI / f"{nome}.py"), *args]


def _env_zip(env: dict) -> dict:
    if not _ZIP:
        return env
    env = dict(env)
    atual = env.get("PYTHONPATH", "")
    env["PYTHONPATH"] = str(_ZIP) + (os.pathsep + atual if atual else "")
    return env


def git(raiz: Path, *args: str, env: dict | None = None, entrada: bytes | None = None) -> tuple[int, bytes]:
    e = {**os.environ, **(env or {})}
    r = subprocess.run(["git", *args], cwd=raiz, capture_output=True, input=entrada, env=e, timeout=300)
    return r.returncode, r.stdout + (r.stderr if r.returncode else b"")


def gtxt(raiz: Path, *args: str, **kw) -> tuple[int, str]:
    rc, out = git(raiz, *args, **kw)
    return rc, out.decode("utf-8", errors="replace").strip()


def achar_caminho(raiz: Path, ref: str, nome: str) -> str | None:
    rc, out = gtxt(raiz, "ls-tree", "-r", "--name-only", ref)
    if rc:
        return None
    cand = [p for p in out.splitlines() if p == nome or p.endswith("/" + nome)]
    return min(cand, key=len) if cand else None


def ler_blob(raiz: Path, ref: str, caminho: str) -> str | None:
    rc, out = git(raiz, "show", f"{ref}:{caminho}")
    return None if rc else out.decode("utf-8-sig", errors="replace").replace("\r\n", "\n")


def blocos(texto: str) -> dict[str, str]:
    linhas = texto.split("\n")
    cortes, cerca = [], False
    for i, ln in enumerate(linhas):
        if re.match(r"^\s*(```|~~~)", ln):
            cerca = not cerca
        if not cerca and ln.startswith("## "):
            cortes.append(i)
    saida: dict[str, str] = {}
    marcas = [0] + cortes + [len(linhas)]
    for k in range(len(marcas) - 1):
        a, b = marcas[k], marcas[k + 1]
        if k == 0:
            chave = "__topo__"
        else:
            m = re.match(r"^## (#\d+) · ", linhas[a])
            chave = m.group(1) if m else linhas[a][3:].strip()
        base, n = chave, 2
        while chave in saida:
            chave, n = f"{base}~{n}", n + 1
        saida[chave] = "\n".join(linhas[a:b]) + ("\n" if b < len(linhas) else "")
    return saida


def historico(raiz: Path, ref: str, caminho: str, atual: dict[str, str]) -> dict[str, tuple[int, bool]]:
    """chave -> (instante em que o texto atual do card chegou, se o limite do historico foi atingido)."""
    rc, out = gtxt(raiz, "log", f"-n{LIMITE_HIST}", "--format=%H %ct", ref, "--", caminho)
    commits = [ln.split() for ln in out.splitlines() if ln.strip()] if not rc else []
    chegou: dict[str, int] = {}
    aberto = set(atual)
    for h, ct in commits:
        t = ler_blob(raiz, h, caminho)
        if t is None:
            break
        b = blocos(t)
        for k in list(aberto):
            if k in b and b[k].rstrip() == atual[k].rstrip():
                chegou[k] = int(ct)
            else:
                aberto.discard(k)
        if not aberto:
            break
    limite = len(commits) >= LIMITE_HIST
    return {k: (chegou.get(k, 0), limite and k in aberto) for k in atual}


def data(ts: int) -> str:
    return datetime.fromtimestamp(ts, timezone.utc).strftime("%d/%m %H:%M UTC") if ts else "?"


def fonte_ramo(raiz: Path, ramo: str, nome: str) -> dict | None:
    ref = f"origin/{ramo}"
    caminho = achar_caminho(raiz, ref, nome)
    if not caminho:
        return None
    texto = ler_blob(raiz, ref, caminho)
    _, bruto = git(raiz, "show", f"{ref}:{caminho}")
    rc, info = gtxt(raiz, "log", "-1", "--format=%ct|%h|%s", ref, "--", caminho)
    ct, h, s = (info.split("|", 2) + ["", "", ""])[:3] if not rc else ("0", "?", "")
    return {"ramo": ramo, "ref": ref, "caminho": caminho, "texto": texto, "ct": int(ct or 0), "hash": h, "msg": s, "bytes": bruto, "eol": "\r\n" if b"\r\n" in bruto else "\n"}


def comparar_estado(fontes: list[dict], local: str | None) -> list[str]:
    L = []
    if len(fontes) == 2:
        a, b = fontes
        if a["texto"].rstrip() == b["texto"].rstrip():
            L.append(f"- {ESTADO}: IGUAL nas duas branches.")
        else:
            novo = max(fontes, key=lambda f: f["ct"])
            L.append(f"- {ESTADO}: DIFERENTE. Mais recente: **{novo['ramo']}** ({data(novo['ct'])}, {novo['hash']}). Nao mistura (so o painel escreve); com --publicar a branch mais antiga recebe uma copia do mais recente. Arquivos salvos com o sufixo de cada branch.")
    for f in fontes:
        L.append(f"  - {f['ramo']}: {f['caminho']} · ultimo commit {data(f['ct'])} ({f['hash']}) · {len(f['texto'])} caracteres")
    if local is not None:
        L.append(f"  - local (pasta de trabalho): {len(local)} caracteres")
    return L


def compilar(fontes: list[dict]) -> tuple[str, list[str], dict]:
    base = max(fontes, key=lambda f: f["ct"])
    for f in fontes:
        f["blocos"] = blocos(f["texto"])
        f["chegada"] = historico(Path(f["raiz"]), f["ref"], f["caminho"], f["blocos"])
    ordem: list[str] = list(base["blocos"])
    for f in fontes:
        anterior = None
        for k in f["blocos"]:
            if k not in ordem:
                ordem.insert(ordem.index(anterior) + 1 if anterior in ordem else len(ordem), k)
            anterior = k
    partes, rel = [], []
    resumo = {"iguais": 0, "diferentes": 0, "so_um": 0}
    for k in ordem:
        tem = [f for f in fontes if k in f["blocos"]]
        textos = {f["blocos"][k].rstrip() for f in tem}
        if len(textos) == 1:
            partes.append(max(tem, key=lambda f: f["ct"])["blocos"][k])
            resumo["iguais" if len(tem) == len(fontes) else "so_um"] += 1
            if len(tem) < len(fontes):
                rel.append(f"| {k} | so existe em {tem[0]['ramo']} | {tem[0]['ramo']} | entrou |")
            continue
        resumo["diferentes"] += 1
        venc = max(tem, key=lambda f: (f["chegada"][k][0], f is base))
        partes.append(venc["blocos"][k])
        det = " · ".join(f"{f['ramo']}: {('>=' if f['chegada'][k][1] else '') + data(f['chegada'][k][0])}" for f in tem)
        rel.append(f"| {k} | DIFERENTE ({det}) | {venc['ramo']} | o texto de {venc['ramo']} chegou por ultimo |")
    final = "".join(p if p.endswith("\n") else p + "\n" for p in partes)
    return final.replace("\n", base["eol"]), rel, resumo


def pasta_trabalho(raiz: Path, nome: str) -> Path:
    rc, atual = gtxt(raiz, "ls-files", "--full-name")
    for p in atual.splitlines():
        if p == nome or p.endswith("/" + nome):
            return raiz / p
    return raiz / nome


def publicar(raiz: Path, ramo: str, arquivos: dict[str, bytes], msg: str, tmp: Path) -> tuple[bool, str]:
    out = ""
    for _ in range(3):
        rc, out = gtxt(raiz, "fetch", "origin", ramo)
        if rc:
            return False, f"fetch falhou: {out[:150]}"
        _, tip = gtxt(raiz, "rev-parse", f"origin/{ramo}")
        _, arv_ant = gtxt(raiz, "rev-parse", f"origin/{ramo}^{{tree}}")
        idx = str(tmp / f"indice_{ramo.replace('/', '_')}")
        env = {"GIT_INDEX_FILE": idx}
        if os.path.exists(idx):
            os.remove(idx)
        if gtxt(raiz, "read-tree", tip, env=env)[0]:
            return False, "read-tree falhou"
        for caminho, conteudo in arquivos.items():
            rc, blob = gtxt(raiz, "hash-object", "-w", "--stdin", entrada=conteudo)
            if rc:
                return False, f"hash-object falhou: {blob[:150]}"
            if gtxt(raiz, "update-index", "--add", "--cacheinfo", f"100644,{blob},{caminho}", env=env)[0]:
                return False, "update-index falhou"
        _, arvore = gtxt(raiz, "write-tree", env=env)
        if arvore == arv_ant:
            return True, "ja estava igual"
        rc, sha = gtxt(raiz, "commit-tree", arvore, "-p", tip, "-m", msg)
        if rc:
            return False, f"commit-tree falhou: {sha[:150]} (git tem user.name e user.email?)"
        rc, out = gtxt(raiz, "push", "origin", f"{sha}:refs/heads/{ramo}")
        if rc == 0:
            return True, f"commit {sha[:9]} publicado em origin/{ramo}"
    return False, f"push recusado: {out[-160:]}"


def main() -> int:
    for s in (sys.stdout, sys.stderr):
        try:
            s.reconfigure(encoding="utf-8", errors="replace")
        except (AttributeError, ValueError):
            pass
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--raiz", type=Path, default=Path.cwd())
    ap.add_argument("--ramos", nargs=2, default=["main", "enxugamento"])
    ap.add_argument("--saida", type=Path, default=None)
    ap.add_argument("--aplicar", action="store_true")
    ap.add_argument("--publicar", action="store_true")
    ap.add_argument("--sem-atualizar", action="store_true", help="nao roda o atualizar_painel.py sobre o compilado")
    a = ap.parse_args()
    raiz = a.raiz.resolve()
    saida = (a.saida or raiz.parent / "painel_sync").resolve()
    saida.mkdir(parents=True, exist_ok=True)
    if a.publicar and not a.aplicar:
        print("ABORTADO: --publicar so vale junto com --aplicar.")
        return 1
    if gtxt(raiz, "rev-parse", "--is-inside-work-tree")[1] != "true":
        print(f"ABORTADO: {raiz} nao e um repositorio Git.")
        return 1
    rc, out = gtxt(raiz, "fetch", "origin")
    print("git fetch origin:", "ok" if rc == 0 else f"FALHOU ({out[:120]}); uso o que ja esta baixado")
    _, atual = gtxt(raiz, "rev-parse", "--abbrev-ref", "HEAD")

    rel = [f"# Relatorio de sincronizacao do painel ({datetime.now():%d/%m/%Y %H:%M})", "",
           f"- repositorio: {raiz} · branch atual: {atual} · modo: {'APLICAR' if a.aplicar else 'RELATORIO (nada alterado)'}", ""]
    fontes = []
    for ramo in a.ramos:
        f = fonte_ramo(raiz, ramo, TEXTO)
        if not f:
            print(f"ABORTADO: nao achei {TEXTO} em origin/{ramo}. Confira o nome da branch (--ramos).")
            return 1
        f["raiz"] = str(raiz)
        fontes.append(f)
        suf = ramo.replace("/", "_")
        (saida / f"PROJECT_STATUS_TEXT.{suf}.md").write_bytes(f["texto"].encode("utf-8"))
    loc = pasta_trabalho(raiz, TEXTO)
    local_txt = loc.read_bytes().decode("utf-8-sig", errors="replace").replace("\r\n", "\n") if loc.is_file() else None
    if local_txt is not None:
        (saida / "PROJECT_STATUS_TEXT.local.md").write_bytes(local_txt.encode("utf-8"))

    rel += ["## 1. PROJECT_STATUS_TEXT.md por branch", "", "| Origem | Caminho | Ultimo commit | Cards | Caracteres |", "|---|---|---|---|---|"]
    for f in fontes:
        n = sum(1 for k in blocos(f["texto"]) if k.startswith("#"))
        rel.append(f"| {f['ramo']} | {f['caminho']} | {data(f['ct'])} ({f['hash']}) {f['msg'][:40]} | {n} | {len(f['texto'])} |")
    if local_txt is not None:
        n = sum(1 for k in blocos(local_txt) if k.startswith("#"))
        igual = [f["ramo"] for f in fontes if f["texto"] == local_txt]
        rel.append(f"| local (pasta de trabalho) | {loc.relative_to(raiz).as_posix()} | igual a: {', '.join(igual) or 'nenhuma das duas'} | {n} | {len(local_txt)} |")

    compilado, linhas, resumo = compilar(fontes)
    arq_comp = saida / "PROJECT_STATUS_TEXT.compilado.md"
    arq_comp.write_bytes(compilado.encode("utf-8"))
    rel += ["", f"## 2. Cards: {resumo['iguais']} iguais nas duas · {resumo['diferentes']} diferentes · {resumo['so_um']} em uma branch so", ""]
    if linhas:
        rel += ["| Card | Situacao | Escolhido | Motivo |", "|---|---|---|---|"] + linhas
    else:
        rel.append("Nenhuma diferenca: as duas branches tem o mesmo texto.")
    estado = [f for f in (fonte_ramo(raiz, r, ESTADO) for r in a.ramos) if f]
    for f in estado:
        (saida / f"PROJECT_STATUS.{f['ramo'].replace('/', '_')}.md").write_bytes(f["texto"].encode("utf-8"))
    rel += ["", f"## 3. {ESTADO}", ""] + comparar_estado(estado, None)

    atualizar_ok = _existe("atualizar_painel")
    if not a.sem_atualizar and atualizar_ok:
        with tempfile.TemporaryDirectory() as td:
            shutil.copy2(arq_comp, Path(td) / TEXTO)
            r = subprocess.run(_cmd("atualizar_painel", "--raiz", td, "--simular"), capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=300, env=_env_zip(dict(__import__("os").environ)))
        rel += ["", "## 4. Simulacao do atualizar_painel.py sobre o compilado (nada gravado)", "", "```text", (r.stdout + r.stderr).strip()[-3500:], "```"]
    (saida / "relatorio_sync.md").write_text("\n".join(rel) + "\n", encoding="utf-8")
    print("\n".join(rel))
    print(f"\nArquivos em: {saida}")

    if not a.aplicar:
        print("\nRELATORIO apenas. Para gravar: acrescente --aplicar (e --publicar para enviar as duas branches).")
        return 0

    alvo = pasta_trabalho(raiz, TEXTO)
    pasta_bk = raiz / ".srag-status-local" / "backups"
    pasta_bk.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%dT%H%M%S")
    bk = pasta_bk / f"PENDENCIAS_antes_sync_{stamp}.md"
    if alvo.is_file():
        shutil.copy2(alvo, bk)
    alvo.write_bytes(compilado.encode("utf-8"))
    print(f"\nCompilado gravado em {alvo.relative_to(raiz).as_posix()} (copia anterior: {bk.relative_to(raiz).as_posix()})")
    if not a.sem_atualizar and atualizar_ok:
        r = subprocess.run(_cmd("atualizar_painel", "--raiz", str(raiz)), capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=600, env=_env_zip(dict(__import__("os").environ)))
        print((r.stdout + r.stderr).strip()[-2500:])
        if r.returncode:
            if bk.is_file():
                shutil.copy2(bk, alvo)
            print("atualizar_painel.py falhou: o arquivo anterior foi devolvido. Nada foi publicado.")
            return 1
    if not a.publicar:
        print("\nPronto no seu computador. Para enviar as duas branches: repita com --aplicar --publicar.")
        return 0

    final = alvo.read_bytes()
    (saida / "PROJECT_STATUS_TEXT.final.md").write_bytes(final)
    ok_tudo = True
    with tempfile.TemporaryDirectory() as td:
        for f in fontes:
            arqs = {f["caminho"]: final}
            if len(estado) == 2 and estado[0]["texto"].rstrip() != estado[1]["texto"].rstrip():
                nov = max(estado, key=lambda e: e["ct"])
                dono = next((e for e in estado if e["ramo"] == f["ramo"]), None)
                if dono is not None and dono is not nov:
                    arqs[dono["caminho"]] = nov["bytes"]
                    print(f"  {ESTADO} de {f['ramo']} <- copia do mais recente ({nov['ramo']})")
            ok, m = publicar(raiz, f["ramo"], arqs, "painel", Path(td))
            ok_tudo &= ok
            print(f"  publicar {f['ramo']}: {'OK' if ok else 'FALHOU'} · {m}")
    if not ok_tudo:
        print("Publicacao incompleta. O texto final esta em", saida / "PROJECT_STATUS_TEXT.final.md")
        return 1
    if alvo.is_file():
        git(raiz, "checkout", "--", alvo.relative_to(raiz).as_posix())
    rc, m = gtxt(raiz, "merge", "--ff-only", f"origin/{atual}")
    print(f"  atualizar {atual} local: {'OK' if rc == 0 else 'veja a mensagem -> ' + m[:200]}")
    for f in fontes:
        if f["ramo"] != atual:
            rc, m = gtxt(raiz, "fetch", "origin", f"{f['ramo']}:{f['ramo']}")
            print(f"  atualizar {f['ramo']} local: {'OK' if rc == 0 else 'ignorado (' + m[:90] + ')'}")
    print("\nFeito: as duas branches tem o mesmo PROJECT_STATUS_TEXT.md.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
