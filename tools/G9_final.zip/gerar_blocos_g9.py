#!/usr/bin/env python3
r"""Gera os blocos de texto da documentacao do G9 a partir dos arquivos que o notebook 11 gravou. So le.

Uso (na raiz do repositorio, depois da abertura do teste):  [antes: $env:PYTHONPATH = "tools\G9_final.zip"]
    .\.venv\Scripts\python.exe -m gerar_blocos_g9
    .\.venv\Scripts\python.exe -m gerar_blocos_g9 --ensaio       (treina a mao com o manifesto do ensaio)

Escreve outputs/final/blocos_g9.md (pasta ignorada pelo Git) e imprime o mesmo texto. Nao altera README,
decisoes.md, YAML nem manifestos: voce cola cada bloco no lugar indicado.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
import sys
from datetime import datetime
from pathlib import Path


def f3(x, nd: int = 3) -> str:
    try:
        return f"{float(x):.{nd}f}".replace(".", ",")
    except (TypeError, ValueError):
        return "n/d"


def pct(x, nd: int = 1) -> str:
    try:
        return f"{float(x) * 100:.{nd}f}".replace(".", ",") + "%"
    except (TypeError, ValueError):
        return "n/d"


def inteiro(x) -> str:
    try:
        return f"{int(x):,}".replace(",", ".")
    except (TypeError, ValueError):
        return "n/d"


def git(raiz: Path, *args: str) -> str:
    try:
        r = subprocess.run(["git", *args], cwd=raiz, capture_output=True, text=True, timeout=60)
        return r.stdout.strip() if r.returncode == 0 else ""
    except (OSError, subprocess.TimeoutExpired):
        return ""


def sha12(p: Path) -> str:
    h = hashlib.sha256()
    with p.open("rb") as fh:
        for bloco in iter(lambda: fh.read(1 << 20), b""):
            h.update(bloco)
    return h.hexdigest()[:12]


def main() -> int:
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except (AttributeError, ValueError):
        pass
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--raiz", type=Path, default=Path.cwd())
    ap.add_argument("--ensaio", action="store_true")
    args = ap.parse_args()
    raiz = args.raiz.resolve()
    tabelas = raiz / "outputs" / "tables"

    achados = sorted(tabelas.glob("*validacao_final_*_manifesto.json"), key=lambda p: p.stat().st_mtime)
    achados = [p for p in achados if ("ensaio" in p.name.lower()) == args.ensaio]
    if not achados:
        print("ABORTADO: nao achei o manifesto do notebook 11" + (" (ensaio)." if args.ensaio else ". O teste ja foi aberto?"))
        return 1
    manifesto_path = achados[-1]
    m = json.loads(manifesto_path.read_text(encoding="utf-8"))
    prefixo = manifesto_path.name.replace("_manifesto.json", "")
    janelas = {j["janela"]: j for j in m.get("janelas", [])}
    # O/E e calibracao nao saem do notebook 11: vem do calibracao_pos_g9.py (CSV) ou e calculado aqui das previsoes gravadas.
    cal = {}
    csv_cal = raiz / "outputs" / "final" / "calibracao_por_janela.csv"
    if csv_cal.is_file() and not args.ensaio:
        import pandas as pd

        cal = {r["janela"]: r for r in pd.read_csv(csv_cal).to_dict("records")}
    else:
        try:
            sys.path.insert(0, str(Path(__file__).resolve().parent))
            import calibracao_pos_g9 as cp
            import pandas as pd

            pr = cp.achar(raiz, args.ensaio)
            if pr is not None:
                dfp = pd.read_parquet(pr) if pr.suffix == ".parquet" else pd.read_csv(pr)
                for nome_j, blocos_j in cp.JANELAS.items():
                    sub = dfp[dfp["bloco"].isin(blocos_j)]
                    if len(sub):
                        cal[nome_j] = cp.resumo(sub["y_true"].to_numpy(dtype=int), sub["y_prob"].to_numpy(dtype=float))
        except Exception as exc:  # noqa: BLE001
            print(f"AVISO: nao consegui calcular O/E das previsoes ({exc!r}).")
    for nome_j, vals in cal.items():
        janelas.setdefault(nome_j, {}).update({k: v for k, v in vals.items() if k in ("o_e", "inclinacao", "ece_quantis", "brier_relativo")})
    a, b, p = janelas.get("teste_a", {}), janelas.get("teste_b", {}), janelas.get("pandemico_isolado", {})
    ic = m.get("ic_bootstrap", {})
    commit = git(raiz, "rev-parse", "--short", "HEAD")
    quando = m.get("teste_aberto_em_utc", "")
    try:
        dt = datetime.fromisoformat(quando)
        data_br, hora_utc = dt.strftime("%d/%m/%Y"), dt.strftime("%H:%M")
    except ValueError:
        data_br, hora_utc = "?", "?"
    sufixo = " (ENSAIO: nao e resultado do teste)" if args.ensaio else ""

    def linha_janela(rotulo: str, j: dict) -> str:
        return (f"| {rotulo} | {j.get('blocos', '')} | {inteiro(j.get('n'))} | {inteiro(j.get('positivos'))} | {pct(j.get('prevalencia'))} | "
                f"{f3(j.get('pr_auc', j.get('ap')))} | {f3(j.get('pr_auc_sobre_prevalencia'), 2)}x | {f3(j.get('auc'))} | {f3(j.get('brier'), 4)} | "
                f"{f3(j.get('o_e'), 2) if 'o_e' in j else 'n/c'} | {f3(j.get('recall'))} | {f3(j.get('precision'))} |")

    tabela = "\n".join([
        "| Janela | Blocos | n | Óbitos | Prevalência | PR-AUC | PR-AUC ÷ prevalência | ROC-AUC | Brier | O/E | Sensibilidade | Precisão |",
        "|---|---|---|---|---|---|---|---|---|---|---|---|",
        linha_janela("Teste A (principal)", a),
        linha_janela("2020–2022 (isolado)", p),
        linha_janela("Teste B (A + 2020–2022)", b),
    ])

    def faixa(nome: str) -> str:
        r = ic.get(nome) or {}
        return f"{f3(r.get('estimativa'), 4 if nome == 'brier' else 3)} (IC 95%: {f3(r.get('ic_inferior'), 4 if nome == 'brier' else 3)} a {f3(r.get('ic_superior'), 4 if nome == 'brier' else 3)})"

    def veredito(ok) -> str:
        if ok is None:
            return "não calculado"
        if ok is True:
            return "dentro do previsto"
        if ok is False:
            return "fora do previsto"
        return f"fora do previsto ({ok} da faixa)"

    pr, roc = a.get("pr_auc", a.get("ap")), a.get("auc")
    def dentro(valor, lo, hi):
        if valor is None:
            return None
        v = float(valor)
        return True if lo <= v <= hi else ("acima" if v > hi else "abaixo")

    h1 = dentro(pr, 0.30, 0.36)
    h2 = dentro(roc, 0.85, 0.87)
    h3 = None if (p.get("brier") is None or a.get("brier") is None) else float(p["brier"]) > float(a["brier"])
    h4 = None if "o_e" not in p else float(p["o_e"]) > 1
    hip = "\n".join([
        "| Hipótese registrada antes do teste | Resultado | Leitura |",
        "|---|---|---|",
        f"| Teste A: PR-AUC entre 0,30 e 0,36 | {f3(pr)} | {veredito(h1)} |",
        f"| Teste A: ROC-AUC entre 0,85 e 0,87 | {f3(roc)} | {veredito(h2)} |",
        f"| 2020–2022: Brier pior que no Teste A | {f3(p.get('brier'), 4)} contra {f3(a.get('brier'), 4)} | {veredito(h3)} |",
        f"| 2020–2022: O/E acima de 1 | {f3(p.get('o_e'), 2) if 'o_e' in p else 'n/c'} | {veredito(h4)} |",
    ])

    def lin_cal(rotulo, j):
        return f"{rotulo}: O/E {f3(j.get('o_e'), 2)}, inclinação {f3(j.get('inclinacao'), 2)}, ECE por quantis {f3(j.get('ece_quantis'), 3)}"

    cal_txt = "Calibração por janela: " + "; ".join(lin_cal(r, j) for r, j in (("Teste A", a), ("2020–2022", p), ("Teste B", b)) if "o_e" in j) + "." if any("o_e" in j for j in (a, p, b)) else ""

    yaml_g9 = f'''  G9_holdout:
    status: executado
    executado_em: "{quando}"
    n_acessos: 1'''

    arquivos = []
    for q in sorted(tabelas.glob(prefixo + "*.csv")) + [manifesto_path]:
        arquivos.append(f"| `{q.relative_to(raiz).as_posix()}` | {q.stat().st_size:,} | {sha12(q)} |".replace(",", "."))

    texto = f"""# Blocos do G9{sufixo}

Fonte: `{manifesto_path.relative_to(raiz).as_posix()}` · commit atual `{commit}` · teste aberto em {data_br} às {hora_utc} UTC.

## Bloco 1 · docs/decisoes.md (no fim da seção 9, depois das hipóteses)

```markdown
### Resultado da abertura (teste aberto uma única vez em {data_br}, {hora_utc} UTC, commit {commit})

O teste foi aberto com tudo congelado: Hist Gradient Boosting, 30 variáveis, calibração `{m.get('calibracao_metodo')}` e limiar {f3(m.get('limiar_final'), 4)}. Nada foi reajustado depois.

{tabela}

Teste A, com intervalo de 95% por bootstrap de grupos ({m.get('ic_bootstrap', {}).get('ap', {}).get('repeticoes', 'n/d')} réplicas): PR-AUC {faixa('ap')}; ROC-AUC {faixa('auc')}; Brier {faixa('brier')}.

{cal_txt}

{hip}

Resultado fora do previsto entra como achado, nunca como motivo para reajuste.
```

## Bloco 2 · README.md (trocar o parágrafo da seção "Resultados")

Apague:

```markdown
Validação (`val_ref`): PR-AUC 0,362, ROC-AUC 0,867, Brier 0,063. Os
resultados do teste ficam no relatório final, depois da abertura única.
```

Cole no lugar:

```markdown
Validação (`val_ref`): PR-AUC 0,362, ROC-AUC 0,867, Brier 0,063.

Teste aberto uma única vez em {data_br}. No Teste A (`test_ref`, n = {inteiro(a.get('n'))}): PR-AUC {f3(pr)} ({f3(a.get('pr_auc_sobre_prevalencia'), 2)}x a prevalência), ROC-AUC {f3(roc)}, Brier {f3(a.get('brier'), 4)}, sensibilidade {f3(a.get('recall'))} e precisão {f3(a.get('precision'))} no limiar {f3(m.get('limiar_final'), 4)}. Em 2020–2022 (isolado): PR-AUC {f3(p.get('pr_auc', p.get('ap')))}, ROC-AUC {f3(p.get('auc'))}, Brier {f3(p.get('brier'), 4)}. As tabelas estão em `resultados/`.
```

## Bloco 3 · configs/supervised.yaml (o notebook já gravou; só conferir)

```yaml
{yaml_g9}
```

## Bloco 4 · resultados/LEIA-ME.md (lista dos arquivos da abertura)

| Arquivo | Bytes | SHA-256 (12) |
|---|---|---|
{chr(10).join(arquivos)}

## Bloco 5 · comentário para o card do painel (#2)

Teste aberto uma vez em {data_br} às {hora_utc} UTC, commit {commit}. Teste A: PR-AUC {f3(pr)}, ROC-AUC {f3(roc)}, Brier {f3(a.get('brier'), 4)}. 2020–2022: PR-AUC {f3(p.get('pr_auc', p.get('ap')))}, Brier {f3(p.get('brier'), 4)}. Hipóteses: PR-AUC {veredito(h1)}; ROC-AUC {veredito(h2)}; Brier de 2020–2022 {veredito(h3)}; O/E {veredito(h4)}.
"""
    destino = raiz / "outputs" / "final"
    destino.mkdir(parents=True, exist_ok=True)
    (destino / "blocos_g9.md").write_text(texto, encoding="utf-8")
    print(texto)
    print(f"[gravado em {(destino / 'blocos_g9.md').relative_to(raiz).as_posix()}]")
    return 0


if __name__ == "__main__":
    sys.exit(main())
