#!/usr/bin/env python3
r"""Troca os caminhos pessoais (pasta do usuario e da empresa) por <REPO> e <HOME> nas saidas salvas.

Uso (na raiz do repositorio, com o venv do projeto):  [antes: $env:PYTHONPATH = "tools\G9_final.zip"]
    .\.venv\Scripts\python.exe -m limpar_caminhos                   (relatorio, nada muda)
    .\.venv\Scripts\python.exe -m limpar_caminhos --aplicar         (grava)
    .\.venv\Scripts\python.exe -m limpar_caminhos --pastas resultados --aplicar

Pastas varridas por padrao: notebooks, data/analytical, outputs/tables, outputs/runs, outputs/final, resultados.
Arquivos: .ipynb .json .csv .yaml .yml .md .txt. Confere que JSON e YAML continuam validos.
Rode DEPOIS de cada execucao de notebooks (cadeia e G9), porque cada execucao grava os caminhos de novo.
"""
from __future__ import annotations

import argparse
import json
import re
import sys
import tempfile
from pathlib import Path

PASTAS = ["notebooks", "data/analytical", "outputs/tables", "outputs/runs", "outputs/final", "resultados"]
SUFIXOS = {".ipynb", ".json", ".csv", ".yaml", ".yml", ".md", ".txt"}
HOME = re.compile(r"[A-Za-z]:(?:\\\\|\\|/)Users(?:\\\\|\\|/)[^\\/\"'\s<>|]+")
REPO_GENERICO = re.compile(r"<HOME>(?:\\\\|\\|/)(?:[^\\/\"'<>|\r\n]+(?:\\\\|\\|/)){0,6}?Projeto_Integrador")
RESTO = re.compile(r"olivem85|OneDrive - |C:\\+Users", re.I)


def variantes_da_raiz(raiz: Path) -> list[re.Pattern]:
    bruto = str(raiz)
    formas = {bruto, bruto.replace("\\", "\\\\"), raiz.as_posix(), bruto.replace("\\", "/")}
    return [re.compile(re.escape(f), re.I) for f in sorted(formas, key=len, reverse=True)]


def limpar(texto: str, raiz_re: list[re.Pattern]) -> tuple[str, int]:
    total = 0
    for rx in raiz_re:
        texto, n = rx.subn("<REPO>", texto)
        total += n
    texto, n = HOME.subn("<HOME>", texto)
    texto, m = REPO_GENERICO.subn("<REPO>", texto)
    return texto, total + n + m


def validar(caminho: Path, texto: str) -> None:
    if caminho.suffix in (".json", ".ipynb"):
        json.loads(texto)
    elif caminho.suffix in (".yaml", ".yml"):
        import yaml

        yaml.safe_load(texto)


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--raiz", type=Path, default=Path.cwd())
    ap.add_argument("--pastas", nargs="*", default=PASTAS)
    ap.add_argument("--aplicar", action="store_true")
    args = ap.parse_args()

    raiz = args.raiz.resolve()
    if not (raiz / "src").is_dir():
        print(f"ABORTADO: {raiz} nao parece a raiz do projeto (sem pasta src).")
        return 1
    raiz_re = variantes_da_raiz(raiz)
    copia = Path(tempfile.mkdtemp(prefix="caminhos_"))
    mudam, falhas, restos = [], [], []
    for pasta in args.pastas:
        base = raiz / pasta
        if not base.is_dir():
            continue
        for p in sorted(base.rglob("*")):
            if not p.is_file() or p.suffix not in SUFIXOS or "_antigo" in p.parts:
                continue
            rel = p.relative_to(raiz).as_posix()
            try:
                bruto = p.read_bytes().decode("utf-8")
            except UnicodeDecodeError:
                falhas.append((rel, "nao e UTF-8"))
                continue
            novo, n = limpar(bruto, raiz_re)
            try:
                validar(p, novo)
            except Exception as exc:  # noqa: BLE001
                falhas.append((rel, f"{type(exc).__name__}: {exc}"))
                continue
            if n:
                destino = copia / rel
                destino.parent.mkdir(parents=True, exist_ok=True)
                destino.write_bytes(novo.encode("utf-8"))
                mudam.append((rel, n))
            for i, linha in enumerate(novo.splitlines(), 1):
                if RESTO.search(linha):
                    restos.append(f"{rel}:{i}: {linha.strip()[:100]}")

    print("=" * 78)
    print(f"RELATORIO (copia em {copia})")
    print("=" * 78)
    for rel, n in mudam:
        print(f"{rel:70s} {n:5d} troca(s)")
    print("-" * 78)
    print(f"arquivos que mudam: {len(mudam)} | trocas: {sum(n for _, n in mudam)}")
    for rel, motivo in falhas:
        print(f"PULADO {rel}: {motivo}")
    if restos:
        print(f"AINDA APARECE nome pessoal ou da empresa ({len(restos)}):")
        print("\n".join(restos[:30]))

    if not args.aplicar:
        print("Relatorio pronto. Nada foi gravado. Para gravar: rode de novo com --aplicar.")
        return 0
    if falhas:
        print("Ha arquivos PULADOS: corrija antes de aplicar.")
        return 2
    for rel, _ in mudam:
        (raiz / rel).write_bytes((copia / rel).read_bytes())
    print(f"GRAVADO: {len(mudam)} arquivo(s).")
    print("Confira: git grep -n -i -E \"olivem85|OneDrive - \" -- notebooks resultados docs README.md")
    return 0


if __name__ == "__main__":
    sys.exit(main())
