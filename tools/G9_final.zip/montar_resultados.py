#!/usr/bin/env python3
r"""Monta a pasta resultados/ (tabelas, figuras e manifestos que o relatorio cita). Relatorio numa copia primeiro.

Uso (na raiz do repositorio, com o venv do projeto, DEPOIS do G9 e do #194):  [antes: $env:PYTHONPATH = "tools\G9_final.zip"]
    .\.venv\Scripts\python.exe -m montar_resultados                          (relatorio; nada e copiado)
    .\.venv\Scripts\python.exe -m montar_resultados --aplicar                (copia, limpa caminhos e escreve o LEIA-ME)
    .\.venv\Scripts\python.exe -m montar_resultados --incluir "outputs/tables/04_eda_resumo_*.csv" --aplicar

Copia SEM renomear: tabelas e manifestos do notebook 11 (so os reais), do 10, 09, 07, 05, importancia e razoes de chances,
ablacoes, maturidade do desfecho, curva de decisao, os manifestos de data/analytical e as figuras de supervisionado_05.
NUNCA copia .parquet, nem nada com "ensaio" no nome, nem a pasta outputs/_antigo.
Troca caminhos pessoais por <REPO> e <HOME> e escreve resultados/LEIA-ME.md (arquivo, notebook de origem, tamanho, SHA-256).
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import shutil
import sys
import tempfile
from pathlib import Path

PADROES = [
    "outputs/tables/11_validacao_final_*",
    "outputs/tables/10_calibracao_limiar_*",
    "outputs/tables/09_ajuste_fino_*",
    "outputs/tables/07_baseline_logistica_*",
    "outputs/tables/05_cinco_familias_*",
    "outputs/tables/05_pilotos_*",
    "outputs/tables/04_eda_decisao_clustering.*",
    "outputs/tables/importancia_permutacao_val_meas.csv",
    "outputs/tables/razoes_chances_logistica.csv",
    "outputs/final/ablacoes_val_ref.csv",
    "outputs/final/ablacoes_roc_por_ano.csv",
    "outputs/final/maturidade_desfecho_por_ano.csv",
    "outputs/final/curva_decisao.csv",
    "outputs/final/calibracao_por_*.csv",
    "outputs/final/tabelas_relatorio_*.csv",
    "data/analytical/manifesto_particao.json",
    "data/analytical/manifesto_supervisionado.json",
    "data/analytical/coorte_final.manifest.json",
    "reports/figures/supervisionado_05/*.png",
    "reports/figures/curva_decisao*.png",
    "reports/figures/equidade_*.png",
]
ORIGEM = [(r"^11_", "11_validacao_final"), (r"^10_", "10_calibracao_limiar"), (r"^09_", "09_ajuste_fino"), (r"^07_", "07_baseline_logistica"),
          (r"^05_", "05_supervisionado_pilotos"), (r"^04_eda", "04_eda_temporal_agrupamento"), (r"^importancia|^razoes", "script de importancia (#91)"),
          (r"^ablacoes", "08_ablacoes_variaveis"), (r"^maturidade", "tools/maturidade_desfecho.py"), (r"^curva_decisao", "script da curva de decisao (#176)"), (r"^calibracao_por", "calibracao_pos_g9.py (#165)"),
          (r"^manifesto_|^coorte_final", "02_coorte_definitiva"), (r"^tabelas_relatorio|^equidade_", "script de tabelas (#55)")]
HOME = re.compile(r"[A-Za-z]:(?:\\\\|\\|/)Users(?:\\\\|\\|/)[^\\/\"'\s<>|]+")
REPO_GEN = re.compile(r"<HOME>(?:\\\\|\\|/)(?:[^\\/\"'<>|\r\n]+(?:\\\\|\\|/)){0,6}?Projeto_Integrador")


def escolher(raiz: Path, extras: list[str]) -> tuple[list[Path], list[str]]:
    achados: dict[Path, None] = {}
    for padrao in PADROES + extras:
        for p in sorted(raiz.glob(padrao)):
            achados[p] = None
    ok, pulados = [], []
    for p in achados:
        rel = p.relative_to(raiz).as_posix()
        if p.suffix == ".parquet" or "ensaio" in p.name.lower() or "_antigo" in p.parts or p.suffix == ".gz":
            pulados.append(f"{rel} (parquet, ensaio ou antigo)")
        elif p.is_file():
            ok.append(p)
    return ok, pulados


def origem(nome: str) -> str:
    for rx, rotulo in ORIGEM:
        if re.search(rx, nome):
            return rotulo
    return "?"


def sha12(p: Path) -> str:
    h = hashlib.sha256()
    with p.open("rb") as fh:
        for b in iter(lambda: fh.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()[:12]


def limpar_texto(p: Path, raiz: Path) -> bytes:
    dados = p.read_bytes()
    if p.suffix not in (".csv", ".json", ".yaml", ".yml", ".md", ".txt"):
        return dados
    texto = dados.decode("utf-8")
    bruto = str(raiz)
    for forma in sorted({bruto, bruto.replace("\\", "\\\\"), raiz.as_posix(), bruto.replace("\\", "/")}, key=len, reverse=True):
        texto = re.sub(re.escape(forma), "<REPO>", texto, flags=re.I)
    texto = HOME.sub("<HOME>", texto)
    texto = REPO_GEN.sub("<REPO>", texto)
    if p.suffix == ".json":
        json.loads(texto)
    return texto.encode("utf-8")


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--raiz", type=Path, default=Path.cwd())
    ap.add_argument("--incluir", action="append", default=[], help="padrao extra (relativo a raiz), pode repetir")
    ap.add_argument("--aplicar", action="store_true")
    args = ap.parse_args()
    raiz = args.raiz.resolve()
    if not (raiz / "src").is_dir():
        print(f"ABORTADO: {raiz} nao parece a raiz do projeto.")
        return 1

    arquivos, pulados = escolher(raiz, args.incluir)
    reais_11 = [p for p in arquivos if p.name.startswith("11_validacao_final_") and p.name.endswith("_manifesto.json")]
    copia = Path(tempfile.mkdtemp(prefix="resultados_"))
    linhas = []
    for p in arquivos:
        rel = p.relative_to(raiz).as_posix()
        destino_rel = Path(*p.relative_to(raiz).parts[1:]) if p.relative_to(raiz).parts[0] in ("outputs", "reports") else p.relative_to(raiz)
        destino = copia / destino_rel
        destino.parent.mkdir(parents=True, exist_ok=True)
        destino.write_bytes(limpar_texto(p, raiz))
        linhas.append((destino_rel.as_posix(), origem(p.name), destino.stat().st_size, sha12(destino)))

    print("=" * 78)
    print(f"RELATORIO (copia em {copia})")
    print("=" * 78)
    for rel, org, tam, h in linhas:
        print(f"{rel:78s} {tam:>10,d}  {org}".replace(",", "."))
    print("-" * 78)
    print(f"arquivos a copiar: {len(linhas)} | pulados: {len(pulados)}")
    for s in pulados[:15]:
        print("  pulado:", s)
    if not reais_11:
        print("AVISO: nenhum manifesto real do notebook 11 (11_validacao_final_*_manifesto.json). O G9 foi executado?")
    if any(r[0].endswith(".parquet") for r in linhas):
        print("ERRO: .parquet na lista.")
        return 2

    if not args.aplicar:
        print("Relatorio pronto. Nada foi copiado. Para copiar: rode de novo com --aplicar.")
        return 0

    destino_base = raiz / "resultados"
    destino_base.mkdir(exist_ok=True)
    for rel, _, _, _ in linhas:
        alvo = destino_base / rel
        alvo.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(copia / rel, alvo)
    corpo = ["# Resultados", "", "Tabelas, figuras e manifestos citados no relatorio. Os dados e as previsoes linha a linha nao entram (ver .gitignore).",
             "Caminhos pessoais foram trocados por `<REPO>` e `<HOME>`.", "",
             "| Arquivo | Origem | Bytes | SHA-256 (12) |", "|---|---|---|---|"]
    corpo += [f"| `{rel}` | {org} | {tam} | {h} |" for rel, org, tam, h in linhas]
    (destino_base / "LEIA-ME.md").write_text("\n".join(corpo) + "\n", encoding="utf-8")
    print(f"COPIADO: {len(linhas)} arquivo(s) em resultados/ + LEIA-ME.md")
    print("Confira: git grep -n -i -E \"olivem85|OneDrive - \" -- resultados   e depois: git add resultados")
    return 0


if __name__ == "__main__":
    sys.exit(main())
