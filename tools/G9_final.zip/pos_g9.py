#!/usr/bin/env python3
r"""COMANDO 2 (depois que a Pessoa C terminar o G9): tudo o que falta, na ordem certa, ate a mescla na main.

Uso (na raiz do repositorio, na branch enxugamento, com o G9 ja executado e publicado; scripts em tools\G9_final):  [antes: $env:PYTHONPATH = "tools\G9_final.zip"]
    .\.venv\Scripts\python.exe -m pos_g9

Passos (para no primeiro erro; pode repetir o comando sem medo: cada etapa confere antes de agir):
    0. confere G9 executado (YAML), manifesto e previsoes REAIS, ramo, arvore limpa
    1. checklist_g9 --depois (0 falhas)                          -> card #2
    2. calibracao_pos_g9 --aplicar (O/E e calibracao)             -> card #165
    3. tabelas_relatorio e curva_decisao (equidade e utilidade)   -> dados do #55 e do #176 (nao bloqueiam)
    4. gerar_blocos_g9 + aplicar_docs_g9 --aplicar (decisoes.md, README, YAML)  -> card #194; commit "[done:#2] [done:#165] [done:#194]"
    5. caminhos pessoais (lote; os comentarios ja foram tratados antes do G9) -> card #189; commit "[done:#189]"
    6. montar_resultados --aplicar                                -> card #157; commit "[done:#157]"
    7. pytest rapido, push da branch e MESCLA NA MAIN (merge normal), push da main
Os cards fecham pelos [done:#N] das mensagens: o painel le a main, entao aparecem assim que a mescla termina.
O que continua com pessoas/IA: #191 (comentarios essenciais), #190 (Markdown), #55 (leitura), #133, #134 (apresentacao) e #147.
Opcoes: --sem-comentarios (pula o passo 5)  --sem-merge (para antes de mesclar)
"""
from __future__ import annotations

import argparse
import os
import re
import subprocess
import sys
from datetime import datetime
from pathlib import Path

AQUI = Path(__file__).resolve().parent
_ZIP = AQUI if AQUI.suffix.lower() == ".zip" else None


def _existe(nome: str) -> bool:
    # roda a partir do zip (sem descompactar): confere dentro do zip
    if _ZIP:
        import zipfile
        try:
            return f"{nome}.py" in zipfile.ZipFile(_ZIP).namelist()
        except OSError:
            return False
    return (AQUI / f"{nome}.py").is_file()


def _cmd(nome: str, *args: str) -> list[str]:
    # com o zip no PYTHONPATH (ver _env_zip), "-m nome" acha o modulo dentro dele
    if _ZIP:
        return [sys.executable, "-m", nome, *args]
    return [sys.executable, str(AQUI / f"{nome}.py"), *args]


def _env_zip(env: dict) -> dict:
    if not _ZIP:
        return env
    env = dict(env)
    atual = env.get("PYTHONPATH", "")
    env["PYTHONPATH"] = str(_ZIP) + (os.pathsep + atual if atual else "")
    return env
linhas: list[str] = []
DICA_PAINEL = ("\nDica: o PROJECT_STATUS_TEXT.md aparece alterado porque o painel esta mostrando uma previa local. "
               "Abra o painel e clique em 'Publicar edicoes locais' (ele devolve o arquivo ao estado do Git) e rode de novo.")


def dica(linhas) -> str:
    return DICA_PAINEL if any("PROJECT_STATUS_TEXT.md" in str(x) for x in linhas) else ""

fechados: list[str] = []
pendentes: list[str] = []


def dizer(txt: str = "") -> None:
    print(txt, flush=True)
    linhas.append(txt)


def git(raiz: Path, *args: str) -> tuple[int, str]:
    r = subprocess.run(["git", *args], cwd=raiz, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=900)
    return r.returncode, (r.stdout + (("\n" + r.stderr) if r.returncode and r.stderr else "")).rstrip()


def rodar(raiz: Path, script: str, *args: str) -> int:
    if not _existe(script[:-3]):
        dizer(f"FALTA o script {script} (no zip ou ao lado do pos_g9.py).")
        return 127
    env = _env_zip({**os.environ, "PYTHONUTF8": "1", "PYTHONIOENCODING": "utf-8"})
    return subprocess.run(_cmd(script[:-3], "--raiz", str(raiz), *args), cwd=raiz, env=env).returncode


def salvar(raiz: Path, final: str) -> None:
    pasta = raiz / "outputs" / "final"
    pasta.mkdir(parents=True, exist_ok=True)
    (pasta / "pos_g9.md").write_text(f"# pos_g9 ({datetime.now():%Y-%m-%d %H:%M})\n\n```text\n" + "\n".join(linhas) + f"\n```\n\n{final}\n", encoding="utf-8")


def parar(raiz: Path, motivo: str) -> int:
    dizer(f"\nPARADO: {motivo}")
    if fechados:
        dizer("Ja feito antes da parada (fica no repositorio): " + ", ".join(fechados))
    dizer("Corrija e rode de novo: o comando confere cada etapa e nao repete o que ja esta aplicado.")
    salvar(raiz, "PARADO: " + motivo)
    return 1


def commitar(raiz: Path, msg: str, caminhos_extra: list[str] | None = None) -> tuple[bool, str]:
    git(raiz, "add", "-A")
    rc, st = git(raiz, "status", "--porcelain")
    vazio = not st.strip()
    if vazio and "[done:" not in msg:
        return True, "nada mudou (sem commit novo)"
    # sem mudanca, o commit vazio ainda leva o [done:#N] ao painel
    rc, out = git(raiz, "commit", *(["--allow-empty"] if vazio else []), "-m", msg)
    return rc == 0, (f"commit: {msg}" if rc == 0 else "git commit falhou: " + out[:200])


def g9_executado(raiz: Path) -> tuple[bool, str]:
    try:
        import yaml

        g9 = yaml.safe_load((raiz / "configs" / "supervised.yaml").read_text(encoding="utf-8"))["gates"]["G9_holdout"]
    except Exception as exc:  # noqa: BLE001
        return False, f"nao consegui ler o YAML: {exc}"
    if g9.get("status") != "executado" or int(g9.get("n_acessos") or 0) != 1:
        return False, f"G9_holdout nao esta 'executado' com n_acessos = 1 (status={g9.get('status')}, n_acessos={g9.get('n_acessos')}). O teste foi aberto?"
    return True, "G9 executado, n_acessos = 1"


def reais(raiz: Path, pasta: str, padrao: str) -> list[Path]:
    base = raiz / pasta
    return [p for p in base.glob(padrao) if "ensaio" not in p.name.lower()] if base.is_dir() else []


def mesclar(raiz: Path, ramo: str) -> tuple[bool, str]:
    git(raiz, "fetch", "origin")
    rc, out = git(raiz, "switch", "main")
    if rc != 0:
        rc, out = git(raiz, "switch", "-c", "main", "--track", "origin/main")
    if rc != 0:
        return False, "nao consegui trocar para a main: " + out[:200]
    rc, out = git(raiz, "pull", "--ff-only")
    if rc != 0:
        git(raiz, "switch", ramo)
        return False, "git pull --ff-only na main falhou: " + out[:200]
    rc, out = git(raiz, "merge", "--no-edit", ramo)
    if rc != 0:
        _, conf = git(raiz, "diff", "--name-only", "--diff-filter=U")
        arquivos = [x.strip() for x in conf.splitlines() if x.strip()]
        so_painel = arquivos and all(x in ("PROJECT_STATUS.md", "PROJECT_STATUS_TEXT.md") for x in arquivos)
        if not so_painel:
            git(raiz, "merge", "--abort")
            git(raiz, "switch", ramo)
            return False, "CONFLITO em arquivo que nao e do painel: " + ", ".join(arquivos[:6]) + ". A mescla foi desfeita; resolva com a IA (card #194, passo 9)."
        for x in arquivos:
            git(raiz, "checkout", "--ours", "--", x)
            git(raiz, "add", x)
        rc, out = git(raiz, "commit", "--no-edit")
        if rc != 0:
            git(raiz, "merge", "--abort")
            git(raiz, "switch", ramo)
            return False, "nao consegui concluir a mescla: " + out[:200]
    rc, out = git(raiz, "push")
    if rc != 0:
        return False, "mescla feita localmente, mas o push da main falhou: " + out[:200] + " (rode: git push)"
    _, log = git(raiz, "log", "--oneline", "-4")
    return True, "main atualizada e publicada:\n" + log


def main() -> int:
    for s in (sys.stdout, sys.stderr):
        try:
            s.reconfigure(encoding="utf-8", errors="replace", line_buffering=True)
        except (AttributeError, ValueError):
            pass
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--raiz", type=Path, default=Path.cwd())
    ap.add_argument("--ramo", default="enxugamento")
    ap.add_argument("--qualquer-ramo", action="store_true")
    ap.add_argument("--sem-comentarios", action="store_true")
    ap.add_argument("--sem-merge", action="store_true")
    a = ap.parse_args()
    raiz = a.raiz.resolve()
    if not (raiz / "src").is_dir() or not (raiz / "configs" / "supervised.yaml").is_file():
        print(f"ABORTADO: {raiz} nao parece a raiz do projeto.")
        return 1

    dizer("== 0. Conferindo o G9, o ramo e a arvore ==")
    ok, msg = g9_executado(raiz)
    if not ok:
        return parar(raiz, msg)
    dizer(msg)
    if not reais(raiz, "outputs/tables", "*validacao_final_*_manifesto.json"):
        return parar(raiz, "nao achei o manifesto REAL do notebook 11 em outputs/tables (so de ensaio?).")
    if not reais(raiz, "outputs/predictions", "*validacao_final_*_predicoes_teste.*"):
        return parar(raiz, "nao achei as previsoes REAIS do teste em outputs/predictions.")
    _, ramo = git(raiz, "rev-parse", "--abbrev-ref", "HEAD")
    if ramo != a.ramo and not a.qualquer_ramo:
        return parar(raiz, f"voce esta no ramo '{ramo}', e o esperado e '{a.ramo}'. Use: git switch {a.ramo}")
    _, suja = git(raiz, "status", "--porcelain", "--untracked-files=no")
    if suja:
        return parar(raiz, "ha mudancas nao commitadas (faca o commit do G9 antes):\n" + "\n".join("  " + x for x in suja.splitlines()[:10]) + dica(suja.splitlines()))
    git(raiz, "fetch", "origin")
    rc, cont = git(raiz, "rev-list", "--left-right", "--count", "HEAD...@{u}")
    if rc == 0:
        frente, atras = (int(x) for x in cont.split())
        if atras:
            return parar(raiz, f"o GitHub tem {atras} commit(s) que voce nao tem: git pull --ff-only")
        dizer(f"ramo {ramo}, arvore limpa, {frente} commit(s) a frente do GitHub")

    dizer("\n== 1. Checklist depois da abertura (#2) ==")
    if rodar(raiz, "checklist_g9.py", "--depois") != 0:
        return parar(raiz, "o checklist --depois tem FALHAS (veja a lista acima).")
    fechados.append("#2")

    dizer("\n== 2. Calibracao por janela, O/E (#165) ==")
    if rodar(raiz, "calibracao_pos_g9.py", "--aplicar") != 0:
        return parar(raiz, "calibracao_pos_g9.py falhou.")
    fechados.append("#165")

    dizer("\n== 3. Tabelas de equidade e curva de decisao (#55, #176; nao bloqueiam) ==")
    if rodar(raiz, "tabelas_relatorio.py", "--aplicar") != 0:
        dizer("AVISO: tabelas_relatorio.py falhou (o #55 precisara delas: rode o script depois e veja a mensagem).")
        pendentes.append("tabelas do #55 (script falhou)")
    curva_ok = rodar(raiz, "curva_decisao.py", "--aplicar") == 0
    if not curva_ok:
        dizer("AVISO: curva_decisao.py falhou (opcional, #176).")

    dizer("\n== 4. Documentacao do G9 (#194) ==")
    if rodar(raiz, "gerar_blocos_g9.py") != 0:
        return parar(raiz, "gerar_blocos_g9.py falhou.")
    rc = rodar(raiz, "aplicar_docs_g9.py", "--aplicar")
    if rc == 1 or rc == 127:
        return parar(raiz, "aplicar_docs_g9.py recusou (veja a mensagem acima).")
    docs_ok = rc == 0
    marcas = "[done:#2] [done:#165]" + (" [done:#194]" if docs_ok else "") + (" [done:#176]" if curva_ok else "")
    if not docs_ok:
        dizer("AVISO: algum trecho da documentacao nao foi achado: complete a mao (card #194, passos 2 a 6). O #194 NAO sera marcado.")
        pendentes.append("documentacao do #194 (trecho a ajustar a mao)")
    ok, msg = commitar(raiz, "g9 documentado " + marcas)
    dizer(msg)
    if not ok:
        return parar(raiz, msg)
    if docs_ok:
        fechados.append("#194 (depois da mescla)")

    if a.sem_comentarios:
        dizer("\n== 5. Comentarios e caminhos: pulado (--sem-comentarios) ==")
        pendentes.append("#189 (comentarios e caminhos)")
    else:
        dizer("\n== 5. Caminhos pessoais e comentarios (#189) ==")
        if rodar(raiz, "lote.py", "relatorio", "--etapas", "caminhos,comentarios") != 0:
            return parar(raiz, "o relatorio do lote (caminhos, comentarios) falhou.")
        if rodar(raiz, "lote.py", "aplicar", "--etapas", "caminhos,comentarios") != 0:
            return parar(raiz, "a aplicacao do lote falhou ou o pytest depois dela falhou. Para desfazer: git checkout -- .")
        ok, msg = commitar(raiz, "comentarios e caminhos limpos [done:#189]")
        dizer(msg)
        if not ok:
            return parar(raiz, msg)
        fechados.append("#189")

    dizer("\n== 6. Pasta resultados/ (#157) ==")
    if rodar(raiz, "montar_resultados.py", "--aplicar") != 0:
        dizer("AVISO: montar_resultados.py falhou: o #157 fica para a Pessoa A.")
        pendentes.append("#157 (resultados/)")
    else:
        ok, msg = commitar(raiz, "resultados no pacote [done:#157]")
        dizer(msg)
        if not ok:
            return parar(raiz, msg)
        fechados.append("#157")

    dizer("\n== 7. Testes, push e mescla na main ==")
    if rodar(raiz, "rodar_testes.py", "--rapido") != 0:
        return parar(raiz, "o pytest rapido falhou antes do push.")
    rc, out = git(raiz, "push")
    if rc != 0:
        rc, out = git(raiz, "push", "-u", "origin", ramo)
    if rc != 0:
        return parar(raiz, "o push da branch falhou: " + out[-200:])
    dizer(f"branch {ramo} publicada")
    if a.sem_merge:
        dizer("--sem-merge: parei antes de mesclar. Faltam: git switch main; git pull --ff-only; git merge --no-edit enxugamento; git push")
        pendentes.append("mescla na main (#194, passo 9)")
    else:
        ok, msg = mesclar(raiz, ramo)
        dizer(msg)
        if not ok:
            pendentes.append("mescla na main (#194, passo 9)")
            return parar(raiz, "a mescla na main nao terminou (a branch ja esta publicada).")
        dizer("Voce esta na main. Daqui em diante, todo o trabalho e na main (git pull antes, git push depois).")

    dizer("\n== PRONTO ==")
    dizer("Cards fechados pelos [done:#N] dos commits (aparecem no painel depois da mescla; use 'Atualizar, auditar e validar'): " + ", ".join(fechados))
    if pendentes:
        dizer("Ficaram pendentes: " + "; ".join(pendentes))
    dizer("Continua com pessoas/IA: #55 leitura das tabelas · #133 limitacoes · #134 apresentacao · #147 fechar a entrega")
    salvar(raiz, "OK" if not pendentes else "OK com pendencias")
    return 0


if __name__ == "__main__":
    sys.exit(main())
