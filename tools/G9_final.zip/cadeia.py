#!/usr/bin/env python3
r"""Executa TODOS os notebooks da cadeia (02 a 10), em ordem, em segundo plano, e atualiza a documentacao.

Uso (na raiz do repositorio, com o venv do projeto; o zip em tools\G9_final.zip no PYTHONPATH (ver LEIA-ME)):
    .\.venv\Scripts\python.exe -m cadeia iniciar            (comeca em segundo plano e devolve o terminal)
    .\.venv\Scripts\python.exe -m cadeia status             (como esta; pode rodar quantas vezes quiser)
    .\.venv\Scripts\python.exe -m cadeia executar           (mesma coisa em primeiro plano, com a saida na tela)
    .\.venv\Scripts\python.exe -m cadeia documentar         (so a parte de documentacao, se a cadeia ja rodou)
    .\.venv\Scripts\python.exe -m cadeia iniciar --de 05    (retoma a partir do notebook 05 depois de corrigir um erro)

Ordem: 02 (regera coorte e artefato) -> 03 -> 04 -> 05 -> 06 -> 07 -> 08 -> 09 -> 10. Nunca roda o 01 (baixa dados) nem o 11 (teste).
Para no primeiro erro. Se tudo der certo: tira caminhos pessoais dos notebooks, grava requirements-lock.txt, acrescenta a versao
do Python ao pyproject, escreve o paragrafo de tempo e memoria no README, roda o pytest, faz commit e push (mensagem com [done:#126]).
Estado em outputs/final/cadeia_status.json, log em outputs/final/cadeia.log, resumo em outputs/final/cadeia.md.
"""
from __future__ import annotations

import argparse
import csv
import json
import os
import re
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

AQUI = Path(__file__).resolve().parent
_ZIP = AQUI if AQUI.suffix.lower() == ".zip" else None


def _existe(nome: str) -> bool:
    # roda a partir do zip (sem descompactar): confere dentro do zip
    if _ZIP:
        import zipfile
        try:
            return f"{nome}.py" in zipfile.ZipFile(_ZIP).namelist()
        except OSError:
            return False
    return (AQUI / f"{nome}.py").is_file()


def _cmd(nome: str, *args: str) -> list[str]:
    # com o zip no PYTHONPATH (ver _env_zip), "-m nome" acha o modulo dentro dele
    if _ZIP:
        return [sys.executable, "-m", nome, *args]
    return [sys.executable, str(AQUI / f"{nome}.py"), *args]


def _env_zip(env: dict) -> dict:
    if not _ZIP:
        return env
    env = dict(env)
    atual = env.get("PYTHONPATH", "")
    env["PYTHONPATH"] = str(_ZIP) + (os.pathsep + atual if atual else "")
    return env
PERIGOSAS = ("SRAG_ENSAIO", "SRAG_ALLOW_TEST_REOPEN", "SRAG_ALLOW_DIRTY")
NUMEROS = [f"{i:02d}" for i in range(2, 11)]
LIMITE_S = {"02": 10800}
PERMITIDOS = ("notebooks/", "requirements-lock.txt", "pyproject.toml", "README.md", "docs/")
INI, FIM = "<!-- cadeia:inicio -->", "<!-- cadeia:fim -->"


def agora() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def git(raiz: Path, *args: str) -> str | None:
    try:
        r = subprocess.run(["git", *args], cwd=raiz, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=300)
    except (OSError, subprocess.TimeoutExpired):
        return None
    return r.stdout.rstrip() if r.returncode == 0 else None


def caminhos(raiz: Path) -> dict[str, Path]:
    pasta = raiz / "outputs" / "final"
    return {"pasta": pasta, "status": pasta / "cadeia_status.json", "log": pasta / "cadeia.log", "resumo": pasta / "cadeia.md",
            "perf": pasta / "performance_notebooks.csv"}


def ler_status(raiz: Path) -> dict:
    p = caminhos(raiz)["status"]
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def gravar_status(raiz: Path, **campos) -> dict:
    p = caminhos(raiz)
    p["pasta"].mkdir(parents=True, exist_ok=True)
    st = ler_status(raiz)
    st.update(campos)
    st["atualizado_em"] = agora()
    p["status"].write_text(json.dumps(st, ensure_ascii=False, indent=1), encoding="utf-8")
    return st


def log(raiz: Path, texto: str) -> None:
    p = caminhos(raiz)
    p["pasta"].mkdir(parents=True, exist_ok=True)
    with p["log"].open("a", encoding="utf-8") as fh:
        fh.write(f"[{datetime.now():%H:%M:%S}] {texto}\n")
    if os.environ.get("CADEIA_BG") != "1":
        print(texto, flush=True)


def vivo(pid: int | None) -> bool:
    if not pid:
        return False
    try:
        import psutil

        return psutil.pid_exists(int(pid)) and psutil.Process(int(pid)).status() != psutil.STATUS_ZOMBIE
    except Exception:  # noqa: BLE001
        try:
            os.kill(int(pid), 0)
            return True
        except OSError:
            return False


def achar_notebooks(raiz: Path, de: str) -> tuple[list[Path], list[str]]:
    achados, faltam = [], []
    for n in NUMEROS:
        if n < de:
            continue
        c = sorted((raiz / "notebooks").glob(f"{n}_*.ipynb"))
        if len(c) == 1:
            achados.append(c[0])
        else:
            faltam.append(f"{n}_*.ipynb ({len(c)} encontrados)")
    return achados, faltam


def memoria_livre_gb() -> float | None:
    try:
        import psutil

        return psutil.virtual_memory().available / 1024 ** 3
    except ImportError:
        return None


def ambiente() -> dict:
    env = {k: v for k, v in os.environ.items() if k not in PERIGOSAS}
    env.update({"PYTHONUTF8": "1", "PYTHONIOENCODING": "utf-8"})
    return env


def impedir_suspensao() -> None:
    if os.name == "nt":
        try:
            import ctypes

            ctypes.windll.kernel32.SetThreadExecutionState(0x80000001)
        except Exception:  # noqa: BLE001
            pass


def linha_perf(raiz: Path, nome: str, desde: str) -> dict:
    p = caminhos(raiz)["perf"]
    if not p.is_file():
        return {}
    achada = {}
    with p.open(encoding="utf-8-sig", newline="") as fh:
        for r in csv.DictReader(fh):
            if r.get("notebook") == nome and r.get("quando", "") >= desde:
                achada = r
    return achada


DICA_PAINEL = ("\nDica: o PROJECT_STATUS_TEXT.md aparece alterado porque o painel esta mostrando uma previa local. "
               "Abra o painel e clique em 'Publicar edicoes locais' (ele devolve o arquivo ao estado do Git) e rode de novo.")


def dica(linhas) -> str:
    return DICA_PAINEL if any("PROJECT_STATUS_TEXT.md" in str(x) for x in linhas) else ""



def tree_suja(raiz: Path) -> str:
    return git(raiz, "status", "--porcelain", "--untracked-files=no") or ""


def arvore_suja_bloqueante(raiz: Path, de: str) -> list[str]:
    """Na primeira rodada a arvore tem de estar limpa. Ao retomar (--de 03 ou mais), notebooks ja executados podem estar modificados."""
    linhas = [ln for ln in tree_suja(raiz).splitlines() if ln.strip()]
    if de == "02":
        return linhas
    return [ln for ln in linhas if not ln[3:].strip().strip('"').startswith("notebooks/")]


# ------------------------------------------------------------------ executar
def cmd_executar(raiz: Path, a) -> int:
    p = caminhos(raiz)
    if not (raiz / "tools" / "medir_notebook.py").is_file():
        print(f"ABORTADO: {raiz} nao parece a raiz do projeto (falta tools/medir_notebook.py).")
        return 1
    nbs, faltam = achar_notebooks(raiz, a.de)
    if faltam:
        gravar_status(raiz, estado="erro", erro="notebooks nao encontrados: " + ", ".join(faltam))
        print("ABORTADO: nao achei exatamente um arquivo para: " + ", ".join(faltam) + ". A renomeacao (#192) foi feita?")
        return 1
    if a.sem_02:
        nbs = [n for n in nbs if not n.name.startswith("02_")]
    suja = arvore_suja_bloqueante(raiz, a.de)
    if suja and not a.forcar:
        gravar_status(raiz, estado="erro", erro="arvore Git suja")
        print("PARADO: ha mudancas nao commitadas:\n" + "\n".join("  " + x for x in suja[:10]) + "\nFaca commit (ou descarte) e rode de novo." + dica(suja))
        return 1
    livre = memoria_livre_gb()
    if livre is not None and livre < a.min_gb and not a.forcar:
        gravar_status(raiz, estado="erro", erro=f"memoria livre {livre:.1f} GB")
        print(f"PARADO: {livre:.1f} GB livres (precisa de {a.min_gb:.0f} GB). Feche navegador, Teams e outros notebooks.")
        return 1
    if a.de == "02" and not a.sem_02:
        log(raiz, "Atencao: o notebook 02 regera a coorte e o artefato (hash pode mudar). Por isso a cadeia inteira e reexecutada em ordem.")
    inicio = agora()
    antigos = ler_status(raiz).get("feitos", []) if a.de != "02" else []
    gravar_status(raiz, estado="rodando", pid=os.getpid(), inicio=inicio, atual=None, erro=None, feitos=antigos, total=len(nbs), de=a.de)
    impedir_suspensao()
    log(raiz, f"Cadeia iniciada: {len(nbs)} notebook(s), a partir do {a.de}.")
    feitos = list(antigos)
    for nb in nbs:
        num = nb.name[:2]
        gravar_status(raiz, atual=nb.name)
        log(raiz, f"=== {nb.name} ===")
        t0, desde = time.time(), agora().replace("T", "T")
        desde_local = datetime.now().isoformat(timespec="seconds")
        cmd = [sys.executable, "tools/medir_notebook.py", f"notebooks/{nb.name}", "--salvar-no-lugar", "--limite-mb", str(a.limite_mb),
               "--limite-s", str(LIMITE_S.get(num, 3600))]
        with p["log"].open("a", encoding="utf-8") as fh:
            rc = subprocess.run(cmd, cwd=raiz, env=ambiente(), stdout=fh, stderr=subprocess.STDOUT).returncode
        dur = time.time() - t0
        perf = linha_perf(raiz, nb.name, desde_local)
        pico = float(perf.get("pico_rss_mb") or 0)
        feitos = [f for f in feitos if f.get("nb") != nb.name] + [{"nb": nb.name, "duracao_s": round(float(perf.get("duracao_s") or dur), 1), "pico_mb": pico, "codigo": rc}]
        gravar_status(raiz, feitos=feitos)
        if rc != 0:
            cauda = "\n".join((p["log"].read_text(encoding="utf-8", errors="replace").splitlines())[-25:])
            gravar_status(raiz, estado="erro", erro=f"{nb.name} terminou com codigo {rc}", atual=None)
            log(raiz, f"PAROU EM {nb.name} (codigo {rc}). Ultimas linhas do log:\n{cauda}")
            log(raiz, f"Corrija sem mudar a logica do estudo e retome: cadeia.py iniciar --de {num}  (ou mande o erro para a IA, card #126).")
            return 2
        log(raiz, f"{nb.name}: ok em {dur / 60:.1f} min, pico {pico / 1024:.1f} GB")
    gravar_status(raiz, estado="documentando", atual=None)
    rc = documentar(raiz, a, feitos)
    gravar_status(raiz, estado="ok" if rc == 0 else "erro", erro=None if rc == 0 else "documentacao ou commit falhou (veja o log)", fim=agora())
    log(raiz, "CADEIA CONCLUIDA." if rc == 0 else "Cadeia executada, mas a etapa de documentacao parou: veja o log.")
    return rc


# ------------------------------------------------------------------ documentar
def paragrafo(feitos: list[dict]) -> str:
    total = sum(float(f.get("duracao_s") or 0) for f in feitos) / 60
    pico = max([float(f.get("pico_mb") or 0) for f in feitos] or [0]) / 1024
    ver = ".".join(map(str, sys.version_info[:3]))
    mem = f", com pico de {pico:.1f} GB de memoria" if pico else ""
    return (f"Tempo e memoria (maquina oficial): a cadeia de notebooks 02 a 10 leva cerca de {total:.0f} min{mem}. "
            "Os notebooks 01 (download dos dados) e 11 (abertura unica do teste) ficam fora dessa execucao. "
            f"Testado com Python {ver}; versoes exatas em `requirements-lock.txt`.")


def atualizar_readme(raiz: Path, texto: str) -> str:
    rp = raiz / "README.md"
    if not rp.is_file():
        return "README.md nao existe (pulado)"
    bruto = rp.read_bytes().decode("utf-8")
    nl = "\r\n" if "\r\n" in bruto else "\n"
    t = bruto.replace("\r\n", "\n")
    bloco = f"{INI}\n{texto}\n{FIM}"
    if INI in t and FIM in t:
        novo = re.sub(re.escape(INI) + r".*?" + re.escape(FIM), lambda m: bloco, t, flags=re.S)
        onde = "bloco existente trocado"
    else:
        linhas = t.split("\n")
        i = next((k for k, ln in enumerate(linhas) if "SRAG_ENSAIO=1" in ln), None)
        if i is None:
            novo = t.rstrip("\n") + "\n\n## Tempo e memoria\n\n" + bloco + "\n"
            onde = "secao nova no fim do README"
        else:
            j = i
            while j + 1 < len(linhas) and linhas[j + 1].strip() != "":
                j += 1
            linhas[j + 1:j + 1] = ["", bloco]
            novo = "\n".join(linhas)
            onde = "depois do paragrafo que cita SRAG_ENSAIO=1"
    rp.write_bytes(novo.replace("\n", nl).encode("utf-8"))
    return onde


def atualizar_pyproject(raiz: Path) -> str:
    pp = raiz / "pyproject.toml"
    if not pp.is_file():
        return "pyproject.toml nao existe (pulado)"
    bruto = pp.read_bytes().decode("utf-8")
    nl = "\r\n" if "\r\n" in bruto else "\n"
    t = bruto.replace("\r\n", "\n")
    cls = f"Programming Language :: Python :: {sys.version_info.major}.{sys.version_info.minor}"
    if cls in t:
        return f"ja tem '{cls}'"
    linhas = t.split("\n")
    idx = [i for i, ln in enumerate(linhas) if "Programming Language :: Python :: 3." in ln]
    if not idx:
        return "sem classificadores de Python no pyproject (pulado)"
    modelo = linhas[idx[-1]]
    indent = modelo[: len(modelo) - len(modelo.lstrip())]
    linhas.insert(idx[-1] + 1, f'{indent}"{cls}",')
    novo = "\n".join(linhas)
    try:
        import tomllib

        tomllib.loads(novo)
    except ImportError:
        pass
    except Exception as exc:  # noqa: BLE001
        return f"NAO alterado: o TOML ficaria invalido ({exc})"
    pp.write_bytes(novo.replace("\n", nl).encode("utf-8"))
    return f"acrescentado '{cls}'"


def documentar(raiz: Path, a, feitos: list[dict] | None = None) -> int:
    p = caminhos(raiz)
    feitos = feitos if feitos is not None else ler_status(raiz).get("feitos", [])
    if not feitos:
        log(raiz, "Sem dados de execucao: rode a cadeia antes (cadeia.py iniciar).")
        return 1
    log(raiz, "--- documentacao ---")
    if _existe("limpar_caminhos"):
        r = subprocess.run(_cmd("limpar_caminhos", "--raiz", str(raiz), "--pastas", "notebooks", "--aplicar"), cwd=raiz, capture_output=True, text=True, encoding="utf-8", errors="replace", env=_env_zip(ambiente()))
        log(raiz, "caminhos pessoais nos notebooks: " + ("limpos" if r.returncode == 0 else f"FALHOU (codigo {r.returncode})\n{r.stdout[-600:]}"))
        if r.returncode != 0:
            return 1
    else:
        log(raiz, "AVISO: limpar_caminhos.py nao esta ao lado do cadeia.py; os notebooks podem ter caminhos pessoais.")
    r = subprocess.run([sys.executable, "-m", "pip", "freeze", "--exclude-editable"], cwd=raiz, capture_output=True, text=True, encoding="utf-8", errors="replace")
    if r.returncode == 0 and r.stdout.strip():
        (raiz / "requirements-lock.txt").write_text(r.stdout.strip() + "\n", encoding="utf-8")
        log(raiz, f"requirements-lock.txt gravado ({len(r.stdout.splitlines())} pacotes)")
    else:
        log(raiz, "pip freeze FALHOU: requirements-lock.txt nao foi gravado")
        return 1
    log(raiz, "pyproject.toml: " + atualizar_pyproject(raiz))
    texto = paragrafo(feitos)
    log(raiz, "README.md: " + atualizar_readme(raiz, texto))
    linhas = ["# Cadeia de notebooks", "", f"Gerado em {agora()}", "", "| Notebook | Tempo (min) | Pico (GB) | Codigo |", "|---|---|---|---|"]
    linhas += [f"| {f['nb']} | {float(f['duracao_s']) / 60:.1f} | {float(f['pico_mb']) / 1024:.1f} | {f['codigo']} |" for f in feitos]
    linhas += ["", texto, ""]
    p["resumo"].write_text("\n".join(linhas), encoding="utf-8")
    t = subprocess.run([sys.executable, "-m", "pytest", "-q", "-p", "no:cacheprovider"], cwd=raiz, capture_output=True, text=True, encoding="utf-8", errors="replace", env=ambiente())
    ultima = (t.stdout.strip().splitlines() or [""])[-1]
    log(raiz, f"pytest rapido: {'OK' if t.returncode == 0 else 'FALHOU'} | {ultima}")
    if t.returncode != 0:
        log(raiz, "Os testes falharam depois da cadeia: NAO foi feito commit. Veja a saida do pytest e chame a IA (card #126).")
        return 1
    if a.sem_commit:
        log(raiz, "--sem-commit: nada foi commitado.")
        return 0
    status = git(raiz, "status", "--porcelain", "--untracked-files=all") or ""
    inesperados = []
    for ln in status.splitlines():
        arq = ln[3:].strip().strip('"')
        if " -> " in arq:
            arq = arq.split(" -> ")[-1]
        if "__pycache__" in arq:
            continue
        if not arq.startswith(PERMITIDOS):
            inesperados.append(arq)
    if inesperados:
        log(raiz, "PARADO antes do commit: arquivos inesperados mudaram: " + ", ".join(inesperados[:8]) + ". Confira com git status.")
        return 1
    if not status:
        log(raiz, "Nada mudou nos arquivos versionados (nada para commitar).")
        return 0
    if git(raiz, "add", "-A") is None or git(raiz, "commit", "-m", "cadeia 02 a 10 executada [done:#126] [done:#195] [done:#170] [done:#175]") is None:
        log(raiz, "git commit FALHOU")
        return 1
    ramo = git(raiz, "rev-parse", "--abbrev-ref", "HEAD") or "HEAD"
    ok = git(raiz, "push") is not None or git(raiz, "push", "-u", "origin", ramo) is not None
    log(raiz, f"commit feito e {'publicado' if ok else 'NAO publicado (rode: git push)'} no ramo {ramo}")
    return 0 if ok else 1


# ------------------------------------------------------------------ iniciar / status
def cmd_iniciar(raiz: Path, a) -> int:
    st = ler_status(raiz)
    if st.get("estado") in ("rodando", "documentando") and vivo(st.get("pid")):
        print(f"JA ESTA RODANDO (PID {st.get('pid')}). Use: cadeia.py status")
        return 1
    p = caminhos(raiz)
    p["pasta"].mkdir(parents=True, exist_ok=True)
    args = _cmd("cadeia", "executar", "--raiz", str(raiz), "--de", a.de, "--limite-mb", str(a.limite_mb), "--min-gb", str(a.min_gb))
    for flag, on in (("--sem-02", a.sem_02), ("--sem-commit", a.sem_commit), ("--forcar", a.forcar)):
        if on:
            args.append(flag)
    # a primeira validacao (arvore limpa e memoria) roda aqui, para o erro aparecer na tela e nao so no log
    suja = arvore_suja_bloqueante(raiz, a.de)
    if suja and not a.forcar:
        print("PARADO: ha mudancas nao commitadas:\n" + "\n".join("  " + x for x in suja[:10]) + dica(suja))
        return 1
    livre = memoria_livre_gb()
    if livre is not None and livre < a.min_gb and not a.forcar:
        print(f"PARADO: {livre:.1f} GB livres (precisa de {a.min_gb:.0f} GB). Feche navegador, Teams e outros notebooks.")
        return 1
    saida = p["log"].open("a", encoding="utf-8")
    kw: dict = {"cwd": raiz, "stdout": saida, "stderr": subprocess.STDOUT, "stdin": subprocess.DEVNULL, "env": _env_zip({**ambiente(), "CADEIA_BG": "1"})}
    if os.name == "nt":
        kw["creationflags"] = 0x00000008 | 0x00000200 | 0x08000000
    else:
        kw["start_new_session"] = True
    proc = subprocess.Popen(args, **kw)
    gravar_status(raiz, estado="rodando", pid=proc.pid, inicio=agora(), atual=None, erro=None, feitos=[] if a.de == "02" else ler_status(raiz).get("feitos", []))
    print(f"Cadeia iniciada em segundo plano (PID {proc.pid}). Pode continuar usando o terminal; nao feche o computador nem o desligue.")
    print("Acompanhe com:  .\\.venv\\Scripts\\python.exe tools\\G9_final\\cadeia.py status")
    return 0


def cmd_status(raiz: Path, a) -> int:
    st = ler_status(raiz)
    if not st:
        print("Nenhuma cadeia iniciada nesta pasta ainda.")
        return 1
    estado = st.get("estado")
    if estado in ("rodando", "documentando") and not vivo(st.get("pid")):
        estado = "INTERROMPIDA (o processo nao existe mais; veja o log)"
    print(f"Estado: {estado} | atual: {st.get('atual')} | inicio: {st.get('inicio')} | atualizado: {st.get('atualizado_em')}")
    for f in st.get("feitos", []):
        print(f"  {f['nb']:38s} {float(f['duracao_s']) / 60:6.1f} min  pico {float(f['pico_mb']) / 1024:5.1f} GB  codigo {f['codigo']}")
    if st.get("erro"):
        print("ERRO:", st["erro"])
    lg = caminhos(raiz)["log"]
    if lg.is_file():
        print("--- ultimas linhas do log ---")
        print("\n".join(lg.read_text(encoding="utf-8", errors="replace").splitlines()[-12:]))
    return {"ok": 0}.get(estado, 3 if estado in ("rodando", "documentando") else 1)


def main() -> int:
    for s in (sys.stdout, sys.stderr):
        try:
            s.reconfigure(encoding="utf-8", errors="replace", line_buffering=True)
        except (AttributeError, ValueError):
            pass
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("acao", choices=["iniciar", "executar", "status", "documentar"])
    ap.add_argument("--raiz", type=Path, default=Path.cwd())
    ap.add_argument("--de", default="02", choices=NUMEROS, help="numero do primeiro notebook (para retomar)")
    ap.add_argument("--sem-02", action="store_true", help="pula o 02 (so se tiver certeza de que o artefato nao precisa ser regerado)")
    ap.add_argument("--sem-commit", action="store_true")
    ap.add_argument("--forcar", action="store_true", help="ignora arvore suja e memoria baixa")
    ap.add_argument("--limite-mb", type=int, default=12288)
    ap.add_argument("--min-gb", type=float, default=8.0)
    a = ap.parse_args()
    raiz = a.raiz.resolve()
    return {"iniciar": cmd_iniciar, "executar": cmd_executar, "status": cmd_status, "documentar": lambda r, x: documentar(r, x)}[a.acao](raiz, a)


if __name__ == "__main__":
    sys.exit(main())
