#!/usr/bin/env python3
r"""Atualiza o TEXTO dos cards no PROJECT_STATUS_TEXT.md da sua pasta (prévia local). Depois, clique em "Publicar edicoes locais".

Uso (na raiz do repositorio):  [antes: $env:PYTHONPATH = "tools\G9_final.zip"]
    .\.venv\Scripts\python.exe ..\atualizar_painel.py             (aplica; guarda copia em .srag-status-local\backups)
    .\.venv\Scripts\python.exe ..\atualizar_painel.py --simular   (so mostra o que mudaria)

O que muda (versao 7 do painel): o card #126 vira "Executar TODOS os notebooks (02 a 10) e atualizar a documentacao, antes do G9",
muito detalhado e com o atalho cadeia.py; o #195 sai (incorporado ao #126); os cards #188, #192, #165, #189, #190, #157, #194 e
os textos gerais (subtitulo, cronograma, pessoas, caminho critico, aviso) acompanham. Cada troca e conferida: se um trecho nao for
encontrado, o script avisa e segue (nada e inventado). No fim roda `server.py validar`; se o painel reclamar, devolve o arquivo original.
"""
from __future__ import annotations

import argparse
import re
import shutil
import subprocess
import sys
from datetime import datetime
from pathlib import Path

ARQ = "PROJECT_STATUS_TEXT.md"

# ----------------------------------------------------------------------------- bloco para IA (mesmo padrao dos outros cards)
BTN = ('<div class="aiact" style="margin:6px 0"><button type="button" '
       'style="font:inherit;font-size:.85rem;font-weight:700;border:1px solid var(--acc2);background:var(--acc2);color:#fff;border-radius:8px;padding:6px 12px;cursor:pointer" '
       'onclick="var b=this,p=b.parentNode.nextElementSibling,t=p?p.innerText:\'\','
       'ok=function(){b.textContent=\'✓ Copiado!\';setTimeout(function(){b.textContent=\'📋 Copiar instruções para a IA\'},1800)},'
       'fb=function(){var a=document.createElement(\'textarea\');a.value=t;document.body.appendChild(a);a.select();try{document.execCommand(\'copy\')}catch(e){}document.body.removeChild(a);ok()};'
       'if(navigator.clipboard&amp;&amp;navigator.clipboard.writeText){navigator.clipboard.writeText(t).then(ok,fb)}else{fb()}">'
       '📋 Copiar instruções para a IA</button></div>')

REGRAS_IA = """REGRAS DO USUÁRIO (valem sempre)
- Se faltar arquivo ou contexto essencial, PARE e diga exatamente o que falta. Não adivinhe e não trabalhe só com trechos.
- Todo script começa por um relatório executado numa cópia, sem alterar o repositório. Só grava com flag explícita (--aplicar).
- Entregue código em blocos completos, prontos para copiar e colar. Diga qual trecho substituir (mostre as 4 primeiras e as 4 últimas linhas do trecho atual), o que fica antes e depois, e o destino de tudo o que está entre as âncoras (apague, mantenha ou "o novo bloco já contém").
- PowerShell: cada bloco em UMA linha, sem quebras. Python no terminal: sempre `.\\.venv\\Scripts\\python.exe`. Se vários testes cabem num comando, entregue só esse comando.
- Comentários de código: português, só o essencial, frases bem curtas. Mensagens de commit: português, bem curtas e pouco descritivas.
- Antes de entregar, releia o que vai imprimir à procura de caracteres estranhos e artefatos de formatação."""

MAPA = """MAPA ATUAL DO PROJETO (branch enxugamento, 05/11/2026)
- Projeto acadêmico SRAG (SIVEP-Gripe): estimar o risco de óbito por SRAG na internação. Windows + PowerShell, ambiente em .venv.
- Notebooks: 01_extracao, 02_coorte_definitiva, 03_eda_primeira_passagem, 04_eda_temporal_agrupamento, 05_supervisionado_pilotos, 06_pipeline_supervisionado, 07_baseline_logistica, 08_ablacoes_variaveis, 09_ajuste_fino, 10_calibracao_limiar, 11_validacao_final (abre o teste uma única vez).
- src/: config.py, dados.py, features.py, modelos.py, avaliacao.py, registro.py. tests/: um arquivo por tema. tools/: medir_notebook.py executa, salva e mede um notebook.
- Configuração única: configs/supervised.yaml (gates G1 a G9; G9_holdout controla a abertura do teste). Decisões: docs/decisoes.md (histórico em docs/historico/).
- Teste fechado: test_ref e test_pandemic só abrem no notebook 11, uma vez, com G9 aprovado. Nunca leia esses blocos em outro lugar."""


def bloco_ia(titulo, objetivo, pedir, passos, aceite, nao, entrega):
    t = [f"TAREFA: {titulo}", "", "OBJETIVO", objetivo.strip(), "", MAPA, "", "ARQUIVOS QUE VOCÊ PRECISA TER (se faltar algum, pare e peça ao usuário)"]
    t += [f"- {x}" for x in pedir] + ["", "PASSOS"] + [f"{i}. {x}" for i, x in enumerate(passos, 1)]
    t += ["", "CRITÉRIOS DE ACEITE (verificáveis)"] + [f"- {x}" for x in aceite] + ["", "NÃO FAÇA"] + [f"- {x}" for x in nao]
    t += ["", "FORMATO DA ENTREGA", entrega.strip(), "", REGRAS_IA]
    txt = "\n".join(t)
    assert "~~~" not in txt
    return BTN + "\n\n~~~text\n" + txt + "\n~~~"


# ----------------------------------------------------------------------------- card #126 novo
NBS = ["02_coorte_definitiva", "03_eda_primeira_passagem", "04_eda_temporal_agrupamento", "05_supervisionado_pilotos", "06_pipeline_supervisionado",
       "07_baseline_logistica", "08_ablacoes_variaveis", "09_ajuste_fino", "10_calibracao_limiar"]
LISTA_PS = ",".join(f"'{n}'" for n in NBS)


def card_126() -> str:
    arquivos = ", ".join([f"notebooks/{n}.ipynb" for n in NBS] + ["requirements-lock.txt", "pyproject.toml", "README.md"])
    fz = r"""
**Dono:** Pessoa C · **Tempo:** ≈ 15 min de trabalho + ≈ 30 a 60 min de máquina (sem ninguém acompanhar) · **Começa quando:** #192 commitado e publicado · **Antes de:** #193 (ensaio do notebook 11).

> [!exemplo] **Atalho automático:** `.\.venv\Scripts\python.exe ..\cadeia.py iniciar`
> Roda **em segundo plano** os notebooks 02 a 10, na ordem, salvando cada um no lugar e medindo tempo e memória; **para no primeiro erro**; ao terminar, **atualiza a documentação sozinho** (tira caminhos pessoais dos notebooks, grava `requirements-lock.txt`, acrescenta a versão do Python ao `pyproject.toml`, escreve o parágrafo de tempo e memória no `README.md`), roda o `pytest`, faz **commit** (`cadeia 02 a 10 executada [done:#126]`) e **push**. Acompanhe com `.\.venv\Scripts\python.exe ..\cadeia.py status`. Se um notebook falhar, corrija e retome com `... cadeia.py iniciar --de 05` (troque 05 pelo número que parou).
> O script foi testado com notebooks simulados (segundo plano, falha, retomada, documentação e commit), **não com os notebooks reais**: se ele recusar ou falhar, siga os passos manuais mais abaixo, que continuam valendo.

#### Antes de começar (5 min)
1. **Ramo e árvore limpos:** `git switch enxugamento; git pull --ff-only; git status --short` (o último não pode imprimir nada).
2. **Memória:** feche navegador, Teams, Excel e outros notebooks. Precisa de **≥ 8 GB livres** (o script confere e recusa se faltar).
3. **Energia:** computador na tomada. O script pede ao Windows para não suspender enquanto roda, mas desligue também a suspensão automática por garantia.
4. **Scripts:** todos os scripts do lote precisam estar na **pasta acima do repositório**. O `pre_g9.py` gera `..\scripts_g9_completo.zip` com todos eles; se esta máquina ainda não os tem, copie esse zip para `..` e rode (um comando): `Expand-Archive -Path ..\scripts_g9_completo.zip -DestinationPath .. -Force`.
5. **Combine** no grupo: "máquina ocupada por ≈ 1 h". Não rode nada pesado junto e **não toque em `src/`, `configs/` nem nos notebooks** enquanto a cadeia roda.

#### Passo a passo (para a pessoa)
1. **Inicie a cadeia** (um comando; devolve o terminal em segundos):
```powershell
.\.venv\Scripts\python.exe ..\cadeia.py iniciar
```
   Esperado: "Cadeia iniciada em segundo plano (PID ...)". Se aparecer `PARADO` (árvore suja ou pouca memória), resolva e repita.
2. **Acompanhe** quando quiser (não interfere na execução):
```powershell
.\.venv\Scripts\python.exe ..\cadeia.py status
```
   Mostra o estado (`rodando`, `documentando`, `ok` ou `erro`), o notebook atual, o tempo e o pico de memória de cada um já feito e as últimas linhas do log (`outputs\final\cadeia.log`).
3. **Se parar com erro**, leia a mensagem e use a tabela:

| O que aparece | Causa provável | O que fazer |
|---|---|---|
| `PARADO: há mudanças não commitadas` | árvore Git suja | commit ou descarte e repita o passo 1 |
| `PARADO: x GB livres` | pouca memória | feche programas e repita |
| `ABORTADO: não achei exatamente um arquivo para: ...` | a renomeação (#192) não foi aplicada | rode o `pre_g9.py` ou aplique o #192 antes |
| `PAROU EM 02_coorte_definitiva` | falta a base de dados ou erro na coorte | confira se a base está na máquina (`data/`); se faltar, chame a equipe; **não rode o 01 por conta própria sem combinar** |
| `PAROU EM 0X` com `MemoryError` | memória acabou | feche programas e retome: `... cadeia.py iniciar --de 0X` |
| `ACIMA DO LIMITE` de memória no log | o notebook rodou, mas passou do teto de 12 GB | retome com `... cadeia.py iniciar --de 0X --limite-mb 16384` |
| erro de código ou de manifesto em um notebook | algo no código ou no YAML | **não mude a lógica do estudo**: cole o erro na IA (bloco abaixo) e retome do mesmo notebook |
| `pytest rápido: FALHOU` na etapa de documentação | teste quebrou depois da cadeia | nada foi commitado; leia a saída, cole na IA e rode `... cadeia.py documentar` depois de corrigir |

4. **Quando disser `CADEIA CONCLUIDA`** (status `ok`), o script já fez commit e push. Confira em **um comando** (esperado: o commit `cadeia 02 a 10 executada [done:#126]` e nada em `git status`):
```powershell
git log --oneline -3; git status --short; git grep -n -I -i -E "olivem85|OneDrive - |C:.{1,4}Users" -- notebooks README.md
```
5. **Confira o manifesto do notebook 10** (esperado: `aprovado aprovado 6cb2c96bca846c7d precision 0.1178`):
```powershell
$m = Get-ChildItem outputs\tables\10_calibracao_limiar_*_manifesto.json | Sort-Object LastWriteTime | Select-Object -Last 1 | Get-Content -Raw | ConvertFrom-Json; "$($m.g7_status) $($m.g8_status) $($m.config_modelo_hash) $($m.limiar_metrica) $($m.escolhas.hist_gradient_boosting.limiar)"
```
   Se o hash ou o limiar forem diferentes, **pare** e chame a equipe: o YAML dos modelos mudou, ou o artefato regerado pelo notebook 02 levou a outro resultado. Não copie o limiar para o YAML sem decisão registrada no `docs/decisoes.md`.
6. **Confira que todos os notebooks ficaram executados e sem erro** (esperado: `0` células sem execução e `0` erros em cada linha):
```powershell
.\.venv\Scripts\python.exe -c "import json,glob; [print(f.split('\\')[-1], 'sem execucao:', sum(1 for c in json.load(open(f,encoding='utf-8'))['cells'] if c['cell_type']=='code' and ''.join(c['source']).strip() and c.get('execution_count') is None), '| erros:', sum(1 for c in json.load(open(f,encoding='utf-8'))['cells'] for o in c.get('outputs',[]) if o.get('output_type')=='error')) for f in sorted(glob.glob('notebooks/0[2-9]_*.ipynb')+glob.glob('notebooks/10_*.ipynb'))]"
```
7. **Abra o `outputs\final\cadeia.md`** (tabela de tempo e memória) e **comente neste card**: tempo total, pico de memória e o commit. Avise o grupo: "cadeia concluída; começo o ensaio (#193)".

#### Passo a passo manual (plano B, sem o script)
1. **Execute os nove notebooks em ordem** (um comando; para no primeiro erro; cada notebook é salvo no lugar e mede tempo e memória):
```powershell
foreach ($n in __LISTA__) { .\.venv\Scripts\python.exe tools\medir_notebook.py "notebooks\$n.ipynb" --salvar-no-lugar --limite-mb 12288 --limite-s 10800; if ($LASTEXITCODE -ne 0) { Write-Host "PAROU EM $n"; break } }
```
   Para retomar depois de um erro, repita o comando só com os nomes que faltam.
2. **Tire os caminhos pessoais dos notebooks** (relatório primeiro; nada muda):
```powershell
.\.venv\Scripts\python.exe ..\limpar_caminhos.py --pastas notebooks
```
   Se o relatório estiver certo, aplique: `.\.venv\Scripts\python.exe ..\limpar_caminhos.py --pastas notebooks --aplicar`.
3. **Grave as versões exatas** do ambiente:
```powershell
.\.venv\Scripts\python.exe -m pip freeze --exclude-editable | Out-File -Encoding utf8 requirements-lock.txt
```
4. **`pyproject.toml`:** descubra a versão com `.\.venv\Scripts\python.exe --version`. Na lista `classifiers`, **depois** da última linha `"Programming Language :: Python :: 3.xx",`, acrescente a linha da versão usada (por exemplo `"Programming Language :: Python :: 3.14",`), com o mesmo recuo. Confira: `.\.venv\Scripts\python.exe -c "import tomllib; tomllib.load(open('pyproject.toml','rb')); print('pyproject ok')"`.
5. **`README.md`, seção "Como rodar":** **depois** do parágrafo que termina em "use `SRAG_ENSAIO=1`." acrescente (os números vêm de `Get-Content outputs\final\performance_notebooks.csv -Tail 10`: some os tempos dos nove notebooks e pegue o maior pico):
```markdown
Tempo e memória (máquina oficial): a cadeia de notebooks 02 a 10 leva cerca de ⟨X⟩ min, com pico de ⟨Y⟩ GB de memória. Os notebooks 01 (download dos dados) e 11 (abertura única do teste) ficam fora dessa execução. Testado com Python ⟨versão⟩; versões exatas em `requirements-lock.txt`.
```
6. **Teste, commit e publicação** (um comando; o `git status` antes do commit deve listar só notebooks, lock, pyproject e README):
```powershell
.\.venv\Scripts\python.exe -m pytest -q; git status --short; git add -A; git commit -m "cadeia 02 a 10 executada [done:#126]"; git push
```
7. Siga os passos 5 a 7 do passo a passo principal (manifesto, notebooks sem erro, comentário no card).

#### Documentação que muda por causa desta tarefa (resumo)
| Onde | Bloco | O que muda | Quem faz |
|---|---|---|---|
| `README.md` | "Como rodar" | parágrafo de tempo, memória e versão do Python (entre os marcadores `<!-- cadeia:inicio -->` e `<!-- cadeia:fim -->`) | `cadeia.py` |
| `requirements-lock.txt` | arquivo novo | versões exatas do ambiente | `cadeia.py` |
| `pyproject.toml` | `classifiers` | linha da versão do Python usada | `cadeia.py` |
| Notebooks 02 a 10 | saídas salvas | caminhos pessoais trocados por `<REPO>` e `<HOME>` | `cadeia.py` + `limpar_caminhos.py` |
| `outputs\final\cadeia.md` | resumo local (não vai ao Git) | tabela de tempo e memória | `cadeia.py` |
| Painel | este card | comentário com tempo, pico e commit | pessoa |

#### Automação sugerida
> [!exemplo] Estratégia do `cadeia.py` (já entregue)
> **Descoberta:** acha cada notebook pelo número (`02_*` a `10_*`) e recusa se faltar ou houver dois. **Segundo plano:** `iniciar` abre um processo desanexado (no Windows, sem janela) que grava `outputs\final\cadeia_status.json` e `cadeia.log`; `status` só lê esses arquivos. **Segurança:** recusa árvore suja (na retomada aceita só notebooks modificados) e pouca memória; remove `SRAG_ENSAIO`, `SRAG_ALLOW_TEST_REOPEN` e `SRAG_ALLOW_DIRTY` do ambiente dos notebooks; nunca roda o 01 nem o 11. **Erro:** para no primeiro, guarda a cauda do log e diz como retomar. **Documentação:** só depois de a cadeia inteira passar; o commit só acontece se o `pytest` passar e se os únicos arquivos alterados forem notebooks, `requirements-lock.txt`, `pyproject.toml`, `README.md` ou `docs/`.

#### Para a IA (copie e cole na conversa)
""" + bloco_ia(
        "#126 · Executar todos os notebooks (02 a 10) e atualizar a documentação, antes do G9",
        "Acompanhar a execução completa e ordenada dos notebooks 02 a 10 (cadeia.py), diagnosticar qualquer parada SEM mudar a lógica do estudo e conferir que a documentação (README, requirements-lock.txt, pyproject) e o manifesto do notebook 10 estão corretos para o G9.",
        ["A saída de `cadeia.py status` e o arquivo outputs/final/cadeia.log (últimas 80 linhas).", "Se houve erro: a mensagem completa e o notebook que parou.",
         "O manifesto novo outputs/tables/10_calibracao_limiar_final_<data>_manifesto.json e configs/supervised.yaml (blocos models, features, limiar, calibracao, gates).", "outputs/final/cadeia.md e git log --oneline -3."],
        ["Se parou: classifique a causa (memória, dado ausente, erro de código, trava de manifesto) e proponha a correção mínima, com âncoras (4 linhas antes e 4 depois) e a linha de PowerShell para retomar (`cadeia.py iniciar --de NN`).",
         "Se terminou: compare o config_modelo_hash com 6cb2c96bca846c7d e o limiar com limiar.otimo do YAML (0,1178). Se diferirem, pare e explique.",
         "Confira o parágrafo do README (tempo, memória, versão do Python) e se o requirements-lock.txt tem scikit-learn==, pandas==, numpy== e pyarrow==.",
         "Diga em uma frase se o #193 (ensaio) pode começar."],
        ["Os notebooks 02 a 10 estão salvos com todas as células executadas e sem erro.", "git status limpo e o commit 'cadeia 02 a 10 executada [done:#126]' publicado.",
         "O manifesto do notebook 10 tem g7_status = aprovado, g8_status = aprovado, limiar_metrica = precision e o hash dos modelos esperado.", "Nenhum caminho pessoal (olivem85, OneDrive - ) nos notebooks."],
        ["Não rode os notebooks 01 e 11.", "Não edite src/, configs/ nem notebooks durante a cadeia.", "Não use SRAG_ENSAIO, SRAG_ALLOW_TEST_REOPEN nem SRAG_ALLOW_DIRTY.", "Não proponha mudar modelo, calibração ou limiar."],
        "Diagnóstico em 3 linhas + linhas de PowerShell (uma por linha). Só entregue código se houver erro.").strip("\n")
    fz = fz.replace("__LISTA__", LISTA_PS)
    u = r"""
Antes de abrir o teste (que só pode ser aberto **uma vez**), o projeto precisa estar **inteiro e coerente**: cada notebook salvo com as saídas do código final, o artefato e os manifestos com o mesmo hash, e a documentação descrevendo o que foi executado. Em vez de reexecutar só o notebook 10, a decisão de 05/11 é **reexecutar toda a cadeia, de ponta a ponta, antes do G9**. Este card incorpora o antigo #195 (cadeia e versões) e a limpeza de caminhos pessoais dos notebooks.

| Ordem | Notebook | O que faz | Por que roda aqui |
|---|---|---|---|
| 1 | `02_coorte_definitiva` | republica a coorte e **regera o artefato** supervisionado (partição 70/15/15) | roda **primeiro**: se o hash do artefato mudar, tudo o que vem depois precisa ser refeito |
| 2 | `03_eda_primeira_passagem` | análise exploratória inicial | saídas com o código final |
| 3 | `04_eda_temporal_agrupamento` | exploração temporal e agrupamento | saídas com o código final |
| 4 | `05_supervisionado_pilotos` | pilotos supervisionados | saídas com o código final |
| 5 | `06_pipeline_supervisionado` | pipeline de pré-processamento e modelo | saídas com o código final |
| 6 | `07_baseline_logistica` | baseline logístico | saídas com o código final |
| 7 | `08_ablacoes_variaveis` | ablações de variáveis | saídas com o código final |
| 8 | `09_ajuste_fino` | ajuste fino do boosting | saídas com o código final |
| 9 | `10_calibracao_limiar` | calibração (G7) e limiar (G8) | **gera o manifesto que o notebook 11 vai procurar** |

**Ficam de fora, de propósito:** o `01_extracao` (baixa os dados da internet; o README diz que ele fica sem saídas salvas) e o `11_validacao_final` (abre o teste: só roda no ensaio do #193 e uma vez no G9, #2).

**Ordem de grandeza:** de 30 a 60 min de máquina (a última medição, de 03/11, foi ≈ 31 min, com pico ≈ 4,1 GB). Use um computador com ≥ 8 GB livres.

> [!atenção] O notebook 02 regera o artefato
> Ele republica a coorte (com backup `.bak`) e regrava o artefato. É determinístico (hash por grupo, semente 42), mas, se o `dataset_sha256` mudar, o manifesto antigo do notebook 10 deixa de servir. É por isso que a cadeia vai até o 10, em ordem, numa única execução.
"""
    pb = r"""
- Os notebooks 04, 05, 06, 08, 09 e 10 foram salvos antes das últimas mudanças em `src/`, e os notebooks 01, 02, 03, 07 e 11 estão sem execução salva (snapshot de 05/11).
- Depois da renomeação das saídas (#192), os arquivos antigos de `outputs/` ficaram em `outputs/_antigo`: só a reexecução gera os nomes novos que o notebook 11 procura.
- Cada execução grava o **caminho completo da máquina** (`C:\Users\...\OneDrive - ...`) nas saídas dos notebooks. Isso precisa ser limpo antes de publicar (o script faz).
- O `README.md` não tem tempo, memória nem versão do Python; não existe `requirements-lock.txt`; o `pyproject.toml` não declara a versão do Python usada.
- O G9 só abre com a **árvore Git limpa**: tudo isso precisa estar commitado e publicado antes do ensaio (#193).
"""
    pq = [f"- notebook-executado: `notebooks/{n}.ipynb` | O notebook {n[:2]} está salvo com todas as células executadas e sem erro." for n in NBS]
    pq += ["- existe: `requirements-lock.txt` | O arquivo com as versões exatas da máquina oficial existe.",
           "- contem: `requirements-lock.txt` :: `scikit-learn==` | O arquivo fixa a versão do scikit-learn.",
           "- contem: `README.md` :: `requirements-lock.txt` | O README cita as versões exatas, o tempo e a memória da cadeia.",
           "- manual: | O manifesto novo do notebook 10 registra G7 e G8 aprovados, precision e o mesmo hash dos modelos (6cb2c96bca846c7d), e o git status ficou limpo depois do commit da cadeia."]
    meta = [("prioridade", "P1"), ("situação", "aberta"), ("estratégia", "desenvolver"), ("marco", "Pré-G9"), ("data ideal", "05/11"), ("responsável", "Pessoa C"), ("pessoas", "C"),
            ("fonte", "Decisão de 05/11: todos os notebooks são reexecutados antes do G9 (a versão anterior deste card só reexecutava o notebook 10); incorpora o antigo #195 e a limpeza de caminhos dos notebooks (#164)"),
            ("depende de", "#192"), ("tags", "cadeia, notebooks, reprodutibilidade, documentação, pré-G9, automatizável"), ("pilar", "Eficiência + Documentação"), ("carga", "1"),
            ("novo", "não"), ("professores", "não"), ("arquivos", arquivos)]
    L = ["## #126 · Executar TODOS os notebooks (02 a 10) em ordem e atualizar a documentação, antes do G9", ""] + [f"- {k}: {v}" for k, v in meta] + [""]
    L += ["### ① Para entender", "", u.strip("\n"), "", "### ② Problema", "", pb.strip("\n"), "", "### ③ O que fazer", "", fz.strip("\n"), "", "### ④ Pronto quando", ""] + pq + [""]
    return "\n".join(L)


# ----------------------------------------------------------------------------- operacoes de texto
class Doc:
    def __init__(self, texto: str):
        self.eol = "\r\n" if "\r\n" in texto else "\n"
        self.linhas = texto.replace("\r\n", "\n").split("\n")
        self.avisos: list[str] = []
        self.feitos: list[str] = []

    def texto(self) -> str:
        return self.eol.join(self.linhas)

    def _topo(self) -> list[tuple[int, str]]:
        achados, em_cerca = [], False
        for i, ln in enumerate(self.linhas):
            if re.match(r"^\s*(```|~~~)", ln):
                em_cerca = not em_cerca
            if not em_cerca and ln.startswith("## "):
                achados.append((i, ln))
        return achados

    def bloco(self, chave: str) -> tuple[int, int] | None:
        topo = self._topo()
        for k, (i, ln) in enumerate(topo):
            if (chave == "painel" and ln.startswith("## Painel")) or (chave != "painel" and re.match(rf"^## #{re.escape(chave)} · ", ln)):
                return i, (topo[k + 1][0] if k + 1 < len(topo) else len(self.linhas))
        return None

    def ler_bloco(self, chave: str) -> str | None:
        b = self.bloco(chave)
        return None if b is None else "\n".join(self.linhas[b[0]:b[1]])

    def trocar_bloco(self, chave: str, novo: str) -> bool:
        b = self.bloco(chave)
        linhas = novo.rstrip("\n").split("\n") + [""]
        if b is None:
            self.linhas = self.linhas[:-1] + [""] + linhas if self.linhas and self.linhas[-1] == "" else self.linhas + [""] + linhas
            self.feitos.append(f"#{chave}: card criado no fim do arquivo")
            return True
        self.linhas[b[0]:b[1]] = linhas
        self.feitos.append(f"#{chave}: card substituido")
        return True

    def _editar(self, chave: str, fn) -> bool:
        b = self.bloco(chave)
        if b is None:
            self.avisos.append(f"#{chave}: card nao encontrado")
            return False
        antigo = "\n".join(self.linhas[b[0]:b[1]])
        novo = fn(antigo)
        if novo == antigo:
            return False
        self.linhas[b[0]:b[1]] = novo.split("\n")
        return True

    def trocar(self, chave: str, velho: str, novo: str, rotulo: str) -> None:
        if self._editar(chave, lambda t: t.replace(velho, novo, 1) if velho in t else t):
            self.feitos.append(f"#{chave}: {rotulo}")
        else:
            ja = (self.ler_bloco(chave) or "")
            if novo and novo in ja:
                return
            self.avisos.append(f"#{chave}: trecho nao encontrado ({rotulo}); confira a mao")

    def trocar_todos(self, chave: str, velho: str, novo: str, rotulo: str) -> None:
        if self._editar(chave, lambda t: t.replace(velho, novo) if velho in t else t):
            self.feitos.append(f"#{chave}: {rotulo}")

    def meta(self, chave: str, campo: str, valor: str) -> None:
        def fn(t: str) -> str:
            ls = t.split("\n")
            fim = next((i for i, ln in enumerate(ls) if ln.startswith("### ")), len(ls))
            for i in range(fim):
                if ls[i].startswith(f"- {campo}:"):
                    ls[i] = f"- {campo}: {valor}"
                    return "\n".join(ls)
            ultimo = max((i for i in range(fim) if ls[i].startswith("- ")), default=1)
            ls.insert(ultimo + 1, f"- {campo}: {valor}")
            return "\n".join(ls)
        if self._editar(chave, fn):
            self.feitos.append(f"#{chave}: {campo} = {valor[:60]}")

    def atalho(self, chave: str, titulo: str, descricao: str) -> None:
        if f"**Atalho automático:** {titulo}" in (self.ler_bloco(chave) or ""):
            return
        caixa = f"\n> [!exemplo] **Atalho automático:** {titulo}\n> {descricao}\n"
        def fn(t: str) -> str:
            m = re.search(r"(?m)^(\*\*Dono:\*\*[^\n]*\n)", t)
            return t if not m else t[:m.end()] + caixa + t[m.end():]
        if self._editar(chave, fn):
            self.feitos.append(f"#{chave}: atalho automatico acrescentado")
        else:
            self.avisos.append(f"#{chave}: nao achei a linha 'Dono' para o atalho")

    def secao_painel(self, nome: str) -> tuple[int, int] | None:
        b = self.bloco("painel")
        if b is None:
            return None
        for i in range(b[0] + 1, b[1]):
            if self.linhas[i].strip() == f"### {nome}":
                fim = next((j for j in range(i + 1, b[1]) if self.linhas[j].startswith("### ")), b[1])
                return i, fim
        return None

    def trocar_secao(self, nome: str, texto: str) -> None:
        s = self.secao_painel(nome)
        novo = ["### " + nome, ""] + texto.strip("\n").split("\n") + [""]
        if s is None:
            b = self.bloco("painel")
            if b is None:
                self.avisos.append(f"painel: bloco nao encontrado ({nome})")
                return
            self.linhas[b[1]:b[1]] = novo
            self.feitos.append(f"painel: secao '{nome}' criada")
            return
        self.linhas[s[0]:s[1]] = novo
        self.feitos.append(f"painel: secao '{nome}' reescrita")

    def editar_secao(self, nome: str, fn, rotulo: str) -> None:
        s = self.secao_painel(nome)
        if s is None:
            self.avisos.append(f"painel: secao '{nome}' nao encontrada")
            return
        antigo = "\n".join(self.linhas[s[0]:s[1]])
        novo = fn(antigo)
        if novo == antigo:
            self.avisos.append(f"painel/{nome}: trecho nao encontrado ({rotulo}); confira a mao")
            return
        self.linhas[s[0]:s[1]] = novo.split("\n")
        self.feitos.append(f"painel/{nome}: {rotulo}")


# ----------------------------------------------------------------------------- as mudancas
def aplicar(d: Doc) -> None:
    d.trocar_bloco("126", card_126())
    d.meta("195", "removido", "05/11: incorporado ao #126 (todos os notebooks, 02 a 10, rodam antes do G9; lock, pyproject e README entram na mesma execução)")
    d.meta("195", "situação", "resolvida")

    d.trocar("192", "Por isso o **notebook 10 é reexecutado logo depois (#126)**. Os notebooks 03 a 09 só são reexecutados **depois do G9** (#195), e as tabelas deles ganham os nomes novos nessa hora.",
             "Por isso **todos os notebooks (02 a 10) são reexecutados logo depois (#126)**, o que regera as saídas com os nomes novos.", "texto do problema")
    d.trocar("192", "O notebook 10 precisa ser reexecutado (#126) antes do ensaio (#193).", "Os notebooks 02 a 10 precisam ser reexecutados (#126) antes do ensaio (#193).", "aviso do notebook 11")
    d.atalho("192", "`.\\.venv\\Scripts\\python.exe ..\\pre_g9.py`",
             "faz o #188 e o #192 juntos: testes completos, relatório e aplicação da renomeação, conferência do notebook 11, commit (`[done:#188] [done:#192]`), push e atualização do painel. Para no primeiro erro e não faz commit se algo falhar. Testado com repositório simulado, não com o real.")
    d.atalho("188", "`.\\.venv\\Scripts\\python.exe ..\\pre_g9.py`", "o mesmo comando do #192 faz o #188 (testes completos e push da branch) antes de renomear. Veja o #192.")

    d.atalho("165", "`.\\.venv\\Scripts\\python.exe ..\\pos_g9.py`", "o comando do pós-G9 roda o `calibracao_pos_g9.py --aplicar` (este card), as tabelas, a curva, os textos do G9 e a documentação, e fecha os cards. Veja o #194.")
    d.atalho("194", "`.\\.venv\\Scripts\\python.exe ..\\pos_g9.py`",
             "**rode na máquina oficial** (onde o G9 foi executado: ele lê `outputs/` e `data/`, que não vão para o Git). Depois que a Pessoa C terminar o G9 e publicar o commit, um comando roda o checklist `--depois`, a calibração (#165), as tabelas (#55), a curva (#176), gera os 5 blocos de texto e **aplica** os blocos em `docs/decisoes.md`, `README.md` e `configs/supervised.yaml` (passos 2 a 6 abaixo), tira comentários e caminhos (#189), monta `resultados/` (#157), roda o pytest, faz os commits (com `[done:#N]`), mescla na `main` e faz o push. Para no primeiro erro. Testado com repositório simulado, não com o real: se ele recusar, os passos manuais abaixo valem.")
    d.trocar("194", "**#195 (B)** → **#190 (A)** → **#189 (B)** → **#191 (B)**", "**#191 (B)** → **#190 (A)**", "ordem de trabalho depois da mescla")
    d.trocar("194", "**#195** (B), depois da cadeia", "**#126** (C), já feito antes do G9", "origem do bloco do README")

    d.atalho("189", "`.\\.venv\\Scripts\\python.exe ..\\pos_g9.py`", "o comando do pós-G9 já roda este lote (caminhos e comentários, com relatório, aplicação e pytest). Só use os passos abaixo se ele não tiver chegado até aqui.")
    d.meta("189", "depende de", "#194")
    d.trocar_todos("189", "depois** da cadeia do #195 (que regrava os caminhos pessoais e as saídas)", "depois** do G9 (o notebook 11 regrava os caminhos pessoais e as saídas)", "texto de abertura")
    d.trocar_todos("189", "#195 publicado e a `main` atualizada", "#194 concluído e a `main` atualizada", "condição de início")
    d.trocar_todos("189", "#195", "#126", "referências à cadeia")

    d.meta("190", "depende de", "#194")
    d.trocar_todos("190", "#195", "#126", "referências à cadeia")
    d.meta("191", "depende de", "#189")
    d.trocar_todos("191", "#195", "#126", "referências à cadeia")
    d.atalho("157", "`.\\.venv\\Scripts\\python.exe ..\\pos_g9.py`", "o comando do pós-G9 já roda o `montar_resultados.py --aplicar` e faz o commit de `resultados/`. Só use os passos abaixo se ele não tiver chegado até aqui.")
    d.meta("157", "depende de", "#194, #55")
    d.trocar_todos("157", "#195", "#126", "referências à cadeia")

    d.trocar_secao("Subtítulo", """Retrato de **05/11, dia da entrega**, sobre a branch `enxugamento` (a `main` recebe a branch no fim do #194). **G6, G7 e G8 aprovados; G9 pendente.** Painel **versão 7: só o essencial antes do G9, e a cadeia completa de notebooks volta para antes dele**. Restam **7 cards até a documentação do G9** (todos da Pessoa C), **8 depois** (Pessoas A e B) e **2 opcionais** (P4). Todo "③ O que fazer" tem passo a passo para a pessoa, automação sugerida (scripts com relatório antes de gravar) e bloco para a IA com botão de copiar.

**A entrega:** (1) o **link do GitHub (branch `main`, completa)** e (2) a **apresentação em PowerPoint** (#134, arquivo `entrega/Apresentacao_SRAG.pptx`).

**Dois comandos fazem quase tudo:** `pre_g9.py` (#188 e #192) agora e `pos_g9.py` (#2, #165, #194, #189, #157) depois do G9. No meio, a Pessoa C roda `cadeia.py iniciar` (#126: **todos os notebooks, 02 a 10**, em segundo plano, com a documentação atualizada sozinha).

**Regra de ordem:** testar, publicar e renomear (#188, #192) → **executar todos os notebooks e atualizar a documentação (#126)** → **ensaio e congelamento (#193)** → **G9, teste aberto uma vez (#2)** → calibração/O/E (#165) → **documentar o G9 e mesclar na main (#194)** → comentários e caminhos (#189) → comentários essenciais (#191) → Markdown (#190) → equidade (#55), limitações (#133), apresentação (#134), resultados (#157) → **fechar a entrega (#147)**.""")
    d.trocar_secao("Cronograma", """- **05/11 qui · 1 Preparar (Pessoa C)** — #188 testar e publicar a branch e #192 renomear as saídas: **um comando, `pre_g9.py`**
- **05/11 qui · 2 Cadeia completa (Pessoa C)** — **#126 executar TODOS os notebooks (02 a 10) e atualizar a documentação**: `cadeia.py iniciar` (segundo plano, ≈ 30 a 60 min de máquina)
- **05/11 qui · 3 Congelar (Pessoa C)** — **#193 ensaio do notebook 11 e checklist: "código congelado"**
- **05/11 qui · 4 G9 (Pessoa C + Equipe)** — **#2 aprovar e abrir o teste uma vez**; depois, **um comando, `pos_g9.py`**: #165 calibração, #194 documentar o G9 e mesclar na main, #189 comentários e caminhos, #157 resultados
- **05/11 qui · 5 Em paralelo, desde já (A e B)** — rascunho do #134 (apresentação) e do #133; **sem tocar em código**
- **05/11 qui · 6 Depois do #194, um de cada vez no repositório (A e B)** — B: #191 comentários essenciais · A: #190 Markdown · A: #55 equidade e #133 limitações · B: #134 apresentação com os números
- **05/11 qui · 7 Fechar (A)** — **#147 fechar a entrega**""")
    d.trocar_secao("Pessoas", """- **C (≈ 4,7 h, das quais ≈ 1 h de máquina)** — **todo o caminho até o G9 e a documentação dele**: #188 e #192 (`pre_g9.py`), **#126 (todos os notebooks)**, #193, **#2 (G9)**, #165 e #194 (`pos_g9.py`, inclui a mescla na `main`). Só a Pessoa C mexe em código até o G9.
- **B (≈ 3,4 h)** — depois do #194: #191 (comentários essenciais), #189 e #157 (só se o `pos_g9.py` não tiver feito) e a **apresentação (#134, dona)**. Opcional: #91.
- **A (≈ 3,4 h)** — depois do #194: #190 (Markdown), #55 (equidade), #133 (limitações e rastreabilidade) e **#147 (fechar a entrega)**. Antes do #194: só documentos (rascunhos).
- **Equipe** — aprovação do G9 e confirmação do congelamento (#2, #193). Opcional: #176 (B).""")
    d.trocar_secao("Caminho crítico", "#188 → #192 → #126 → #193 → #2 → #165 → #194 → #189 → #191 → #190 → #157 → #147 (e #134 em paralelo, antes do #147)")

    def aviso(t: str) -> str:
        t = t.replace("a cadeia 03 a 09 (#195), ", "")
        t = t.replace("a ordem é #195 → #189 → #191 → #190", "a ordem é #189 → #191 → #190")
        t = re.sub(r"3\. \*\*#195\*\* \(cadeia 03 a 09\): pode ficar para depois[^.]*\.\s*", "", t)
        if "Versão 7" not in t:
            ls = t.split("\n")
            ls[2:2] = ["> [!decisão] Versão 7 (05/11): a cadeia completa volta para antes do G9", "> **Todos os notebooks (02 a 10) são reexecutados antes do G9** (#126), em segundo plano, com a documentação atualizada pelo próprio script (`cadeia.py`). O #195 foi incorporado ao #126. **Dois comandos** fazem o resto: `pre_g9.py` (#188 e #192) e, depois do G9, `pos_g9.py` (#2, #165, #194, #189, #157). Os cards são fechados por `[done:#N]` nos commits.", ""]
            t = "\n".join(ls)
        t = t.replace("(≈ 4,0 h)", "(≈ 4,7 h)")
        t = t.replace("a renomeação das saídas (#192) **foi mantida** e o notebook 10 é reexecutado logo depois (#126)", "a renomeação das saídas (#192) **foi mantida** e **todos os notebooks (02 a 10) são reexecutados logo depois (#126), antes do G9**")
        return t
    d.editar_secao("Aviso da revisão", aviso, "referências ao #195 e à cadeia")

    def ajuda(t: str) -> str:
        extra = ("\n- **Lote 4 (comandos de ponta a ponta):** `pre_g9.py` (#188 e #192: testes, renomeação, commit, push, painel) · `cadeia.py` (#126: notebooks 02 a 10 em segundo plano, com `iniciar`, `status` e `--de NN` para retomar; "
                 "documentação automática: caminhos, lock, pyproject, README; commit e push) · `pos_g9.py` (depois do G9: checklist, calibração, tabelas, curva, documentação do G9, comentários e caminhos, resultados, commits, mescla na main) · `aplicar_docs_g9.py` (aplica os blocos do G9) · `painel_marcar.py` (tenta marcar cards como concluídos) · `atualizar_painel.py` (este texto). "
                 "Os cards são fechados por `[done:#N]` na mensagem dos commits: o painel lê a `main`, então os que vão na branch aparecem quando ela é mesclada.")
        return t.rstrip("\n") + extra + "\n" if "Lote 4" not in t else t
    d.editar_secao("Ajuda · Bloco para a IA e scripts desta revisão", ajuda, "scripts do lote 4")


def validar(raiz: Path) -> tuple[bool, str]:
    srv = raiz / ".srag-status-local" / "server.py"
    if not srv.is_file():
        return True, "server.py nao encontrado: validacao do painel pulada"
    r = subprocess.run([sys.executable, str(srv), "validar"], cwd=raiz, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=300)
    saida = (r.stdout + r.stderr).strip()
    ok = r.returncode == 0 and "ida-e-volta ok" in saida
    return ok, saida[-700:]


def main() -> int:
    for s in (sys.stdout, sys.stderr):
        try:
            s.reconfigure(encoding="utf-8", errors="replace")
        except (AttributeError, ValueError):
            pass
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--raiz", type=Path, default=Path.cwd())
    ap.add_argument("--simular", action="store_true")
    ap.add_argument("--arquivo", default=ARQ)
    a = ap.parse_args()
    raiz = a.raiz.resolve()
    caminho = raiz / a.arquivo
    if not caminho.is_file():
        print(f"ABORTADO: nao achei {a.arquivo} em {raiz}.")
        return 1
    original = caminho.read_bytes().decode("utf-8-sig")
    d = Doc(original)
    aplicar(d)
    for f in d.feitos:
        print("  feito:", f)
    for av in dict.fromkeys(d.avisos):
        print("  AVISO:", av)
    novo = d.texto()
    if novo == original:
        print("Nada mudou: o texto do painel ja esta atualizado.")
        return 0
    if novo.count("```") % 2 or novo.count("~~~") % 2:
        print("ABORTADO: o resultado teria blocos de codigo desbalanceados; nada foi gravado.")
        return 1
    if a.simular:
        print(f"Simulacao: {len(d.feitos)} troca(s), {len(d.avisos)} aviso(s). Nada foi gravado.")
        return 0
    pasta = raiz / ".srag-status-local" / "backups"
    pasta.mkdir(parents=True, exist_ok=True)
    copia = pasta / f"PENDENCIAS_antes_lote4_{datetime.now():%Y%m%dT%H%M%S}.md"
    shutil.copy2(caminho, copia)
    caminho.write_bytes(novo.encode("utf-8"))
    ok, saida = validar(raiz)
    print("validacao do painel:", saida)
    if not ok:
        shutil.copy2(copia, caminho)
        print("O painel reclamou: o arquivo ORIGINAL foi devolvido. Mande a mensagem acima para a IA.")
        return 1
    print(f"Texto atualizado em {a.arquivo} (copia do original em {copia.relative_to(raiz).as_posix()}).")
    print("Agora: abra o painel e clique em 'Publicar edicoes locais'.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
