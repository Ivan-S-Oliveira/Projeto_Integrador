#!/usr/bin/env python3
r"""Aplica os blocos de texto do G9 (outputs/final/blocos_g9.md) em docs/decisoes.md, README.md e configs/supervised.yaml.

Uso (na raiz do repositorio, DEPOIS do G9 e do gerar_blocos_g9.py):  [antes: $env:PYTHONPATH = "tools\G9_final.zip"]
    .\.venv\Scripts\python.exe -m aplicar_docs_g9             (relatorio: mostra o que faria; nada e gravado)
    .\.venv\Scripts\python.exe -m aplicar_docs_g9 --aplicar   (grava)

Faz o que o card #194 pede nos passos 2 a 6:
    - docs/decisoes.md: insere o "Resultado da abertura" antes de "## 10." (ou no fim, se nao achar a ancora)
    - README.md: troca "os resultados do teste ficam no relatorio final..." pelo paragrafo com os numeros
    - configs/supervised.yaml: selecao_modelos.teste_consultado -> true e a frase "permanecem fechados" -> "foram abertos ..."
Recusa blocos de ENSAIO. Nao mexe em models, features, limiar, calibracao nem gates (confere por comparacao). E idempotente.
Codigo de saida: 0 tudo aplicado (ou ja estava), 2 parcial (algum trecho nao foi achado), 1 erro.
"""
from __future__ import annotations

import argparse
import re
import sys
from datetime import datetime
from pathlib import Path


def ler(p: Path) -> tuple[str, str, bool]:
    b = p.read_bytes()
    bom = b.startswith(b"\xef\xbb\xbf")
    t = b.decode("utf-8-sig")
    eol = "\r\n" if "\r\n" in t else "\n"
    return t.replace("\r\n", "\n"), eol, bom


def gravar(p: Path, t: str, eol: str, bom: bool) -> None:
    dados = t.replace("\n", eol).encode("utf-8")
    p.write_bytes((b"\xef\xbb\xbf" if bom else b"") + dados)


def blocos(texto: str) -> dict[int, list[str]]:
    partes = re.split(r"(?m)^## Bloco (\d+)\b", texto)
    out: dict[int, list[str]] = {}
    for i in range(1, len(partes) - 1, 2):
        cercas = re.findall(r"```[a-z]*\n(.*?)\n```", partes[i + 1], flags=re.S)
        out[int(partes[i])] = cercas
    return out


def data_g9(raiz: Path) -> str:
    try:
        import yaml

        cfg = yaml.safe_load((raiz / "configs" / "supervised.yaml").read_text(encoding="utf-8"))
        quando = str(cfg["gates"]["G9_holdout"]["executado_em"])
        return datetime.fromisoformat(quando.replace("Z", "+00:00")).strftime("%d/%m/%Y")
    except Exception:  # noqa: BLE001
        return datetime.now().strftime("%d/%m/%Y")


def aplicar_decisoes(raiz: Path, bloco1: str, gravar_: bool) -> tuple[str, bool]:
    p = raiz / "docs" / "decisoes.md"
    if not p.is_file():
        return "docs/decisoes.md nao existe", False
    t, eol, bom = ler(p)
    if "Resultado da abertura" in t:
        return "decisoes.md: ja tem 'Resultado da abertura' (nada a fazer)", True
    m = re.search(r"(?m)^## 10\.", t)
    novo_bloco = bloco1.strip("\n")
    if m:
        t2 = t[:m.start()].rstrip("\n") + "\n\n" + novo_bloco + "\n\n" + t[m.start():]
        onde = "antes de '## 10.'"
    else:
        t2 = t.rstrip("\n") + "\n\n" + novo_bloco + "\n"
        onde = "no fim do arquivo (nao achei '## 10.')"
    if gravar_:
        gravar(p, t2, eol, bom)
    return f"decisoes.md: 'Resultado da abertura' inserido {onde}", True


def aplicar_readme(raiz: Path, novo: str, gravar_: bool) -> tuple[str, bool]:
    p = raiz / "README.md"
    if not p.is_file():
        return "README.md nao existe", False
    t, eol, bom = ler(p)
    if "Teste aberto uma única vez" in t or "Teste aberto uma unica vez" in t:
        return "README: ja descreve a abertura do teste (nada a fazer)", True
    novo = novo.strip("\n")
    pad_a = re.compile(r"Valida[çc][ãa]o \(`val_ref`\):.{0,400}?depois da abertura [úu]nica\.", re.S)
    pad_b = re.compile(r"Os\s+resultados do teste ficam no relat[óo]rio final,\s+depois da abertura [úu]nica\.")
    if pad_a.search(t):
        t2 = pad_a.sub(lambda m: novo, t, count=1)
        onde = "paragrafo de resultados trocado"
    elif pad_b.search(t):
        resto = novo.split("\n\n", 1)[-1] if "\n\n" in novo else novo
        t2 = pad_b.sub(lambda m: resto, t, count=1)
        onde = "frase 'ficam no relatorio final' trocada pelo paragrafo do teste"
    else:
        t2 = t.rstrip("\n") + "\n\n## Resultado do teste\n\n" + novo + "\n"
        onde = "secao nova no fim (nao achei a frase antiga: apague a mao qualquer texto que diga que o resultado fica no relatorio)"
        if gravar_:
            gravar(p, t2, eol, bom)
        return f"README: {onde}", False
    if gravar_:
        gravar(p, t2, eol, bom)
    return f"README: {onde}", True


def aplicar_yaml(raiz: Path, data: str, gravar_: bool) -> tuple[str, bool]:
    import yaml

    p = raiz / "configs" / "supervised.yaml"
    if not p.is_file():
        return "supervised.yaml nao existe", False
    t, eol, bom = ler(p)
    antes = yaml.safe_load(t)
    feito, falta = [], []
    t2 = t
    if re.search(r"(?m)^\s*teste_consultado:\s*true\b", t2):
        feito.append("teste_consultado ja era true")
    elif re.search(r"(?m)^(\s*teste_consultado:\s*)false\b", t2):
        t2 = re.sub(r"(?m)^(\s*teste_consultado:\s*)false\b", r"\1true", t2, count=1)
        feito.append("teste_consultado -> true")
    else:
        falta.append("chave teste_consultado nao encontrada")
    frase = rf"test_ref e test_pandemic foram abertos uma unica vez em {data} (G9)"
    if "foram abertos uma unica vez" in t2:
        feito.append("observacao ja atualizada")
    else:
        pad = re.compile(r"(?m)^(\s*-\s*[\"']?)test_ref e test_pandemic permanecem fechados[^\n\"']*([\"']?)\s*$")
        if pad.search(t2):
            t2 = pad.sub(lambda m: m.group(1) + frase + m.group(2), t2, count=1)
            feito.append("observacao 'permanecem fechados' trocada")
        else:
            falta.append("frase 'permanecem fechados' nao encontrada")
    try:
        depois = yaml.safe_load(t2)
    except yaml.YAMLError as exc:
        return f"YAML ficaria invalido ({exc}); nada gravado", False
    for chave in ("models", "features", "limiar", "calibracao", "gates", "temporal", "target"):
        if antes.get(chave) != depois.get(chave):
            return f"ABORTADO: a edicao mudaria '{chave}' (nao deveria); nada gravado", False
    if t2 != t and gravar_:
        gravar(p, t2, eol, bom)
    ok = not falta
    return "supervised.yaml: " + "; ".join(feito + [f"AVISO: {f}" for f in falta]), ok


def main() -> int:
    for s in (sys.stdout, sys.stderr):
        try:
            s.reconfigure(encoding="utf-8", errors="replace")
        except (AttributeError, ValueError):
            pass
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--raiz", type=Path, default=Path.cwd())
    ap.add_argument("--blocos", type=Path)
    ap.add_argument("--aplicar", action="store_true")
    a = ap.parse_args()
    raiz = a.raiz.resolve()
    arq = a.blocos or (raiz / "outputs" / "final" / "blocos_g9.md")
    if not arq.is_file():
        print(f"ABORTADO: nao achei {arq}. Rode antes o gerar_blocos_g9.py (sem --ensaio).")
        return 1
    texto = arq.read_text(encoding="utf-8", errors="replace")
    if "ENSAIO" in texto.splitlines()[0]:
        print("ABORTADO: o arquivo de blocos e de ENSAIO (nao e resultado do teste). Gere com o teste real.")
        return 1
    bl = blocos(texto)
    if len(bl.get(1, [])) < 1 or len(bl.get(2, [])) < 2:
        print("ABORTADO: nao achei os blocos 1 e 2 no arquivo (formato inesperado).")
        return 1
    data = data_g9(raiz)
    resultados = [aplicar_decisoes(raiz, bl[1][0], a.aplicar), aplicar_readme(raiz, bl[2][1], a.aplicar), aplicar_yaml(raiz, data, a.aplicar)]
    for msg, _ in resultados:
        print(("  " if a.aplicar else "  [simulacao] ") + msg)
    tudo = all(ok for _, ok in resultados)
    print(("GRAVADO." if a.aplicar else "Relatorio pronto. Nada foi gravado. Para gravar: --aplicar.") + ("" if tudo else " ATENCAO: algum trecho precisa de ajuste a mao (veja acima)."))
    return 0 if tudo else 2


if __name__ == "__main__":
    sys.exit(main())
