#!/usr/bin/env python3
r"""Fluxo ate o G9 em dois comandos (rodar na raiz do repositorio, na branch enxugamento; antes: $env:PYTHONPATH = "tools\G9_final.zip").

  .\.venv\Scripts\python.exe -m fluxo preparar    cadeia 02-10, ensaio do 11, ensaio do pos-G9 e checklist
  .\.venv\Scripts\python.exe -m fluxo abrir       aprova o G9, abre o teste, confere, publica e roda o pos_g9

Cada comando aceita --conferir: so confere (nada e alterado) e mostra o plano.
A aprovacao humana e sempre digitada: APROVO O G9 e ABRIR O TESTE.
"""
from __future__ import annotations

import argparse
import difflib
import os
import re
import shutil
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path

AQUI = Path(__file__).resolve().parent
_ZIP = AQUI if AQUI.suffix.lower() == ".zip" else None


def _existe(nome: str) -> bool:
    # roda a partir do zip (sem descompactar): confere dentro do zip
    if _ZIP:
        import zipfile
        try:
            return f"{nome}.py" in zipfile.ZipFile(_ZIP).namelist()
        except OSError:
            return False
    return (AQUI / f"{nome}.py").is_file()


def _cmd(nome: str, *args: str) -> list[str]:
    # com o zip no PYTHONPATH (ver _env_zip), "-m nome" acha o modulo dentro dele
    if _ZIP:
        return [sys.executable, "-m", nome, *args]
    return [sys.executable, str(AQUI / f"{nome}.py"), *args]


def _env_zip(env: dict) -> dict:
    if not _ZIP:
        return env
    env = dict(env)
    atual = env.get("PYTHONPATH", "")
    env["PYTHONPATH"] = str(_ZIP) + (os.pathsep + atual if atual else "")
    return env
YAML = "configs/supervised.yaml"
NB11 = "notebooks/11_validacao_final.ipynb"
PERIGOSAS = ("SRAG_ENSAIO", "SRAG_ALLOW_TEST_REOPEN", "SRAG_ALLOW_DIRTY")
OBRIG_PREPARAR = ["cadeia", "limpar_caminhos", "checklist_g9", "calibracao_pos_g9", "gerar_blocos_g9"]
OBRIG_ABRIR = ["checklist_g9", "pos_g9", "aplicar_docs_g9", "gerar_blocos_g9", "calibracao_pos_g9", "lote", "rodar_testes"]
OPCIONAIS = ["tabelas_relatorio", "curva_decisao", "montar_resultados"]
CAMPO = re.compile(r"^ {4}(status|aprovado_por|data|executado_em|n_acessos):[ \t]*(.*?)[ \t]*$")

LOG: Path | None = None


class Parar(Exception):
    pass


def dizer(txt: str = "") -> None:
    print(txt, flush=True)
    if LOG:
        with LOG.open("a", encoding="utf-8") as fh:
            fh.write(txt + "\n")


def parar(msg: str) -> None:
    raise Parar(msg)


def git(raiz: Path, *args: str) -> tuple[int, str]:
    r = subprocess.run(["git", *args], cwd=raiz, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=900)
    return r.returncode, (r.stdout + (("\n" + r.stderr) if r.returncode and r.stderr else "")).rstrip()


def ambiente(extra: dict | None = None) -> dict:
    env = {k: v for k, v in os.environ.items() if k not in PERIGOSAS}
    env.update({"PYTHONUTF8": "1", "PYTHONIOENCODING": "utf-8"})
    env.update(extra or {})
    return env


def rodar(cmd: list[str], raiz: Path, env: dict | None = None) -> tuple[int, str]:
    p = subprocess.Popen(cmd, cwd=raiz, env=env or ambiente(), stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, encoding="utf-8", errors="replace", bufsize=1)
    linhas = []
    for ln in p.stdout:
        ln = ln.rstrip("\r\n")
        linhas.append(ln)
        dizer(ln)
    return p.wait(), "\n".join(linhas)


def script(raiz: Path, nome: str, *args: str, extra: dict | None = None) -> tuple[int, str]:
    return rodar(_cmd(nome, "--raiz", str(raiz), *args), raiz, _env_zip(ambiente(extra)))


def sem_suspensao() -> None:
    if os.name == "nt":
        try:
            import ctypes

            ctypes.windll.kernel32.SetThreadExecutionState(0x80000001)
        except Exception:  # noqa: BLE001
            pass


def suja(raiz: Path) -> list[str]:
    return [x for x in git(raiz, "status", "--porcelain", "--untracked-files=no")[1].splitlines() if x.strip()]


def so_painel(linhas: list[str]) -> bool:
    return any("PROJECT_STATUS_TEXT.md" in x for x in linhas)


def divergencia(raiz: Path) -> tuple[int, int] | None:
    rc, out = git(raiz, "rev-list", "--left-right", "--count", "HEAD...@{u}")
    if rc != 0:
        return None
    a, b = out.split()
    return int(a), int(b)


def reais(raiz: Path, pasta: str, padrao: str) -> list[Path]:
    base = raiz / pasta
    return [p for p in base.glob(padrao) if "ensaio" not in p.name.lower()] if base.is_dir() else []


# ---------------------------------------------------------------- YAML do G9
def linhas_yaml(raiz: Path) -> list[str]:
    return re.findall(r"[^\n]*\n|[^\n]+", (raiz / YAML).read_bytes().decode("utf-8"))


def ler_g9(linhas: list[str]) -> dict:
    ini = [i for i, ln in enumerate(linhas) if ln.rstrip("\r\n") == "  G9_holdout:"]
    if len(ini) != 1:
        parar(f"nao achei exatamente uma linha '  G9_holdout:' em {YAML} (achei {len(ini)}).")
    ini = ini[0]
    fim = len(linhas)
    for j in range(ini + 1, len(linhas)):
        t = linhas[j].rstrip("\r\n")
        if t.strip() and len(t) - len(t.lstrip(" ")) <= 2:
            fim = j
            break
    campos = {}
    for i in range(ini + 1, fim):
        m = CAMPO.match(linhas[i].rstrip("\r\n"))
        if m:
            campos[m.group(1)] = (i, m.group(2).strip("'\""))
    falta = [c for c in ("status", "aprovado_por", "data", "executado_em", "n_acessos") if c not in campos]
    if falta:
        parar("o bloco G9_holdout nao tem as linhas: " + ", ".join(falta))
    return campos


def yaml_aprovado(linhas: list[str], campos: dict, hoje: str) -> list[str]:
    novo = list(linhas)
    for chave, valor in (("status", "aprovado"), ("aprovado_por", "equipe"), ("data", f"'{hoje}'")):
        i = campos[chave][0]
        eol = linhas[i][len(linhas[i].rstrip("\r\n")):]
        novo[i] = f"    {chave}: {valor}{eol}"
    return novo


def validar_yaml(antes: list[str], depois: list[str]) -> None:
    try:
        import yaml
    except ImportError:
        return
    a, d = yaml.safe_load("".join(antes)), yaml.safe_load("".join(depois))
    ga, gd = a["gates"]["G9_holdout"], d["gates"]["G9_holdout"]
    if gd.get("status") != "aprovado":
        parar("o YAML novo nao ficou com status aprovado. Nada foi gravado.")
    for k in ("status", "aprovado_por", "data"):
        ga[k] = gd[k]
    if a != d:
        parar("o YAML novo muda mais do que as tres linhas. Nada foi gravado.")


# ---------------------------------------------------------------- conferencias
def conferir_base(raiz: Path, args, obrigatorios: list[str], conferir: bool) -> dict:
    dizer("== Conferindo o ambiente ==")
    if not (raiz / "src").is_dir() or not (raiz / YAML).is_file() or not (raiz / "tools" / "medir_notebook.py").is_file():
        parar(f"{raiz} nao parece a raiz do projeto (falta src, {YAML} ou tools/medir_notebook.py).")
    falta = [n for n in obrigatorios if not _existe(n)]
    if falta:
        parar("faltam scripts ao lado do fluxo.py: " + ", ".join(f + ".py" for f in falta))
    sem_opc = [n for n in OPCIONAIS if not _existe(n)]
    if sem_opc:
        dizer("AVISO: scripts opcionais ausentes (o pos_g9 segue sem eles): " + ", ".join(f + ".py" for f in sem_opc))
    dizer("scripts: ok")
    ramo = git(raiz, "rev-parse", "--abbrev-ref", "HEAD")[1]
    if ramo != args.ramo and not args.qualquer_ramo:
        parar(f"voce esta no ramo '{ramo}' e o esperado e '{args.ramo}': git switch {args.ramo}")
    s = suja(raiz)
    if s:
        parar("ha mudancas nao commitadas:\n" + "\n".join("  " + x for x in s[:10]) + ("\nO PROJECT_STATUS_TEXT.md alterado e a previa do painel: clique em 'Publicar edicoes locais' e rode de novo." if so_painel(s) else ""))
    git(raiz, "fetch", "origin")
    d = divergencia(raiz)
    if d and d[1]:
        if conferir:
            dizer(f"AVISO: o GitHub tem {d[1]} commit(s) novos; o comando de verdade faz git pull --ff-only antes.")
        else:
            rc, out = git(raiz, "pull", "--ff-only")
            if rc != 0:
                parar("git pull --ff-only falhou: " + out[-200:])
            dizer(f"git pull: {d[1]} commit(s) trazidos")
    dizer(f"ramo {ramo}, arvore limpa")
    campos = ler_g9(linhas_yaml(raiz))
    g9 = {k: v[1] for k, v in campos.items()}
    dizer(f"G9_holdout: status={g9['status']}, n_acessos={g9['n_acessos']}")
    if g9["status"] == "executado" or g9["n_acessos"] not in ("0", ""):
        parar("o G9 ja foi executado. O teste NAO pode ser aberto de novo.")
    if reais(raiz, "outputs/tables", "*validacao_final_*_manifesto.json"):
        parar("ja existe manifesto REAL do notebook 11: o teste ja foi aberto.")
    return g9


def checklist(raiz: Path, *extra: str, antes: bool = True) -> None:
    rc, out = script(raiz, "checklist_g9", *extra)
    if antes:
        if rc != 0 or "PODE APROVAR O G9" not in out:
            parar("o checklist nao liberou o G9 (veja as linhas [FALHA] acima).")
    elif rc != 0:
        parar("o checklist --depois tem FALHAS (veja acima).")


# ---------------------------------------------------------------- preparar
def preparar(raiz: Path, a) -> None:
    conferir_base(raiz, a, OBRIG_PREPARAR, a.conferir)
    g9 = ler_g9(linhas_yaml(raiz))
    if g9["status"][1] != "pendente":
        parar(f"o G9 esta '{g9['status'][1]}', nao 'pendente'. Para aprovar e abrir use: fluxo.py abrir")
    if a.conferir:
        dizer("\nPLANO (nada foi executado):")
        dizer("  1. cadeia.py executar (notebooks 02 a 10, documentacao, pytest, commit e push)" + (" [pulada]" if a.pular_cadeia else ""))
        dizer("  2. notebook 11 em modo ENSAIO (SRAG_ENSAIO so no processo filho)")
        dizer("  3. calibracao_pos_g9.py --ensaio e gerar_blocos_g9.py --ensaio")
        dizer("  4. checklist_g9.py --com-testes")
        dizer("  5. arvore limpa")
        return
    if not a.pular_cadeia:
        dizer("\n== 1/5 Cadeia de notebooks 02 a 10 (leva horas; nao feche o terminal nem desligue o computador) ==")
        rc, _ = rodar(_cmd("cadeia", "executar", "--raiz", str(raiz), "--de", a.de), raiz, _env_zip(ambiente()))
        if rc != 0:
            parar(f"a cadeia parou (veja o erro acima). Corrija e retome: fluxo.py preparar --de NN (NN = notebook onde parou).")
    else:
        dizer("\n== 1/5 Cadeia: pulada (--pular-cadeia) ==")
    s = suja(raiz)
    if s:
        parar("depois da cadeia a arvore ficou suja:\n" + "\n".join("  " + x for x in s[:10]))
    dizer("\n== 2/5 Ensaio do notebook 11 (o teste NAO e lido) ==")
    sem_suspensao()
    rc, out = rodar([sys.executable, "tools/medir_notebook.py", NB11, "--limite-mb", "14336", "--limite-s", "3600"], raiz, ambiente({"SRAG_ENSAIO": "1"}))
    if rc != 0:
        parar("o ensaio falhou (veja acima). Corrija e repita: fluxo.py preparar --pular-cadeia")
    if "ENSAIO" not in out.upper():
        dizer("AVISO: nao vi a palavra ENSAIO na saida. Confira o inicio da saida antes de seguir.")
    dizer("\n== 3/5 Ensaio do pos-G9 ==")
    for nome in ("calibracao_pos_g9", "gerar_blocos_g9"):
        rc, _ = script(raiz, nome, "--ensaio")
        if rc != 0:
            parar(f"{nome}.py --ensaio falhou (veja acima).")
    dizer("\n== 4/5 Checklist do G9 (com testes; leva alguns minutos) ==")
    checklist(raiz, "--com-testes")
    dizer("\n== 5/5 Arvore ==")
    s = suja(raiz)
    if s:
        parar("o ensaio deixou a arvore suja:\n" + "\n".join("  " + x for x in s[:10]))
    dizer("arvore limpa")
    dizer("\n== PRONTO: PODE APROVAR O G9 ==")
    dizer("1. Avise o grupo: 'codigo congelado'. Ninguem mexe em src, configs ou notebooks.")
    dizer("2. Peca os tres 'ok' por escrito: 'G9: codigo congelado, checklist verde, aprovo'.")
    dizer("3. Com os tres ok, rode:  .\\.venv\\Scripts\\python.exe tools\\G9_final\\fluxo.py abrir")


# ---------------------------------------------------------------- abrir
def confirmar(frase: str, aviso: str) -> None:
    dizer(aviso)
    try:
        r = input(f"\nDigite exatamente  {frase}  para continuar (qualquer outra coisa cancela): ").strip()
    except EOFError:
        r = ""
    dizer(f"resposta digitada: {r!r}")
    if r != frase:
        parar("aprovacao nao confirmada. Nada foi alterado depois deste ponto.")


def publicar(raiz: Path, ramo: str) -> None:
    rc, out = git(raiz, "push")
    if rc != 0:
        rc, out = git(raiz, "push", "-u", "origin", ramo)
    if rc != 0:
        parar("o push falhou: " + out[-200:] + " (o commit local existe; rode git push quando resolver).")


def backup(raiz: Path) -> None:
    dest = raiz.parent / "backup_g9"
    dest.mkdir(exist_ok=True)
    for sub in ("outputs/tables", "outputs/predictions"):
        if (raiz / sub).is_dir():
            shutil.copytree(raiz / sub, dest / Path(sub).name, dirs_exist_ok=True)
    m = raiz / "data" / "analytical" / "manifesto_supervisionado.json"
    if m.is_file():
        shutil.copy2(m, dest / m.name)
    dizer(f"backup em {dest}")


def abrir(raiz: Path, a) -> None:
    ramo = git(raiz, "rev-parse", "--abbrev-ref", "HEAD")[1]
    conferir_base(raiz, a, OBRIG_ABRIR, a.conferir)
    campos = ler_g9(linhas_yaml(raiz))
    status = campos["status"][1]
    if a.conferir:
        dizer("\nPLANO (nada foi executado):")
        dizer("  1. checklist_g9.py (sem testes) tem de liberar")
        if status == "pendente":
            hoje = datetime.now().strftime("%Y-%m-%d")
            antes = linhas_yaml(raiz)
            depois = yaml_aprovado(antes, campos, hoje)
            validar_yaml(antes, depois)
            dizer("  2. APROVACAO 1 (digitar APROVO O G9); troca so estas linhas do G9_holdout:")
            for ln in difflib.unified_diff(antes, depois, "atual", "novo", n=0, lineterm=""):
                if ln.startswith(("+", "-")) and not ln.startswith(("+++", "---")):
                    dizer("     " + ln.rstrip("\r\n"))
            dizer("  3. commit 'G9 aprovado [done:#193] [done:#81]' e push")
        else:
            dizer(f"  2-3. G9 ja esta '{status}': pula a aprovacao")
        dizer("  4. APROVACAO 2 (digitar ABRIR O TESTE); roda o notebook 11 de verdade (sem SRAG_*)")
        dizer("  5. backup em ..\\backup_g9, checklist_g9.py --depois, commit 'G9 executado [done:#2] [done:#26]' e push")
        dizer("  6. pos_g9.py" + (" (pulado: --sem-pos)" if a.sem_pos else ""))
        return
    dizer("\n== 1/6 Checklist antes da aprovacao ==")
    checklist(raiz)
    if status == "pendente":
        antes = linhas_yaml(raiz)
        hoje = datetime.now().strftime("%Y-%m-%d")
        depois = yaml_aprovado(antes, campos, hoje)
        validar_yaml(antes, depois)
        dif = [ln.rstrip("\r\n") for ln in difflib.unified_diff(antes, depois, "atual", "novo", n=0, lineterm="") if ln.startswith(("+", "-")) and not ln.startswith(("+++", "---"))]
        dizer("\n== 2/6 APROVACAO HUMANA 1: aprovar o G9 ==")
        confirmar("APROVO O G9", "O checklist esta verde. Mudanca no " + YAML + ":\n" + "\n".join("  " + x for x in dif) + "\n\nSo continue se a equipe deu os tres 'ok' por escrito no grupo.")
        (raiz / YAML).write_bytes("".join(depois).encode("utf-8"))
        s = suja(raiz)
        if s != [x for x in s if YAML in x]:
            parar("alem do YAML, ha outras mudancas na arvore:\n" + "\n".join("  " + x for x in s))
        git(raiz, "add", YAML)
        rc, out = git(raiz, "commit", "-m", "G9 aprovado [done:#193] [done:#81]")
        if rc != 0:
            git(raiz, "checkout", "--", YAML)
            parar("git commit falhou (o YAML foi devolvido): " + out[:200])
        publicar(raiz, ramo)
        dizer("G9 aprovado, commitado e publicado")
    else:
        dizer(f"\n== 2/6 G9 ja esta '{status}': aprovacao pulada ==")
        d = divergencia(raiz)
        if d and d[0]:
            publicar(raiz, ramo)
    s = suja(raiz)
    d = divergencia(raiz)
    if s or (d and d[0]):
        parar("antes de abrir o teste a arvore tem de estar limpa e publicada (a trava do notebook exige).")
    dizer("\n== 3/6 APROVACAO HUMANA 2: abrir o teste (UMA unica vez) ==")
    confirmar("ABRIR O TESTE", "Computador na tomada, suspensao desativada, nada pesado aberto.")
    sem_suspensao()
    dizer("\n== 4/6 Notebook 11 (teste real) ==")
    inicio = time.time() - 5
    rc, _ = rodar([sys.executable, "tools/medir_notebook.py", NB11, "--salvar-no-lugar", "--limite-s", "5400", "--limite-mb", "14336"], raiz)
    if rc != 0:
        gravou = [p for p in reais(raiz, "outputs/predictions", "*validacao_final_*_predicoes_teste.*") if p.stat().st_mtime >= inicio]
        backup(raiz)
        if gravou:
            parar("o notebook falhou DEPOIS de gravar as previsoes. NAO RODE O NOTEBOOK 11 DE NOVO. Use o plano de recuperacao do card #2, passo 8 (e me envie a saida acima).")
        parar("o notebook falhou ANTES de gravar as previsoes (nada do teste foi visto). Leia a mensagem acima; depois de corrigir, e seguro repetir: fluxo.py abrir")
    dizer("\n== 5/6 Backup, checklist depois e publicacao ==")
    backup(raiz)
    rc, _ = script(raiz, "checklist_g9", "--depois")
    if rc != 0:
        parar("o checklist --depois tem FALHAS. O backup foi feito e NADA foi commitado. Confira as linhas acima; para publicar depois: git add -A; git commit -m \"G9 executado [done:#2] [done:#26]\"; git push")
    dizer(git(raiz, "status", "--short")[1] or "(sem mudancas)")
    git(raiz, "add", "-A")
    rc, out = git(raiz, "commit", "-m", "G9 executado [done:#2] [done:#26]")
    if rc != 0 and "nothing to commit" not in out:
        parar("git commit falhou: " + out[:200])
    publicar(raiz, ramo)
    dizer("G9 executado, commitado e publicado. AVISE O GRUPO: 'teste aberto'.")
    if a.sem_pos:
        dizer('--sem-pos: depois rode  $env:PYTHONPATH = "tools\\G9_final.zip"; .\\.venv\\Scripts\\python.exe -m pos_g9')
        return
    dizer("\n== 6/6 Pos-G9 (pos_g9.py) ==")
    extra = ["--ramo", a.ramo] + (["--qualquer-ramo"] if a.qualquer_ramo else [])
    rc, _ = script(raiz, "pos_g9", *extra)
    if rc != 0:
        parar("o pos_g9 parou (veja acima). O teste ja esta aberto e publicado. Corrija e rode so:  .\\.venv\\Scripts\\python.exe tools\\G9_final\\pos_g9.py  (e seguro repetir).")
    dizer("\n== TUDO PRONTO ==")


def main() -> int:
    global LOG
    for s in (sys.stdout, sys.stderr):
        try:
            s.reconfigure(encoding="utf-8", errors="replace", line_buffering=True)
        except (AttributeError, ValueError):
            pass
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("fase", choices=["preparar", "abrir"])
    ap.add_argument("--raiz", type=Path, default=Path.cwd())
    ap.add_argument("--ramo", default="enxugamento")
    ap.add_argument("--qualquer-ramo", action="store_true")
    ap.add_argument("--conferir", action="store_true")
    ap.add_argument("--de", default="02", help="preparar: notebook onde retomar a cadeia")
    ap.add_argument("--pular-cadeia", action="store_true", help="preparar: comeca no ensaio")
    ap.add_argument("--sem-pos", action="store_true", help="abrir: nao roda o pos_g9")
    a = ap.parse_args()
    raiz = a.raiz.resolve()
    pasta = raiz.parent / "fluxo_logs"
    pasta.mkdir(exist_ok=True)
    LOG = pasta / f"fluxo_{a.fase}_{datetime.now():%Y%m%d_%H%M%S}.log"
    try:
        (preparar if a.fase == "preparar" else abrir)(raiz, a)
    except Parar as exc:
        dizer(f"\nPARADO: {exc}")
        dizer(f"(log completo: {LOG})")
        return 1
    except KeyboardInterrupt:
        dizer("\nInterrompido pelo usuario.")
        return 130
    dizer(f"(log completo: {LOG})")
    return 0


if __name__ == "__main__":
    sys.exit(main())