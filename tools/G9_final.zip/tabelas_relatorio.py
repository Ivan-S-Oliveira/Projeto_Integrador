#!/usr/bin/env python3
r"""Tabelas de equidade e figura por regiao a partir dos CSV que o notebook 11 gravou. So le CSV agregados.

Uso (na raiz do repositorio, com o venv do projeto, DEPOIS do G9):  [antes: $env:PYTHONPATH = "tools\G9_final.zip"]
    .\.venv\Scripts\python.exe -m tabelas_relatorio                  (relatorio: lista o que leu e o que suprimiu; nada e gravado)
    .\.venv\Scripts\python.exe -m tabelas_relatorio --aplicar        (grava outputs/final/tabelas_relatorio_*.csv e reports/figures/equidade_regiao.png)
    .\.venv\Scripts\python.exe -m tabelas_relatorio --ensaio         (usa os CSV do ensaio, so para treinar)

Regras aplicadas depois do notebook (o notebook nao muda): grupo suprimido se n < 100, ou obitos < 20, ou curas < 20;
codigos de raca/cor e zona viram nomes legiveis; "9" vira "9 ignorado"; vazio vira "AUSENTE".
"""
from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path

import numpy as np
import pandas as pd

MIN_N, MIN_EVENTOS = 100, 20
NOMES = {
    "cs_raca": {"1": "1 branca", "2": "2 preta", "3": "3 amarela", "4": "4 parda", "5": "5 indigena", "9": "9 ignorado"},
    "cs_zona": {"1": "1 urbana", "2": "2 rural", "3": "3 periurbana", "9": "9 ignorado"},
}
COLUNAS = ["grupo", "n", "obitos", "prevalencia", "pr_auc_sobre_prev", "roc_auc", "brier", "o_e", "recall", "precision", "suprimido"]


def achar_prefixo(tabelas: Path, ensaio: bool) -> str | None:
    cands = [p for p in tabelas.glob("*validacao_final_*_manifesto.json") if ("ensaio" in p.name.lower()) == ensaio]
    return max(cands, key=lambda p: p.stat().st_mtime).name.replace("_manifesto.json", "") if cands else None


def preparar(tab: pd.DataFrame, grupo: str) -> pd.DataFrame:
    t = tab.copy()
    t["grupo"] = t["grupo"].astype("string").str.replace(r"\.0$", "", regex=True)
    t["grupo"] = t["grupo"].replace(NOMES.get(grupo, {})).fillna("AUSENTE")
    t["obitos"] = (t["n"] * t["prevalencia"]).round().astype(int)
    curas = t["n"] - t["obitos"]
    t["suprimido"] = (t["n"] < MIN_N) | (t["obitos"] < MIN_EVENTOS) | (curas < MIN_EVENTOS) | t.get("suprimido", False).astype(bool)
    metricas = [c for c in t.columns if c in ("pr_auc", "pr_auc_sobre_prev", "roc_auc", "auc", "brier", "o_e", "f1", "precision", "recall", "especificidade")]
    t.loc[t["suprimido"], metricas] = np.nan
    if "roc_auc" not in t.columns and "auc" in t.columns:
        t["roc_auc"] = t["auc"]
    return t


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--raiz", type=Path, default=Path.cwd())
    ap.add_argument("--ensaio", action="store_true")
    ap.add_argument("--aplicar", action="store_true")
    args = ap.parse_args()
    raiz = args.raiz.resolve()
    tabelas = raiz / "outputs" / "tables"

    prefixo = achar_prefixo(tabelas, args.ensaio) if tabelas.is_dir() else None
    if not prefixo:
        print("ABORTADO: nao achei o manifesto do notebook 11" + (" (ensaio)." if args.ensaio else ". O G9 foi executado?"))
        return 1
    arquivos = sorted(tabelas.glob(f"{prefixo}_por_grupo_*.csv"))
    if not arquivos:
        print(f"ABORTADO: nenhum {prefixo}_por_grupo_*.csv.")
        return 1
    print(f"Prefixo lido: {prefixo}" + (" (ENSAIO)" if args.ensaio else ""))

    saidas, resumo = {}, []
    for arq in arquivos:
        m = re.match(rf"{re.escape(prefixo)}_por_grupo_(teste_a|teste_b|pandemico_isolado)_(.+)\.csv$", arq.name)
        if not m:
            continue
        janela, grupo = m.groups()
        t = preparar(pd.read_csv(arq), grupo)
        cols = [c for c in COLUNAS if c in t.columns]
        saidas[(janela, grupo)] = t[cols]
        resumo.append((janela, grupo, len(t), int(t["suprimido"].sum())))
    print(f"{'janela':20s} {'grupo':20s} {'linhas':>7s} {'suprimidas':>11s}")
    for j, g, n, s in resumo:
        print(f"{j:20s} {g:20s} {n:7d} {s:11d}")

    fn = {p.name.split("_fn_por_")[1][:-4]: pd.read_csv(p) for p in tabelas.glob(f"{prefixo}_fn_por_*.csv")}
    print(f"Tabelas de falsos negativos: {', '.join(fn) or 'nenhuma'}")

    if not args.aplicar:
        print("Relatorio pronto. Nada foi gravado. Para gravar: rode de novo com --aplicar.")
        return 0

    destino = raiz / "outputs" / "final"
    destino.mkdir(parents=True, exist_ok=True)
    for (janela, grupo), t in saidas.items():
        t.to_csv(destino / f"tabelas_relatorio_{janela}_{grupo}.csv", index=False, encoding="utf-8-sig")
    for grupo, t in fn.items():
        t.to_csv(destino / f"tabelas_relatorio_fn_{grupo}.csv", index=False, encoding="utf-8-sig")

    reg = saidas.get(("teste_a", "regiao_residencia"))
    if reg is not None and reg["recall"].notna().any():
        import matplotlib

        matplotlib.use("Agg")
        import matplotlib.pyplot as plt

        r = reg[~reg["suprimido"]].sort_values("recall")
        fig, ax = plt.subplots(1, 2, figsize=(11, 4))
        ax[0].barh(r["grupo"], r["recall"], label="sensibilidade")
        ax[0].barh(r["grupo"], r["precision"], height=0.4, label="precisao")
        ax[0].axvline(float(np.average(r["recall"], weights=r["n"])), color="red", ls="--", lw=1, label="media (sensibilidade)")
        ax[0].set_title("Teste A: sensibilidade e precisao por regiao (corte global)")
        ax[0].legend()
        if "o_e" in r.columns and r["o_e"].notna().any():
            ax[1].barh(r["grupo"], r["o_e"])
            ax[1].axvline(1.0, color="gray", ls="--", lw=1)
            ax[1].set_title("Teste A: O/E por regiao (1 = calibrado)")
        fig.tight_layout()
        pasta = raiz / "reports" / "figures"
        pasta.mkdir(parents=True, exist_ok=True)
        fig.savefig(pasta / "equidade_regiao.png", dpi=150)
        print("Figura: reports/figures/equidade_regiao.png")
    amplitude = ""
    if reg is not None and reg["recall"].notna().any():
        r = reg[~reg["suprimido"]]
        amplitude = f" Sensibilidade por regiao: de {r['recall'].min():.3f} a {r['recall'].max():.3f}."
    print(f"GRAVADO: {len(saidas) + len(fn)} tabela(s) em outputs/final.{amplitude}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
